# Vérification du domaine https://gabon-360-ai.vercel.app

Date : 8 novembre 2026 · Statut : **partiellement vérifié — la qualité « production » ne peut être confirmée que depuis ton tableau de bord Vercel**

## 1. Ce que j'ai pu constater depuis l'extérieur

| Constat | Résultat |
|---|---|
| L'adresse répond | Oui : la page « GABON 360 AI » s'affiche |
| Mur de connexion Vercel (protection de déploiement) | **Non** : la page est publique, aucune demande de connexion Vercel. C'est ce qu'il faut pour que l'APK puisse appeler `/api` |
| Contenu | L'application GABON 360 AI : écran de connexion « Accès sur invitation uniquement », onglets Accueil / Alertes / Carte / Missions / Parcs / Garmin / Rapports / Utilisateurs, avatar central, « Dicter », « Voix : activée » |
| Cohérence avec le code d'archive | Les textes visibles de la page en ligne se retrouvent à l'identique dans `index.html` de `complet` et dans `index-132.html` : **je ne peux donc pas dire quelle version est déployée** |

## 2. Ce que je n'ai pas pu vérifier (et pourquoi)

1. **« Production »** : seul le tableau de bord Vercel indique quel déploiement porte l'étiquette Production et quels domaines lui sont attachés. Depuis l'extérieur, je ne vois qu'une page qui répond.
2. **Version du code déployé** : le contenu visible est identique entre versions ; je ne peux pas ouvrir les fichiers `.js` du site (l'outil refuse les adresses que je n'ai pas reçues de toi ou d'une page).
3. **Routes `/api/*`** : non testées pour la même raison.
4. **CORS** : sans objet tant que `api/_cors.js` n'est pas déployé ; d'après le code d'origine, les routes actuelles n'envoient aucun en-tête CORS. **L'APK hybride ne pourra donc pas utiliser `/api` tant que cette modification n'est pas déployée.**

## 3. Contrôle à faire (5 minutes, sans rien modifier)

Dans Vercel, projet GABON 360 AI :
1. **Settings → Domains** : `gabon-360-ai.vercel.app` doit apparaître avec la mention Production (d'après le fonctionnement habituel de Vercel, l'adresse `<projet>.vercel.app` est le domaine de production ; les aperçus de branche ont des adresses de la forme `<projet>-git-<branche>-<équipe>.vercel.app`).
2. **Settings → Git → Production Branch** : noter la branche (probablement `main` ou `principal`).
3. **Deployments** : le déploiement marqué « Production » est-il bien le dernier validé ? Noter le commit.
4. **Settings → Deployment Protection** : « Vercel Authentication » doit être **désactivée pour Production** (confirmé de fait par la page publique), et peut rester active pour les aperçus.
5. **Settings → Environment Variables** : `ANTHROPIC_API_KEY` présente pour Production (l'IA serveur en dépend).
6. Depuis un ordinateur, test en lecture seule :
   `curl -i https://gabon-360-ai.vercel.app/api/assistant`
   Attendu : code 200 et un JSON `{"ok":true}` (clé IA configurée) ou `{"ok":false}` (non configurée). Un code 404 signifierait que la route n'est pas déployée ; un 401/403 avec page Vercel, que la protection est active.

## 4. Conséquence pour la suite

- Le domaine est **retenu comme adresse de l'API** (`G360_API_BASE=https://gabon-360-ai.vercel.app`), sous réserve des points 1 et 3 ci-dessus.
- **Ne déploie pas le CORS directement en production** : fais-le d'abord sur une branche de test (adresse d'aperçu), vérifie avec `curl -i -X OPTIONS <adresse-d-aperçu>/api/assistant -H "Origin: https://appassets.androidplatform.net" -H "Access-Control-Request-Method: POST"` (attendu : 204 avec `Access-Control-Allow-Origin`), puis fusionne vers la branche de production.
- Le projet `android/` d'origine pointe vers une adresse d'aperçu de branche ; elle n'est pas reprise ici.
