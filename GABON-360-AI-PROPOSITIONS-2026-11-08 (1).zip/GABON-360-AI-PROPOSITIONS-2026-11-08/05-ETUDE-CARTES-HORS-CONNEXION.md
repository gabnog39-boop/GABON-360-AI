# GABON 360 AI — Étude : cartes téléchargeables et utilisables hors connexion en forêt

Date : 8 novembre 2026 · Statut : **étude et architecture à valider — aucun code de cartes n'est encore écrit**
Objectif (décision du 8 novembre) : choisir une zone (parc, province, rectangle libre), la télécharger quand il y a du réseau, puis l'utiliser en forêt sans réseau, avec la position GPS et les traces.

## 1. Constat sur l'application actuelle (code de `complet`)
- La carte (`index.html`) est une carte Leaflet avec 3 fonds : Esri World Imagery (satellite haute résolution), EOX Sentinel-2 sans nuages 2020 (zoom max 13) et OpenStreetMap, plus des couches Esri de routes/noms.
- **Tous ces fonds sont chargés en ligne, tuile par tuile.** Il n'existe aucun cache de tuiles : sans réseau, la carte est vide (Leaflet lui-même sera embarqué par la proposition 01 ; les tuiles non).
- La variable `MAP` (carte Leaflet) est globale : un module séparé peut lui ajouter une couche hors ligne sans modifier le script existant.

## 2. Le point bloquant : le droit de télécharger les tuiles d'avance
| Source actuelle | Télécharger pour l'usage hors ligne ? | Ce que disent les conditions publiées |
|---|---|---|
| **OpenStreetMap** (`tile.openstreetmap.org`) | **Interdit** | La politique de la fondation précise que le téléchargement en masse est interdit et que l'usage hors ligne n'est pas permis sur ce serveur ; elle renvoie vers des tuiles auto-hébergées ou un fournisseur qui l'autorise |
| **Esri World Imagery** | **Non autorisé** (d'après la FAQ d'Esri relayée sur leurs forums) | Seule la mise en cache temporaire, pendant la connexion, est admise ; pas de copie réutilisée hors ligne |
| **EOX Sentinel-2 sans nuages** | **Possible, par une voie officielle** | EOX propose des fichiers prêts pour l'usage hors ligne (GeoPackage / base SQLite de tuiles) et des livraisons sur mesure (MBTiles) ; usage gratuit **non commercial** (licence CC BY-NC-SA 4.0 avec mention obligatoire), licence commerciale séparée sinon |
| **OpenStreetMap, données** (pas les tuiles) | **Autorisé** (licence ODbL, mention obligatoire) | Des fonds vectoriels dérivés d'OSM peuvent être découpés par zone et hébergés par nous (voir 3.B) |

**Conséquence : les boutons « télécharger cette zone » ne doivent jamais aspirer les tuiles OSM ou Esri actuelles.** Ce serait contraire à leurs conditions et risquerait un blocage de l'application.
Observation à traiter à part : d'après un représentant d'Esri sur son forum, le service World Imagery exige une licence ArcGIS et n'est pas ouvert à un usage commercial ; la conformité de l'usage **actuel en ligne** par GABON 360 AI est à vérifier avec Esri (je ne donne pas d'avis juridique).

## 3. Deux types de fonds hors ligne recommandés
**A. Imagerie satellite Sentinel-2 (EOX), en paquets MBTiles par zone.**
- Résolution native ≈ 10 m (zoom utile jusqu'à 13–14) : on voit la canopée, les fleuves, les clairières, les grandes pistes ; **on ne voit pas les sentiers ni les petits layons**.
- Licence : à confirmer avec EOX pour l'usage de GABON 360 AI (non commercial gratuit ; la liste d'usages non commerciaux publiée cite la recherche, l'éducation, les ONG et l'usage personnel, pas explicitement les administrations : question à poser). Contact public indiqué pour les livraisons sur mesure : `cloudless@eox.at`.

**B. Fond « plan » vectoriel dérivé d'OpenStreetMap (routes, pistes, sentiers, cours d'eau, villages), au format PMTiles.**
- Un outil libre (`pmtiles extract`) découpe un fond mondial Protomaps par emprise et niveau de zoom maximal en **un seul fichier**, affichable dans Leaflet avec la bibliothèque `protomaps-leaflet`.
- Atout : permet de voir les pistes et sentiers **s'ils sont cartographiés dans OSM** (la complétude pour la forêt gabonaise n'est pas vérifiée ici et conditionne l'intérêt réel de ce fond).
- Taille à mesurer par une extraction d'essai ; je n'avance aucun chiffre.

## 4. Taille des paquets d'imagerie (estimation, hypothèse : 20 Ko par tuile satellite)
Hypothèses : emprise rectangulaire, niveaux de zoom 8 à N, tuiles carrées de 256 px ; les tuiles de bordure augmentent de 20 à 40 % le total pour une zone irrégulière.
| Surface | Zoom max 12 | Zoom max 13 | Zoom max 14 |
|---|---|---|---|
| 1 000 km² (petit parc) | ≈ 0,3 Mo | ≈ 1 Mo | ≈ 4 Mo |
| 5 000 km² | ≈ 1,4 Mo | ≈ 5,4 Mo | ≈ 22 Mo |
| 20 000 km² | ≈ 5 Mo | ≈ 22 Mo | ≈ 87 Mo |
| Gabon entier (≈ 267 700 km²) | ≈ 73 Mo | ≈ 291 Mo | ≈ 1,2 Go |
À vérifier sur un paquet réel : le poids moyen d'une tuile varie selon la compression et le relief. Conclusion pratique : **un parc entier tient sur un téléphone en quelques dizaines de Mo** ; le pays entier en zoom 13 reste raisonnable (< 0,5 Go).

## 5. Architecture recommandée (hybride, sans casser l'existant)
1. **Fabrication des paquets (nous, une fois, sur ordinateur)** : paquets MBTiles par parc/province à partir d'une source autorisée (A) ; PMTiles par zone (B). Chaque paquet reçoit un numéro de version, une taille, une empreinte SHA-256 et la mention de licence.
2. **Hébergement** : fichiers statiques sur un stockage nous appartenant (Supabase Storage, ou autre) + un `catalogue.json` listant zones, tailles, versions, empreintes. Pas de découpage à la demande dans une fonction Vercel (limites de taille et de durée) : on prépare les zones à l'avance.
3. **Téléchargement dans l'APK** : écran « Cartes hors ligne » (liste du catalogue, taille avant téléchargement, vérification de l'espace libre, progression, reprise après coupure, vérification SHA-256, suppression d'un paquet). Le téléchargement est réalisé par un service Android de premier plan, car il peut durer longtemps.
4. **Lecture hors ligne** : l'APK lit les paquets dans son stockage privé et les sert à la WebView comme des tuiles (`https://appassets.androidplatform.net/tiles/<zone>/{z}/{x}/{y}.jpg`) : un gestionnaire de requêtes natif interroge la base MBTiles (SQLite, intégré à Android). Leaflet n'a besoin que d'une couche supplémentaire.
5. **Affichage** : nouvelle couche « Hors ligne (zone téléchargée) » ajoutée à la carte existante par un module séparé, sans toucher à `index.html`. Bascule automatique conseillée quand il n'y a pas de réseau ; les fonds en ligne restent disponibles.
6. **GPS et traces** : position, points marqués, traces de mission et suivi continu (extension GPS en premier plan) s'affichent sur la couche hors ligne comme sur les fonds en ligne.
7. **Mentions** : attribution EOX et OpenStreetMap affichée sur la carte, comme l'exigent les licences.
8. **Aucune simulation** : une zone non téléchargée affiche « zone non disponible hors connexion », jamais une tuile inventée.

## 6. Plan en phases
| Phase | Contenu | Livrable | Sortie |
|---|---|---|---|
| C0 | Décision sur la source d'imagerie et la licence (message à EOX) ; extraction d'essai PMTiles d'un parc pour mesurer la taille et la couverture des pistes | note de licence + mesures | licence confirmée par écrit |
| C1 | Un paquet MBTiles d'un parc ; gestionnaire de tuiles natif ; couche « hors ligne » | diff séparé (module natif + module JS) | la zone s'affiche en mode avion sur le TECNO |
| C2 | Catalogue, téléchargeur avec reprise et SHA-256, écran de gestion des cartes | diff séparé | téléchargement interrompu puis repris, paquet vérifié |
| C3 | Fond vectoriel PMTiles (si C0 montre un intérêt) | diff séparé | pistes visibles hors ligne |
| C4 | Tous les parcs, mises à jour de versions, nettoyage | catalogue complet | essai en forêt |

## 7. Risques
- **Licence** (voir 2) : le plus important ; rien ne doit être téléchargé en masse avant la phase C0.
- **Résolution** : 10 m ne suffit pas pour naviguer sur des sentiers ; d'où le fond vectoriel B et, si besoin, une imagerie plus fine sous licence qui autorise l'usage hors ligne.
- **Stockage et coût des données** : téléchargement par parc, jamais le pays entier sans confirmation ; avertissement avant un téléchargement sur réseau mobile.
- **Mises à jour** : une carte hors ligne vieillit ; chaque paquet affiche sa date.
- **WebView** : la lecture de tuiles par un gestionnaire de requêtes natif est une technique standard, mais elle n'a pas été testée sur le téléphone cible.

## 8. Décisions demandées
1. Autorises-tu l'envoi d'une demande de licence à EOX (ou veux-tu la faire toi-même) ?
2. Quelles zones en premier (parc pilote) ?
3. Veux-tu aussi le fond vectoriel OSM (B) pour les pistes, après l'essai de mesure ?

## 9. Sources consultées (novembre 2026)
- Politique d'usage des tuiles OpenStreetMap : https://operations.osmfoundation.org/policies/tiles/ et https://operations.osmfoundation.org/policies/vector/
- EOxCloudless, licence : https://cloudless.eox.at/documentation/license ; produits « Viewing » (fichiers hors ligne) : https://cloudless.eox.at/products/viewing ; tarification et livraisons sur mesure : https://cloudless.eox.at/pricing
- Protomaps, démarrage et extraction : https://docs.protomaps.com/guide/getting-started
- Esri, FAQ sur le stockage de tuiles hors ligne (relayée sur le forum GeoNet) : https://geonet.esri.com/t5/arcgis-runtime-sdk-for-wpf-retired-questions/what-are-the-terms-of-use-for-bing-tpk-s/td-p/728399 ; discussion sur les conditions d'usage de World Imagery : https://community.esri.com/t5/arcgis-location-platform-developers-ques/inquiry-about-world-imagery/m-p/1569266
Limite : ces sources décrivent les conditions telles que publiées ; elles ne remplacent pas la lecture des textes contractuels ni un avis juridique.
