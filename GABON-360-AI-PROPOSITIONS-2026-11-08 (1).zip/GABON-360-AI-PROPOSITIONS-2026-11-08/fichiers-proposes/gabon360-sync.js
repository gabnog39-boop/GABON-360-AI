/* GABON 360 AI — Synchronisation différée (additif, désactivé par défaut).
   Activation : window.G360_OFFLINE_SYNC = true (voir gabon360-config.js).
   Principe : quand le téléphone n'a pas de réseau, une écriture (POST) vers les tables listées dans
   G360_SYNC_TABLES est conservée localement puis rejouée dans l'ordre au retour du réseau.
   Garanties et limites (voir PLAN) :
   - Aucune donnée n'est inventée ; l'élément en attente est visible (pastille « en attente »).
   - Le jeton de session est relu à chaque envoi depuis le stockage de l'application ; ce module ne
     renouvelle JAMAIS la session (le jeton de renouvellement tourne : le consommer ici pourrait
     déconnecter l'application). En cas de 401, la file est conservée et réessayée plus tard.
   - Une erreur définitive (400/403/404/409/422) place l'élément dans une file « refusés » conservée,
     sans bloquer la suite. Rien n'est supprimé silencieusement.
   - Doublon possible si la requête a atteint le serveur sans que la réponse revienne (coupure en cours
     d'envoi) : le schéma serveur n'offre pas de clé d'idempotence côté client. */
(function () {
  "use strict";
  var W = typeof window !== "undefined" ? window : globalThis;
  if (W.__G360_SYNC__) return;
  W.__G360_SYNC__ = true;

  var SB = "https://ztucadvgowsdixomoikm.supabase.co";
  var QKEY = "g360_sync_queue", FKEY = "g360_sync_failed", MAX = 500;
  var enabled = function () { return W.G360_OFFLINE_SYNC === true; };
  var tables = function () { return Array.isArray(W.G360_SYNC_TABLES) ? W.G360_SYNC_TABLES : ["evenements", "observations"]; };
  var store = function () { try { return W.localStorage; } catch (e) { return null; } };
  var read = function (k) { var s = store(); if (!s) return []; try { return JSON.parse(s.getItem(k)) || []; } catch (e) { return []; } };
  var write = function (k, v) { var s = store(); if (!s) return false; try { s.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };
  var online = function () { try { return W.navigator.onLine !== false; } catch (e) { return true; } };

  function targetTable(url, method) {
    if (String(method || "GET").toUpperCase() !== "POST") return null;
    var u = String(url || "");
    if (u.indexOf(SB + "/rest/v1/") !== 0) return null;
    var t = u.slice((SB + "/rest/v1/").length).split(/[?#]/)[0];
    return tables().indexOf(t) >= 0 ? t : null;
  }

  function badge() {
    try {
      var n = read(QKEY).length, d = W.document; if (!d || !d.body) return;
      var el = d.getElementById("g360-sync-badge");
      if (!n) { if (el) el.style.display = "none"; return; }
      if (!el) {
        el = d.createElement("div"); el.id = "g360-sync-badge";
        el.style.cssText = "position:fixed;left:12px;bottom:18px;z-index:9997;padding:6px 12px;border-radius:999px;background:#5a3b00;color:#fff;font:600 12px system-ui,sans-serif;border:1px solid #ffd27a";
        d.body.appendChild(el);
      }
      el.style.display = "block"; el.textContent = "⏳ " + n + " enregistrement(s) en attente d'envoi";
    } catch (e) {}
  }
  function emit() { try { W.dispatchEvent(new W.CustomEvent("g360:sync-state", { detail: { pending: read(QKEY).length, failed: read(FKEY).length } })); } catch (e) {} badge(); }

  function enqueue(url, opt) {
    var q = read(QKEY); if (q.length >= MAX) return false;
    q.push({ id: Date.now() + "-" + Math.random().toString(36).slice(2, 8), url: String(url), method: "POST", body: opt && opt.body != null ? String(opt.body) : null, prefer: (opt && opt.headers && (opt.headers.Prefer || opt.headers.prefer)) || "return=minimal", apikey: (opt && opt.headers && opt.headers.apikey) || "", at: new Date().toISOString() });
    if (!write(QKEY, q)) return false;
    emit(); return true;
  }

  var flushing = false;
  async function flush() {
    if (!enabled() || flushing || !online()) return { sent: 0, pending: read(QKEY).length };
    flushing = true; var sent = 0;
    try {
      var q = read(QKEY);
      while (q.length) {
        var it = q[0], tok = "";
        try { var s = JSON.parse(store().getItem("g360s")); tok = s && s.access_token || ""; } catch (e) {}
        if (!tok || !it.apikey) break;                                  // pas de session : on attend la connexion de l'utilisateur
        var r;
        try { r = await W.__g360RealFetch(it.url, { method: "POST", headers: { apikey: it.apikey, "Content-Type": "application/json", Authorization: "Bearer " + tok, Prefer: it.prefer }, body: it.body }); }
        catch (e) { break; }                              // réseau toujours indisponible
        if (r.ok) { q.shift(); write(QKEY, q); sent++; continue; }
        if (r.status === 401 || r.status === 408 || r.status === 429 || r.status >= 500) break;   // on réessaiera
        var f = read(FKEY); f.push(Object.assign({}, it, { status: r.status })); write(FKEY, f.slice(-200));
        q.shift(); write(QKEY, q);
      }
    } finally { flushing = false; emit(); }
    return { sent: sent, pending: read(QKEY).length };
  }

  W.__g360RealFetch = W.fetch ? W.fetch.bind(W) : null;
  if (W.__g360RealFetch) {
    W.fetch = function (url, opt) {
      var t = enabled() ? targetTable(url, opt && opt.method) : null;
      if (!t) return W.__g360RealFetch(url, opt);
      if (!online()) {
        if (enqueue(url, opt)) return Promise.resolve(new W.Response(null, { status: 202, headers: { "x-g360-queued": "1" } }));
        return W.__g360RealFetch(url, opt);
      }
      return W.__g360RealFetch(url, opt).catch(function (e) {
        if (e && e.name !== "AbortError" && enqueue(url, opt)) return new W.Response(null, { status: 202, headers: { "x-g360-queued": "1" } });
        throw e;
      });
    };
  }
  W.G360Sync = { flush: flush, pending: function () { return read(QKEY).length; }, failed: function () { return read(FKEY); }, enabled: enabled };
  if (W.addEventListener) {
    W.addEventListener("online", function () { flush(); });
    W.addEventListener("load", function () { emit(); flush(); });
    try { setInterval(function () { flush(); }, 60000); } catch (e) {}
  }
})();
