/* GABON 360 AI — configuration de l'adresse du serveur /api (Vercel).
   Dans l'APK, le site est embarqué (file://) : les routes /api/* n'existent pas localement.
   Pour les activer dans l'APK, renseignez ici l'adresse PUBLIQUE de votre déploiement, par exemple :
     window.G360_API_BASE = "https://votre-domaine.vercel.app";
   Laissée vide : l'application fonctionne sans ces routes (avatar en mode local, limites des parcs/frontières
   récupérées directement quand c'est possible). Ne mettez pas ici d'adresse protégée par connexion Vercel : elle refuserait les requêtes. */
window.G360_API_BASE = window.G360_API_BASE || "";

/* --- Ajouts APK hybride (valeurs par défaut sûres ; le build de l'APK peut les surcharger en amont) --- */
// Synchronisation différée des saisies faites hors réseau (voir gabon360-sync.js). Désactivée tant que non testée sur téléphone.
window.G360_OFFLINE_SYNC = (typeof window.G360_OFFLINE_SYNC === "boolean") ? window.G360_OFFLINE_SYNC : false;
window.G360_SYNC_TABLES = window.G360_SYNC_TABLES || ["evenements", "observations"];
