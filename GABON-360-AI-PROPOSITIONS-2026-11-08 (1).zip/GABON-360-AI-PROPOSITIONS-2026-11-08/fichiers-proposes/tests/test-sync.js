// Test unitaire Node de gabon360-sync.js (logique seulement : pas un test sur appareil).
const assert = require("assert"); const fs = require("fs"); const vm = require("vm");
const SB = "https://ztucadvgowsdixomoikm.supabase.co"; let ok = 0;
function make({ onLine = false, token = "T1", flag = true } = {}) {
  const mem = {}; if (token) mem.g360s = JSON.stringify({ access_token: token });
  const calls = []; let mode = "ok";
  const w = { localStorage: { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } },
    navigator: { onLine }, Response, CustomEvent: class { constructor(t, o) { this.type = t; this.detail = o && o.detail; } }, dispatchEvent() {},
    G360_OFFLINE_SYNC: flag, setInterval: () => 0, fetch: async (u, o) => { calls.push({ u, o }); if (mode === "net") throw new TypeError("Failed to fetch"); const st = typeof mode === "number" ? mode : 201; return new Response(null, { status: st }); } };
  w.window = w; vm.createContext(w); vm.runInContext(fs.readFileSync(__dirname + "/../gabon360-sync.js", "utf8"), w);
  return { w, mem, calls, setMode: m => { mode = m; } };
}
const t = async (n, f) => { await f(); ok++; console.log("OK  " + n); };
const post = (w, tb = "evenements") => w.fetch(SB + "/rest/v1/" + tb, { method: "POST", headers: { apikey: "PUB", "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify({ titre: "x" }) });
(async () => {
  await t("désactivé : aucune interception", async () => { const s = make({ flag: false }); const r = await post(s.w); assert.equal(r.status, 201); assert.equal(s.w.G360Sync.pending(), 0); });
  await t("hors ligne : mise en file + réponse 202 marquée", async () => { const s = make(); const r = await post(s.w); assert.equal(r.status, 202); assert.equal(r.headers.get("x-g360-queued"), "1"); assert.equal(s.w.G360Sync.pending(), 1); assert.equal(s.calls.length, 0); });
  await t("hors ligne : autre table et GET non interceptés", async () => { const s = make(); await post(s.w, "profiles"); await s.w.fetch(SB + "/rest/v1/evenements"); assert.equal(s.w.G360Sync.pending(), 0); assert.equal(s.calls.length, 2); });
  await t("en ligne + coupure réseau : mise en file", async () => { const s = make({ onLine: true }); s.setMode("net"); const r = await post(s.w); assert.equal(r.status, 202); assert.equal(s.w.G360Sync.pending(), 1); });
  await t("en ligne + erreur serveur 400 : transmise telle quelle (pas de file)", async () => { const s = make({ onLine: true }); s.setMode(400); const r = await post(s.w); assert.equal(r.status, 400); assert.equal(s.w.G360Sync.pending(), 0); });
  await t("retour réseau : envoi dans l'ordre avec jeton et clé", async () => { const s = make(); await post(s.w); await post(s.w, "observations"); s.w.navigator.onLine = true; s.calls.length = 0; const r = await s.w.G360Sync.flush(); assert.equal(r.sent, 2); assert.equal(s.calls[0].u, SB + "/rest/v1/evenements"); assert.equal(s.calls[1].u, SB + "/rest/v1/observations"); assert.equal(s.calls[0].o.headers.Authorization, "Bearer T1"); assert.equal(s.calls[0].o.headers.apikey, "PUB"); assert.equal(s.w.G360Sync.pending(), 0); });
  await t("401 : file conservée, aucun renouvellement de session", async () => { const s = make(); await post(s.w); s.w.navigator.onLine = true; s.setMode(401); s.calls.length = 0; const r = await s.w.G360Sync.flush(); assert.equal(r.sent, 0); assert.equal(s.w.G360Sync.pending(), 1); assert.equal(s.calls.length, 1); assert.ok(!s.calls.some(c => String(c.u).includes("/auth/v1/"))); });
  await t("422 : élément déplacé vers « refusés », suite non bloquée", async () => { const s = make(); await post(s.w); await post(s.w); s.w.navigator.onLine = true; s.setMode(422); await s.w.G360Sync.flush(); assert.equal(s.w.G360Sync.pending(), 0); assert.equal(s.w.G360Sync.failed().length, 2); });
  await t("sans session : on attend, rien n'est perdu", async () => { const s = make({ token: null }); await post(s.w); s.w.navigator.onLine = true; const r = await s.w.G360Sync.flush(); assert.equal(r.sent, 0); assert.equal(s.w.G360Sync.pending(), 1); });
  await t("plafond de 500 : au-delà, l'erreur réelle remonte", async () => { const s = make(); for (let i = 0; i < 500; i++) await post(s.w); assert.equal(s.w.G360Sync.pending(), 500); const r = await post(s.w); assert.equal(r.status, 201); });
  console.log("\nTests sync : " + ok + " réussis, 0 échoué");
})().catch(e => { console.error("ÉCHEC", e.message); process.exit(1); });
