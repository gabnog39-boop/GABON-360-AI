// GABON 360 AI — CORS explicite pour l APK hybride (interface embarquée -> API HTTPS).
// Origines autorisées : celles de la variable G360_ALLOWED_ORIGINS (séparées par des virgules),
// par défaut l origine interne de l APK. Aucune origine générique "*" : les routes /api utilisent
// un jeton de session (Authorization), donc on n autorise que des origines nommées.
const DEFAUT = ["https://appassets.androidplatform.net"];
const origines = () => (process.env.G360_ALLOWED_ORIGINS ? process.env.G360_ALLOWED_ORIGINS.split(",").map(s => s.trim()).filter(Boolean) : DEFAUT);
module.exports = function avecCors(handler) {
  return async function (req, res) {
    const o = req.headers && req.headers.origin;
    if (o && origines().includes(o)) {
      res.setHeader("Access-Control-Allow-Origin", o);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "Authorization,Content-Type");
      res.setHeader("Access-Control-Max-Age", "600");
    }
    if (req.method === "OPTIONS") return res.status(204).end();
    return handler(req, res);
  };
};
