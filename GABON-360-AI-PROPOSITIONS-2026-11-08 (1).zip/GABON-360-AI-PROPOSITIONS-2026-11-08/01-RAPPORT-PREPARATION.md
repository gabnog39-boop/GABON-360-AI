# GABON 360 AI — Préparation des corrections (avant toute modification) — révision 2

**Révision 2 du 8 novembre 2026 — ce qui a changé depuis la première version :**
- Tes décisions sont intégrées : adresse API `https://gabon-360-ai.vercel.app` (voir `03`), clé debug pour les essais et procédure de clé permanente séparée (voir `04`), synchronisation différée **désactivée** pour les premiers tests, cartes hors ligne voulues (voir `05`).
- Le workflow hybride (fichier n° 12) reçoit un **point d'extension générique** : il exécute les dossiers `android-ext/*/install.sh` s'ils existent. Grâce à lui, la dictée vocale native et le GPS en premier plan sont livrés en **deux diffs séparés (13 et 14) qui n'ajoutent que de nouveaux fichiers** : ils ne modifient aucun des 12 fichiers, et chacun peut être appliqué ou ignoré indépendamment.
- Vérification de conservation des originaux : voir `06` (tous les contrôles réussis).
- Les 12 fichiers restent 12 ; seul le fichier n° 12 a été révisé (ligne 12 du tableau).

Date : 8 novembre 2026 · Base : `GABON-360-AI-complet.zip` + deux JS de `correctifs-v2`
Statut : **PROPOSITION — rien n'est appliqué, rien n'est poussé sur GitHub.**

## 0. Ce qui a été vérifié, et ce qui ne l'a pas été

| Vérifié ici (exécuté) | Non vérifié (impossible ici) |
|---|---|
| Le patch combiné s'applique proprement sur une copie fraîche de `complet`, résultat identique à la proposition | Compilation Gradle / APK (pas de réseau, pas de SDK Android) |
| Syntaxe de tous les JS et du script inline de `index.html` (Node 22) | Compilation du Java généré (seulement : aucune erreur de syntaxe ; les types Android n'ont pas pu être résolus) |
| `tests/test-ia22.js` : 289 réussis, 0 échoué | Comportement sur téléphone (GPS, micro, voix, installation) |
| `tests/test-sync.js` (nouveau) : 10 réussis, 0 échoué | Comportement réel dans un navigateur / WebView |
| Étape « Contrôles préalables » du nouveau workflow exécutée en local : code retour 0 | Réponse CORS réelle de Vercel, réponse réelle de Supabase |
| YAML du nouveau workflow valide | Exécution du workflow sur GitHub Actions |

## 1. Fichiers à corriger

Aucun fichier existant n'est supprimé. Les 5 workflows d'origine, `android/`, `index-132.html`, les HTML de développement, les ZIP et `.corrompu` restent tels quels.

| # | Fichier | Type | Lignes | Pourquoi | Risque | Dépendance | Retour arrière |
|---|---|---|---|---|---|---|---|
| 1 | `gabon360-ia.js` | modifié | +2 −1 | Correctif v2 : l'observateur du DOM se déconnecte pendant son travail (boucle de gel) | Faible : 1 ligne, déjà éprouvé dans v2 | — | Rétablir la ligne d'origine |
| 2 | `gabon360-modules-addon.js` | modifié | +1 −1 | Correctif v2 : bouton « + Modules IA » compact (CSS) | Très faible : CSS seul | — | Idem |
| 3 | `gabon360-config.js` | modifié | +4 | Ajoute les drapeaux `G360_OFFLINE_SYNC` (faux par défaut) et `G360_SYNC_TABLES` | Faible : valeurs par défaut sans effet | Utilisé par #10 | Retirer 4 lignes |
| 4 | `index.html` | modifié | +1 −1 | Charge `gabon360-sync.js` après `ia22.js` (une seule balise ajoutée) | Faible : sans effet tant que le drapeau est faux | #10 doit exister | Retirer la balise |
| 5 | `api/_cors.js` | **nouveau** | +20 | CORS explicite : origine nommée uniquement, jamais `*` | Moyen : à tester réellement sur Vercel | Variable Vercel facultative `G360_ALLOWED_ORIGINS` | Supprimer le fichier + annuler #6–9 |
| 6 | `api/assistant.js` | modifié | +3 −2 | Enveloppe le handler avec le CORS (`avatar.js` en hérite) | Moyen : logique métier inchangée | #5 | Rétablir 2 lignes |
| 7 | `api/frontiere.js` | modifié | +3 −2 | Idem | Faible | #5 | Idem |
| 8 | `api/frontieres.js` | modifié | +3 −2 | Idem (fichier identique à #7) | Faible | #5 | Idem |
| 9 | `api/parcs.js` | modifié | +3 −2 | Idem | Faible | #5 | Idem |
| 10 | `gabon360-sync.js` | **nouveau** | +96 | Synchronisation différée des saisies hors réseau (tables `evenements`, `observations`) | Moyen : intercepte `fetch` pour ces POST ; **inactif tant que le drapeau est faux** | #3, #4 | Retirer la balise (#4) |
| 11 | `tests/test-sync.js` | **nouveau** | +27 | 10 tests unitaires de #10 | Nul | #10 | Supprimer |
| 12 | `.github/workflows/build-apk-hybride.yml` | **nouveau** | +359 | Workflow APK hybride, manuel, à côté de l'existant | Moyen : jamais exécuté | Variable de dépôt `G360_API_BASE` | Supprimer le fichier |

Décision 4 (logo + marge 17 %) : **déjà satisfaite dans `complet`** (logo de 39 772 octets, marge 17 % dans son workflow). Aucune correction nécessaire ; le nouveau workflow conserve cette marge. Le logo reste en 360×360 : suffisant pour un APK de test, flou en grand format.

Diffs : dossier `diffs/` (un fichier par correction, `TOUT.patch` combiné, et `COMPARATIF-workflow-existant-vers-hybride.patch`). Fichiers complets proposés : `fichiers-proposes/`.

## 2. Ce que fait le workflow hybride (par rapport à `build-apk-test.yml`)

| Sujet | Existant | Proposé |
|---|---|---|
| Déclenchement | push sur `test-avatar-central` + manuel | **Manuel seulement**, refusé si la branche est `main` ou `principal` |
| Droits | `contents: write` + création de release | `contents: read`, **artefact de build** (pas de release) |
| Gradle | non épinglé (`gradle` du runner) | **8.9** épinglé ; AGP 8.5.2 → **8.7.3** |
| Chargement de l'interface | `file:///android_asset/…` | `https://appassets.androidplatform.net/assets/…` (WebViewAssetLoader, `androidx.webkit:webkit:1.12.1`) |
| Accès fichiers WebView | `setAllowFileAccess(true)` | `false` (+ accès contenu `false`) |
| Trafic non chiffré | autorisé | **interdit** |
| Adresse API | aucune (vide) | **variable de dépôt `G360_API_BASE`, obligatoire, HTTPS**, injectée dans la copie d'`assets` seulement |
| Leaflet | chargé depuis jsDelivr (inutilisable sans réseau) | téléchargé au build, servi localement par l'APK |
| Géolocalisation / micro WebView | non gérés | autorisation accordée seulement à l'origine de l'APK et si la permission Android est accordée |
| Liens externes | s'ouvrent dans la WebView | s'ouvrent dans le navigateur du téléphone |
| Contrôles avant build | présence de 5 JS et du logo | syntaxe de tous les JS **et du script inline**, logo **décodable**, tests ia22 et sync |
| Contrôles après build | existence de l'APK | package, `versionCode`, permissions, présence des fichiers clés dans l'APK, SHA-256 |
| Identifiant de l'app | `gabon.gabon360`, v5 | **inchangé** (`gabon.gabon360`), v6 `0.6-hybride` : s'installe par-dessus la v5 si même signature |

Points d'extension ajoutés en révision 2 : la classe `MainActivity` du workflow charge par réflexion les classes facultatives `gabon.gabon360.ext.SttBridge` et `gabon.gabon360.ext.TrackBridge` **si elles existent** ; sans elles, rien ne change. Une étape « Extensions natives facultatives » exécute `android-ext/*/install.sh`, et les contrôles préalables vérifient la syntaxe et les tests de chaque extension.

Signature : le build produit un APK **debug** (signé par la clé debug du runner, différente à chaque exécution). Une installation par-dessus une version précédente peut donc être refusée ; il faudra désinstaller l'ancienne. Une clé de signature fixe est une décision à prendre (section 7).

## 3. Configuration recommandée

### Android
- `minSdk 23`, `compileSdk 35`, `targetSdk 35` (inchangés) ; AGP 8.7.3 ; Gradle 8.9 ; Java 17.
- Permissions : INTERNET, ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION, RECORD_AUDIO (inchangées).
- Interface embarquée dans `assets/site/`, origine `https://appassets.androidplatform.net`.
- Ponts natifs conservés : `AndroidGPS` (start, stop, available, last), `AndroidTTS` (speak, isReady).

### API (côté GitHub / Vercel — à créer par toi, rien n'est touché ici)
| Où | Nom | Valeur |
|---|---|---|
| GitHub → Settings → Variables (dépôt) | `G360_API_BASE` | `https://<ton-domaine-vercel-public>` sans chemin ; **pas** une URL protégée par connexion Vercel (elle refuserait les requêtes) |
| GitHub → Variables | `G360_OFFLINE_SYNC` | `false` pour les premiers essais ; `true` seulement après le test 6 de la section 5 |
| Vercel → Environment | `ANTHROPIC_API_KEY` | déjà requise pour l'IA serveur (inchangée) |
| Vercel → Environment | `G360_ALLOWED_ORIGINS` | facultative ; par défaut `https://appassets.androidplatform.net` |

Les données (alertes, missions, observations, rapports) passent **directement par Supabase** depuis l'application ; seules les routes `/api/avatar`, `/api/assistant`, `/api/parcs`, `/api/frontiere(s)` passent par Vercel.

## 4. Risques et limites connus (non corrigés par cette proposition)

1. **Reconnaissance vocale** : le code appelle `webkitSpeechRecognition`, que la WebView Android ne fournit en général pas. Le micro pour dicter à l'avatar est donc probablement inopérant dans l'APK. La voix de sortie (AndroidTTS) est séparée et peut fonctionner. Une correction fiable demande un pont natif `SpeechRecognizer` : proposition distincte à valider.
2. **Cartes hors ligne** : Leaflet sera embarqué, mais les **tuiles** (OpenStreetMap, ArcGIS, EOX) restent en ligne. Aucun cache de tuiles n'existe dans le code. « Carte hors ligne » n'est donc pas vrai tant qu'un module de tuiles pré-téléchargées n'existe pas.
3. **GPS en arrière-plan** : le suivi GPS est lié à l'écran de l'application ; il n'y a pas de service de premier plan. Écran éteint ou application en arrière-plan, l'enregistrement d'une trace en forêt peut s'arrêter. À tester ; correction probable (service de premier plan) à proposer séparément.
4. **Traces GPS** : aucune table serveur identifiée pour synchroniser des traces ; elles restent locales et exportables en GPX. La synchronisation différée ne couvre que les saisies d'`evenements` et d'`observations`.
5. **Doublons possibles** à la synchronisation si une requête atteint le serveur sans que la réponse revienne (pas de clé d'idempotence côté serveur connue).
6. **Service worker** : l'application tente de l'enregistrer en HTTPS ; `sw.js` n'est pas copié dans l'APK, l'échec est capturé par le code existant (simple avertissement dans la console).
7. **Supabase / CORS** : on suppose que Supabase accepte l'origine de l'APK (comportement par défaut) ; à vérifier au premier essai.
8. **Locus Map, DeLorme/inReach** : absents du code. Étude séparée : `02-ETUDE-LOCUS-INREACH.md`. Aucune simulation.

## 5. Plan de tests

### 5.1 Automatisés (déjà exécutés sur la proposition)
| Test | Résultat |
|---|---|
| `node --check` de tous les JS + script inline de `index.html` | OK |
| `tests/test-ia22.js` | 289 réussis, 0 échoué |
| `tests/test-sync.js` | 10 réussis, 0 échoué |
| Patch combiné sur copie fraîche de `complet` | applique proprement, identique |
| Logo décodable | OK (360×360) |

### 5.2 Sur téléphone (à faire après construction de l'APK)
Prérequis : APK construit par GitHub Actions, SHA-256 relevé, installation sur le TECNO.

**Test 1 — Démarrage et connexion.** L'application s'ouvre sans écran figé ; les champs e-mail/code répondent ; la connexion Supabase aboutit. *Critère :* aucune page blanche, aucun gel de plus de 3 secondes.

**Test 2 — Avatar central.** L'avatar s'affiche (logo officiel), le bouton de contrôle répond, un message passe par `via IA « … »`. *Critère :* chaque réponse vient de l'avatar, jamais d'une IA directement.

**Test 3 — Les 22 IA.** Pour chaque ligne : ouvrir la page, poser une question écrite, relever l'étiquette « via IA » et le mode (local ou serveur).

| IA | Page | Données lues | Critère de réussite |
|---|---|---|---|
| accueil | Accueil | alertes, missions, observations | synthèse chiffrée cohérente avec les listes |
| carte | Carte | alertes, observations | carte affichée, couches basculables |
| satellites | Satellites | — | source externe nommée « non reliée » si absente |
| drones | Drones | — | idem |
| navigation | Navigation terrain | missions | itinéraire/traces listés |
| geoloc | Géolocalisation | missions | position affichée après test GPS (5.3) |
| cyber | Cybersécurité | profiles | réponse sans fuite de données d'autres comptes |
| memoire | Mémoire territoriale | alertes, observations, missions | chronologie cohérente |
| alertes | Alertes | alertes | nombre égal à la liste |
| rapports | Rapports | rapports | nombre égal à la liste ; export PDF s'ouvre |
| stats | Statistiques | 4 sources | chiffres égaux aux listes |
| meteo | Météo | — | donnée réelle ou « indisponible », jamais inventée |
| parcs | Parcs nationaux | observations | 13 parcs affichés |
| eaux | Eaux et océan | observations | réponse cohérente |
| frontieres | Frontières | — | frontière affichée ou message d'indisponibilité |
| air | Espace aérien | — | source nommée « non reliée » si absente |
| centre | Centre national | alertes, missions, rapports | situation globale cohérente |
| admin | Administration | profiles | accès réservé au propriétaire |
| users | Utilisateurs | profiles | rôles/statuts modifiables selon droits |
| paiements | Paiements | — | statut « vérifié serveur », pas de faux succès |
| missions | Missions | missions | création/lecture ; export GPX |
| garmin | Garmin / GPX | missions, observations | import/export GPX ; aucune promesse de liaison directe |

Pour chaque IA, tester aussi : réponse en mode local (hors réseau) et, avec réseau et `ANTHROPIC_API_KEY`, mode serveur.

**Test 4 — Pages.** Parcourir les 8 vues natives (accueil, carte, alertes, missions, parcs, rapports, utilisateurs, Garmin/GPX) et les 12 modules du bouton « + Modules IA ». *Critère :* chaque page s'ouvre, le défilement fonctionne, le bouton flottant ne recouvre pas le bas de l'écran.

**Test 5 — API HTTPS explicite.** Avec réseau : `/api/parcs` et `/api/frontiere` répondent, l'avatar serveur répond. *Critère :* aucune erreur CORS dans la console distante ; sans `G360_API_BASE`, le build échoue (test négatif du workflow).

**Test 6 — Synchronisation différée** (si `G360_OFFLINE_SYNC=true`). Mode avion → saisir une alerte → pastille « en attente » → réseau rétabli → l'alerte apparaît côté serveur **une seule fois**. Tester aussi : session expirée (la file est conservée), puis reconnexion.

### 5.3 GPS
1. Première ouverture : demande de permission de localisation ; refus → message « Autorisation GPS refusée », pas de plantage.
2. Accord → `GPS satellite actif`, coordonnées qui évoluent en marchant, précision affichée.
3. Localisation du téléphone coupée → message « Active la localisation GPS du téléphone ».
4. **Mode avion** (GPS seul) en extérieur dégagé : la position continue d'arriver (c'est le test central « sans réseau »).
5. Enregistrement de points → compteur local → export GPX → fichier ouvrable dans une autre application.
6. Écran éteint 5 minutes puis rallumé : relever si la trace a des trous (limite n°3).
7. Rotation, retour arrière, fermeture/réouverture : pas de perte des points enregistrés.

### 5.4 Régression
Comparer, avant/après, sur la version actuellement installée : connexion, liste d'alertes, carte, rapport PDF, avatar vocal (voix de sortie), import GPX. Toute différence est un défaut à corriger avant diffusion.

## 6. Étapes proposées après ton autorisation (toutes réversibles)

1. Je te confirme la liste exacte des fichiers (section 1). Rien d'autre n'est touché.
2. Tu appliques `TOUT.patch` toi-même sur une **branche de test dédiée** (jamais `main`/`principal`), ou tu m'autorises à fournir un ZIP prêt à pousser.
3. Tu crées la variable `G360_API_BASE` (et `G360_OFFLINE_SYNC=false`).
4. Tu lances manuellement le workflow « hybride » depuis cette branche.
5. Tests 1 à 5, puis 6 si activé. Je corrige selon les résultats par petits diffs.
6. L'APK n'est déclaré prêt qu'avec : build réussi, SHA-256, contrôles `aapt2` positifs, tests du téléphone validés.

## 6 bis. Extensions séparées (révision 2) — diffs 13 et 14

| Diff | Contenu (nouveaux fichiers seulement) | Ce que ça apporte | Tests exécutés ici | Limites |
|---|---|---|---|---|
| `13-dictee-native.patch` | `SttBridge.java` (pont `SpeechRecognizer`), `gabon360-stt-native.js` (fournit `webkitSpeechRecognition` quand la WebView n'en a pas), `install.sh`, test | La dictée de `index.html` et de `gabon360-ia.js` fonctionne **sans modifier leur code** (même API : `lang`, `onstart`, `onresult`, `onerror`, `onend`) | 11 réussis | Dépend du service de reconnaissance vocale du téléphone (souvent Google) : s'il est absent, le message d'origine « dictée indisponible » reste affiché. La dictée peut exiger une connexion, sauf pack de langue hors ligne installé sur le téléphone. La 1re fois, l'autorisation micro est demandée : retoucher le micro après l'avoir accordée |
| `14-gps-premier-plan.patch` | `TrackService.java` (service de premier plan avec notification), `TrackBridge.java` (pont `AndroidTrack`), `gabon360-gps-bridge.js`, `install.sh`, test | Suivi GPS écran éteint ; les positions alimentent `g360:gps-fix` **et** `onPos()` de `index.html` : la mission de patrouille continue de tracer en arrière-plan ; bouton « Suivi continu écran éteint » dans la section Navigation forêt | 10 réussis | Ajoute les permissions `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_LOCATION`, `POST_NOTIFICATIONS` ; notification permanente pendant le suivi ; tampon local plafonné à 2 Mo ; **`AndroidGPS` existant reste inchangé** ; effet réel à valider sur le TECNO (économiseur de batterie, restrictions du constructeur) |

Vérifications faites : chaque diff s'applique seul et combiné aux 12 fichiers ; l'installation des deux extensions sur un projet Android simulé produit un manifeste XML valide, sans doublon au second passage ; aucune erreur de syntaxe Java (types Android non résolus faute de SDK : **non compilé**).

**Observation hors périmètre, non corrigée :** le `LocationListener` de `MainActivity` (code d'origine du workflow) n'implémente pas `onStatusChanged`, requis par Android antérieur à la version 11 ; sur un téléphone ancien, une `AbstractMethodError` est possible. L'extension 14 l'implémente pour son propre code. Correction du code d'origine proposée en diff séparé si tu le souhaites.

## 7. Décisions — état au 8 novembre 2026

| # | Décision | Réponse | Suite |
|---|---|---|---|
| 1 | Adresse API | `https://gabon-360-ai.vercel.app`, **sous réserve de vérification de la production** | `03` : page publique confirmée, qualité « production » à confirmer dans Vercel ; CORS à déployer d'abord sur une branche de test |
| 2 | Signature | Clé debug pour les premiers essais ; procédure de clé permanente séparée | `04` ; désinstaller l'APK précédent entre deux essais |
| 3 | Synchronisation différée | **Désactivée** pendant les premiers tests | Variable `G360_OFFLINE_SYNC=false` (valeur par défaut) |
| 4 | Dictée native, GPS premier plan | Propositions en diffs séparés | 13 et 14 (section 6 bis) |
| 5 | Cartes hors ligne | Oui, voulues | `05` : étude ; **la licence de téléchargement doit être réglée avant tout code** |

## 7 bis. Décisions encore à prendre (ancienne liste, pour mémoire)

1. **Adresse publique de l'API** (`G360_API_BASE`) : quel domaine Vercel de production ?
2. **Signature de l'APK** : rester en debug pour les essais, ou créer une clé de signature fixe (nécessaire pour mettre à jour par-dessus sans désinstaller et pour toute diffusion) ?
3. **Synchronisation différée** : l'activer dans les premiers APK d'essai, ou seulement après le test 6 ?
4. **Reconnaissance vocale native** et **service GPS de premier plan** : les inclure comme prochaines propositions ?
5. **Cartes hors ligne** : faut-il un module de tuiles pré-téléchargées (zones forestières) ? C'est un chantier à part.
