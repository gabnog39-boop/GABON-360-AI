/* GABON 360 AI — Dictée vocale native Android (extension facultative, APK uniquement).
   Fournit window.webkitSpeechRecognition / window.SpeechRecognition quand la WebView n'en a pas,
   en s'appuyant sur le pont natif AndroidSTT. Le code existant (index.html, gabon360-ia.js) n'est pas modifié :
   il utilise déjà SpeechRecognition (lang, interimResults, maxAlternatives, onstart, onresult, onerror, onend, start).
   Si le pont natif est absent ou le service de reconnaissance indisponible, rien n'est défini : le message
   d'origine « Dictée vocale indisponible » reste affiché. Rien n'est simulé. */
(function () {
  "use strict";
  var W = typeof window !== "undefined" ? window : globalThis;
  if (!W.AndroidSTT) return;
  if (W.SpeechRecognition || W.webkitSpeechRecognition) return;      // l'API du navigateur existe : on ne la remplace pas
  var ok = false;
  try { ok = !!W.AndroidSTT.available(); } catch (e) { ok = false; }
  if (!ok) return;

  var active = null;

  function result(text, fin) {
    var alt = { transcript: String(text), confidence: 0.9 };
    var r = [alt]; r.isFinal = !!fin; r.item = function (i) { return r[i]; };
    var rs = [r]; rs.item = function (i) { return rs[i]; };
    return { resultIndex: 0, results: rs };
  }
  function call(o, name, ev) { try { if (typeof o[name] === "function") o[name](ev); } catch (e) { try { console.warn("GABON 360 dictée :", e); } catch (x) {} } }
  function finish(o) { if (active !== o) return; active = null; if (!o._ended) { o._ended = true; call(o, "onend", { type: "end" }); } }

  W.__g360sttEvent = function (ev) {
    var o = active; if (!o || !ev) return;
    if (ev.type === "start") { if (!o._started) { o._started = true; call(o, "onstart", { type: "start" }); } }
    else if (ev.type === "result") { if (ev.final || o.interimResults) call(o, "onresult", result(ev.text || "", ev.final)); }
    else if (ev.type === "error") { call(o, "onerror", { type: "error", error: ev.error || "unknown" }); }
    else if (ev.type === "end") { finish(o); }
  };

  function G360SpeechRecognition() {
    this.lang = "fr-FR"; this.continuous = false; this.interimResults = false; this.maxAlternatives = 1;
    this.onstart = this.onresult = this.onerror = this.onend = null;
    this._ended = false; this._started = false;
  }
  G360SpeechRecognition.prototype.start = function () {
    var self = this;
    if (active && active !== self) { try { W.AndroidSTT.abort(); } catch (e) {} finish(active); }
    active = self; self._ended = false; self._started = false;
    var st = "";
    try { st = String(W.AndroidSTT.start(self.lang || "fr-FR", !!self.interimResults)); } catch (e) { st = "indisponible"; }
    if (st === "ok") return;
    var code = st === "permission" ? "not-allowed" : "service-not-allowed";   // « permission » : autorisation demandée, retoucher le micro
    call(self, "onerror", { type: "error", error: code });
    finish(self);
  };
  G360SpeechRecognition.prototype.stop = function () { try { W.AndroidSTT.stop(); } catch (e) {} };
  G360SpeechRecognition.prototype.abort = function () { var o = this; try { W.AndroidSTT.abort(); } catch (e) {} finish(o); };

  W.webkitSpeechRecognition = G360SpeechRecognition;
  W.SpeechRecognition = G360SpeechRecognition;
  W.__G360_STT_NATIF__ = true;
})();
