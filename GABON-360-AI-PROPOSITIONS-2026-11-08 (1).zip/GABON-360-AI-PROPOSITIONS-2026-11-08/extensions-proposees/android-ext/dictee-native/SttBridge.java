package gabon.gabon360.ext;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.util.ArrayList;
import org.json.JSONObject;

/** Dictée vocale native : expose SpeechRecognizer à la page sous le nom « AndroidSTT ». Extension facultative. */
public class SttBridge {
    public static final String JS_NAME = "AndroidSTT";
    private final Activity act;
    private final WebView web;
    private SpeechRecognizer rec;

    public SttBridge(Activity a, WebView w) { act = a; web = w; }

    @JavascriptInterface public boolean available() { return SpeechRecognizer.isRecognitionAvailable(act); }

    /** Retourne « ok », « permission » (autorisation micro demandée : retoucher le micro) ou « indisponible ». */
    @JavascriptInterface public String start(final String lang, final boolean interim) {
        if (!SpeechRecognizer.isRecognitionAvailable(act)) return "indisponible";
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            act.runOnUiThread(() -> act.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 3602));
            return "permission";
        }
        act.runOnUiThread(() -> begin(lang, interim));
        return "ok";
    }

    @JavascriptInterface public void stop() { act.runOnUiThread(() -> { if (rec != null) rec.stopListening(); }); }

    @JavascriptInterface public void abort() { act.runOnUiThread(() -> { destroyNow(); }); }

    private void destroyNow() {
        if (rec != null) { try { rec.cancel(); rec.destroy(); } catch (Exception e) { } rec = null; }
    }

    private void begin(String lang, boolean interim) {
        destroyNow();
        rec = SpeechRecognizer.createSpeechRecognizer(act);
        rec.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { emit("start", null, false, null); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float v) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int t, Bundle p) { }
            @Override public void onError(int code) { emit("error", null, false, mapError(code)); finish(); }
            @Override public void onResults(Bundle b) {
                String t = first(b);
                if (t != null) emit("result", t, true, null);
                else emit("error", null, false, "no-speech");
                finish();
            }
            @Override public void onPartialResults(Bundle b) {
                String t = first(b);
                if (t != null) emit("result", t, false, null);
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, (lang == null || lang.isEmpty()) ? "fr-FR" : lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, interim);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        rec.startListening(i);
    }

    private static String first(Bundle b) {
        ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (l != null && !l.isEmpty()) ? l.get(0) : null;
    }

    private static String mapError(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
            case SpeechRecognizer.ERROR_NO_MATCH: return "no-speech";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
            case SpeechRecognizer.ERROR_SERVER: return "network";
            case SpeechRecognizer.ERROR_AUDIO: return "audio-capture";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "not-allowed";
            case SpeechRecognizer.ERROR_CLIENT:
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "aborted";
            default: return "unknown";
        }
    }

    private void finish() {
        emit("end", null, false, null);
        act.runOnUiThread(() -> destroyNow());
    }

    private void emit(String type, String text, boolean fin, String err) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            if (text != null) o.put("text", text);
            o.put("final", fin);
            if (err != null) o.put("error", err);
            final String js = "window.__g360sttEvent&&window.__g360sttEvent(" + o.toString() + ")";
            act.runOnUiThread(() -> web.evaluateJavascript(js, null));
        } catch (Exception e) { }
    }
}
