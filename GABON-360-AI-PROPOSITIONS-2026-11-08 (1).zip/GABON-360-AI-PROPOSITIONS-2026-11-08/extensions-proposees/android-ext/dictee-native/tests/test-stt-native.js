// Test unitaire Node de gabon360-stt-native.js (logique du shim seulement : pas un test sur appareil).
const assert = require("assert"), fs = require("fs"), vm = require("vm");
const SRC = fs.readFileSync(__dirname + "/../gabon360-stt-native.js", "utf8"); let ok = 0;
function make({ bridge = true, available = true, native = false, startReturn = "ok" } = {}) {
  const log = [];
  const w = {};
  if (bridge) w.AndroidSTT = { available: () => available, start: (l, i) => { log.push(["start", l, i]); return startReturn; }, stop: () => log.push(["stop"]), abort: () => log.push(["abort"]) };
  if (native) w.webkitSpeechRecognition = function Natif() {};
  w.console = console; w.window = w; vm.createContext(w); vm.runInContext(SRC, w);
  return { w, log };
}
const t = (n, f) => { f(); ok++; console.log("OK  " + n); };
t("pont absent : rien n'est défini", () => { const s = make({ bridge: false }); assert.equal(s.w.webkitSpeechRecognition, undefined); });
t("service indisponible : rien n'est défini", () => { const s = make({ available: false }); assert.equal(s.w.webkitSpeechRecognition, undefined); });
t("API navigateur déjà présente : non remplacée", () => { const s = make({ native: true }); assert.equal(s.w.webkitSpeechRecognition.name, "Natif"); assert.equal(s.w.SpeechRecognition, undefined); });
t("pont disponible : API définie sous les deux noms", () => { const s = make(); assert.equal(typeof s.w.webkitSpeechRecognition, "function"); assert.equal(s.w.SpeechRecognition, s.w.webkitSpeechRecognition); });
t("cycle complet comme dans index.html (onstart, onresult, onend)", () => {
  const s = make(), ev = []; const r = new s.w.webkitSpeechRecognition(); r.lang = "fr-FR";
  r.onstart = () => ev.push("start"); r.onresult = e => ev.push("res:" + e.results[0][0].transcript + ":" + e.results[0].isFinal); r.onend = () => ev.push("end"); r.onerror = e => ev.push("err:" + e.error);
  r.start(); assert.deepEqual(s.log[0], ["start", "fr-FR", false]);
  s.w.__g360sttEvent({ type: "start" }); s.w.__g360sttEvent({ type: "result", text: "combien d'alertes", final: true }); s.w.__g360sttEvent({ type: "end" }); s.w.__g360sttEvent({ type: "end" });
  assert.deepEqual(ev, ["start", "res:combien d'alertes:true", "end"]);
});
t("résultat partiel ignoré si interimResults=false, transmis sinon", () => {
  const s = make(); let n = 0; const r = new s.w.webkitSpeechRecognition(); r.onresult = () => n++; r.start();
  s.w.__g360sttEvent({ type: "result", text: "co", final: false }); assert.equal(n, 0);
  const r2 = new s.w.webkitSpeechRecognition(); r2.interimResults = true; r2.onresult = () => n++; r2.start(); s.w.__g360sttEvent({ type: "result", text: "co", final: false }); assert.equal(n, 1);
});
t("erreur native : onerror puis onend, code web standard", () => {
  const s = make(), ev = []; const r = new s.w.webkitSpeechRecognition(); r.onerror = e => ev.push(e.error); r.onend = () => ev.push("end"); r.start();
  s.w.__g360sttEvent({ type: "error", error: "network" }); s.w.__g360sttEvent({ type: "end" }); assert.deepEqual(ev, ["network", "end"]);
});
t("permission demandée : onerror not-allowed puis onend (aucun faux résultat)", () => {
  const s = make({ startReturn: "permission" }), ev = []; const r = new s.w.webkitSpeechRecognition(); r.onerror = e => ev.push(e.error); r.onresult = () => ev.push("res"); r.onend = () => ev.push("end"); r.start(); assert.deepEqual(ev, ["not-allowed", "end"]);
});
t("service indisponible au démarrage : service-not-allowed", () => {
  const s = make({ startReturn: "indisponible" }), ev = []; const r = new s.w.webkitSpeechRecognition(); r.onerror = e => ev.push(e.error); r.start(); assert.deepEqual(ev, ["service-not-allowed"]);
});
t("stop et abort relayés au pont ; abort termine", () => {
  const s = make(), ev = []; const r = new s.w.webkitSpeechRecognition(); r.onend = () => ev.push("end"); r.start(); r.stop(); r.abort();
  assert.deepEqual(s.log.map(x => x[0]), ["start", "stop", "abort"]); assert.deepEqual(ev, ["end"]);
});
t("événement natif sans reconnaissance active : ignoré sans erreur", () => { const s = make(); s.w.__g360sttEvent({ type: "result", text: "x", final: true }); });
console.log("\nTests dictée native : " + ok + " réussis, 0 échoué");
