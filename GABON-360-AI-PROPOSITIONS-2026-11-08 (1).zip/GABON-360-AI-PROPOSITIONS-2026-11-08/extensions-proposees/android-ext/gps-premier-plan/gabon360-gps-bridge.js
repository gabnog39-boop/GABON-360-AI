/* GABON 360 AI — GPS en premier plan Android (extension facultative, APK uniquement).
   S'ajoute à AndroidGPS (inchangé). Les positions du service natif sont reversées :
   1) dans l'événement existant « g360:gps-fix » (navigation forêt, connecteurs) ;
   2) dans onPos() de index.html, si présent, pour que le suivi de mission continue écran éteint
      (onPos ignore déjà les positions trop imprécises ou trop proches : pas de doublon avec watchPosition).
   Sans pont natif AndroidTrack, ce fichier ne fait rien. Aucune position n'est inventée. */
(function () {
  "use strict";
  var W = typeof window !== "undefined" ? window : globalThis;
  if (!W.AndroidTrack) return;
  var T = W.AndroidTrack, timer = null;

  function parse(txt) {
    var out = [];
    String(txt || "").split("\n").forEach(function (l) {
      if (!l) return;
      var p = l.split(",").map(Number);
      if (p.length < 6 || !isFinite(p[0]) || !isFinite(p[1]) || Math.abs(p[0]) > 90 || Math.abs(p[1]) > 180) return;
      out.push({ lat: p[0], lon: p[1], accuracy: p[2], speed: p[3], altitude: p[4], time: p[5] });
    });
    return out;
  }
  function deliver(f) {
    try { W.dispatchEvent(new W.CustomEvent("g360:gps-fix", { detail: { lat: f.lat, lon: f.lon, accuracy: f.accuracy, speed: f.speed, altitude: f.altitude, time: f.time } })); } catch (e) {}
    if (typeof W.onPos === "function") {
      try { W.onPos({ coords: { latitude: f.lat, longitude: f.lon, accuracy: f.accuracy, speed: f.speed, altitude: f.altitude }, timestamp: f.time }); } catch (e) {}
    }
  }
  function pump() { var txt = ""; try { txt = T.drain() || ""; } catch (e) { return 0; } var fixes = parse(txt); fixes.forEach(deliver); return fixes.length; }
  function status(ok, msg) { try { W.dispatchEvent(new W.CustomEvent("g360:gps-status", { detail: { ok: ok, message: msg } })); } catch (e) {} }
  function loop() { if (!timer) timer = setInterval(pump, 3000); }

  var api = {
    start: function (opts) {
      var reset = !(opts && opts.reset === false), st = "";
      try { st = String(T.start(reset)); } catch (e) { st = "indisponible"; }
      if (st === "ok") { loop(); status(true, "Suivi GPS continu actif (fonctionne écran éteint)"); return true; }
      status(false, st === "permission" ? "Autorisation de localisation demandée : relancez le suivi continu après l'avoir accordée" : "Suivi GPS continu indisponible");
      return false;
    },
    stop: function () { try { T.stop(); } catch (e) {} pump(); if (timer) { clearInterval(timer); timer = null; } status(false, "Suivi GPS continu arrêté"); },
    active: function () { try { return !!T.active(); } catch (e) { return false; } },
    pump: pump
  };
  W.G360Track = api;

  if (W.document && W.document.addEventListener) W.document.addEventListener("visibilitychange", function () { if (W.document.visibilityState === "visible" && api.active()) pump(); });
  if (api.active()) loop();                                        // reprise après rechargement de la page

  // Bouton dans la section « Navigation forêt » (créée par gabon360-navigation-offline.js) : recherche sans observateur du DOM.
  var essais = 0, poll = setInterval(function () {
    essais++;
    var root = W.document && W.document.getElementById("g360-offline-nav");
    if (root && !W.document.getElementById("g360-track-btn")) {
      var b = W.document.createElement("button"); b.id = "g360-track-btn"; b.type = "button";
      b.style.cssText = "margin-top:8px;padding:10px 14px;border-radius:10px;border:1px solid #48d8b1;background:#073a38;color:#fff;font-weight:700";
      var maj = function () { b.textContent = api.active() ? "Arrêter le suivi continu (écran éteint)" : "Suivi continu écran éteint"; };
      b.onclick = function () { if (api.active()) api.stop(); else api.start(); setTimeout(maj, 400); };
      maj(); root.appendChild(b);
    }
    if ((root && W.document.getElementById("g360-track-btn")) || essais > 60) clearInterval(poll);
  }, 2000);
})();
