package gabon.gabon360.ext;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/** Pont « AndroidTrack » : suivi GPS continu (écran éteint). S'ajoute à AndroidGPS, ne le remplace pas. */
public class TrackBridge {
    public static final String JS_NAME = "AndroidTrack";
    private static final int PAR_LOT = 5000;
    private final Activity act;

    public TrackBridge(Activity a, WebView w) { act = a; }

    /** Retourne « ok » ou « permission » (autorisation de localisation demandée : relancer ensuite). */
    @JavascriptInterface public String start(final boolean reset) {
        if (act.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            act.runOnUiThread(() -> act.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 3601));
            return "permission";
        }
        if (Build.VERSION.SDK_INT >= 33 && act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            act.runOnUiThread(() -> act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3604));   // non bloquant
        }
        if (reset && !TrackService.running) vider();
        act.runOnUiThread(() -> {
            Intent i = new Intent(act, TrackService.class);
            if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i); else act.startService(i);
        });
        return "ok";
    }

    @JavascriptInterface public void stop() { act.runOnUiThread(() -> act.stopService(new Intent(act, TrackService.class))); }

    @JavascriptInterface public boolean active() { return TrackService.running; }

    /** Retourne jusqu'à 5000 positions « lat,lon,précision,vitesse,altitude,heure » (une par ligne) et les retire du tampon. */
    @JavascriptInterface public String drain() {
        synchronized (TrackService.LOCK) {
            File f = TrackService.fichier(act);
            if (!f.exists()) return "";
            StringBuilder sortie = new StringBuilder(), reste = new StringBuilder();
            int n = 0;
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String ligne;
                while ((ligne = r.readLine()) != null) {
                    if (n < PAR_LOT) { sortie.append(ligne).append('\n'); n++; } else { reste.append(ligne).append('\n'); }
                }
            } catch (IOException e) { return ""; }
            try (FileWriter w = new FileWriter(f, false)) { w.write(reste.toString()); } catch (IOException e) { }
            return sortie.toString();
        }
    }

    private void vider() {
        synchronized (TrackService.LOCK) { TrackService.fichier(act).delete(); }
    }
}
