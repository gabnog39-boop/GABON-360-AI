#!/usr/bin/env bash
# Extension « GPS en premier plan » : exécutée par le workflow build-apk-hybride.yml (étape « Extensions natives facultatives »).
# Ne modifie aucun fichier du dépôt : n'agit que sur le projet Android temporaire (variable ANDROID_PROJECT).
set -euo pipefail
D="$(cd "$(dirname "$0")" && pwd)"
P="${ANDROID_PROJECT:?ANDROID_PROJECT non défini}"
J="$P/app/src/main/java/gabon/gabon360/ext"; A="$P/app/src/main/assets/site"; M="$P/app/src/main/AndroidManifest.xml"
test -f "$A/index.html" && test -f "$M"
mkdir -p "$J"
cp "$D/TrackService.java" "$J/TrackService.java"
cp "$D/TrackBridge.java" "$J/TrackBridge.java"
cp "$D/gabon360-gps-bridge.js" "$A/gabon360-gps-bridge.js"
python3 - "$A/index.html" "$M" <<'PY'
import sys
idx, man = sys.argv[1], sys.argv[2]
h = open(idx, encoding="utf-8").read()
tag = '<script src="./gabon360-gps-bridge.js"></script>'
anchor = '<script src="./gabon360-sync.js"></script>'
if tag not in h:
    assert h.count(anchor) == 1, "ancre gabon360-sync.js introuvable ou multiple dans index.html"
    h = h.replace(anchor, anchor + tag)
    open(idx, "w", encoding="utf-8").write(h)
m = open(man, encoding="utf-8").read()
perms = ""
for p in ("FOREGROUND_SERVICE", "FOREGROUND_SERVICE_LOCATION", "POST_NOTIFICATIONS"):
    if "android.permission." + p not in m:
        perms += '<uses-permission android:name="android.permission.%s" />\n    ' % p
if perms:
    assert m.count("<application") == 1
    m = m.replace("<application", perms + "<application", 1)
if "ext.TrackService" not in m:
    assert m.count("</application>") == 1
    m = m.replace("</application>", '<service android:name=".ext.TrackService" android:exported="false" android:foregroundServiceType="location" />\n    </application>', 1)
open(man, "w", encoding="utf-8").write(m)
print("Extension GPS en premier plan installée.")
PY
