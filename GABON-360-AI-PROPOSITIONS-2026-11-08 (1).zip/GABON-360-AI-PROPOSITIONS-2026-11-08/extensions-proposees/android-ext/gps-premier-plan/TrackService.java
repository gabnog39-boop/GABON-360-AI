package gabon.gabon360.ext;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import gabon.gabon360.MainActivity;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/** Suivi GPS en service de premier plan (notification permanente). Extension facultative.
 *  Chaque position est ajoutée à un tampon local (fichier) : rien n'est perdu si la page est suspendue. */
public class TrackService extends Service {
    static final String CHANNEL = "g360_track";
    static final String BUFFER = "g360_track_buffer.csv";
    static final long MAX_OCTETS = 2_000_000L;
    static final Object LOCK = new Object();
    static volatile boolean running = false;
    private LocationManager lm;

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location l) { append(getApplicationContext(), l); }
        @Override public void onProviderEnabled(String p) { }
        @Override public void onProviderDisabled(String p) { }
        @Override public void onStatusChanged(String p, int s, Bundle b) { }   // requis par Android < 11
    };

    static File fichier(Context c) { return new File(c.getFilesDir(), BUFFER); }

    static void append(Context c, Location l) {
        synchronized (LOCK) {
            try {
                File f = fichier(c);
                if (f.length() > MAX_OCTETS) {                      // plafond : l'ancien tampon est mis de côté (un seul exemplaire)
                    File old = new File(c.getFilesDir(), BUFFER + ".old");
                    old.delete();
                    f.renameTo(old);
                }
                try (FileWriter w = new FileWriter(f, true)) {
                    w.write(l.getLatitude() + "," + l.getLongitude() + "," + l.getAccuracy() + "," + l.getSpeed() + "," + l.getAltitude() + "," + l.getTime() + "\n");
                }
            } catch (IOException e) { }
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Suivi GPS de patrouille", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Intent ouvrir = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, ouvrir, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        b.setContentTitle("GABON 360 AI").setContentText("Suivi GPS de patrouille actif").setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).setContentIntent(pi);
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        else startForeground(1001, n);
        try {
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 1f, listener, Looper.getMainLooper());
            running = true;
        } catch (SecurityException e) {                              // permission retirée : on s'arrête proprement
            running = false;
            stopSelf();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        if (lm != null) { try { lm.removeUpdates(listener); } catch (Exception e) { } }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
