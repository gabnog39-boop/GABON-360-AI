// Test unitaire Node de gabon360-gps-bridge.js (logique du shim seulement : pas un test sur appareil).
const assert = require("assert"), fs = require("fs"), vm = require("vm");
const SRC = fs.readFileSync(__dirname + "/../gabon360-gps-bridge.js", "utf8"); let ok = 0;
function make({ bridge = true, buffer = "", startReturn = "ok", withOnPos = true } = {}) {
  const ev = [], pos = [], timers = []; let buf = buffer, running = false;
  const w = { console, CustomEvent: class { constructor(t, o) { this.type = t; this.detail = o && o.detail; } }, dispatchEvent: e => ev.push(e),
    setInterval: (f, ms) => { timers.push({ f, ms }); return timers.length; }, clearInterval: i => { if (timers[i - 1]) timers[i - 1].dead = true; }, setTimeout: () => 0,
    document: { addEventListener() {}, getElementById: () => null, visibilityState: "visible" } };
  if (bridge) w.AndroidTrack = { start: r => { w.__resetArg = r; if (startReturn === "ok") running = true; return startReturn; }, stop: () => { running = false; }, active: () => running, drain: () => { const b = buf; buf = ""; return b; } };
  if (withOnPos) w.onPos = p => pos.push(p);
  w.window = w; vm.createContext(w); vm.runInContext(SRC, w);
  return { w, ev, pos, timers, push: s => { buf += s; } };
}
const t = (n, f) => { f(); ok++; console.log("OK  " + n); };
t("pont absent : rien n'est défini", () => { const s = make({ bridge: false }); assert.equal(s.w.G360Track, undefined); });
t("pont présent : API G360Track exposée, AndroidGPS non touché", () => { const s = make(); assert.equal(typeof s.w.G360Track.start, "function"); assert.equal(s.w.AndroidGPS, undefined); });
t("démarrage ok : réinitialisation par défaut, statut positif, boucle de lecture", () => {
  const s = make(); assert.equal(s.w.G360Track.start(), true); assert.equal(s.w.__resetArg, true);
  assert.ok(s.ev.some(e => e.type === "g360:gps-status" && e.detail.ok)); assert.ok(s.timers.some(x => x.ms === 3000));
});
t("start({reset:false}) conserve le tampon", () => { const s = make(); s.w.G360Track.start({ reset: false }); assert.equal(s.w.__resetArg, false); });
t("permission demandée : pas de boucle, message clair, retour faux", () => {
  const s = make({ startReturn: "permission" }); assert.equal(s.w.G360Track.start(), false);
  assert.ok(!s.timers.some(x => x.ms === 3000)); assert.ok(s.ev.some(e => e.type === "g360:gps-status" && !e.detail.ok && /Autorisation/.test(e.detail.message)));
});
t("lecture : positions reversées dans g360:gps-fix ET onPos", () => {
  const s = make({ buffer: "0.391,9.454,12.5,0.8,25,1760000000000\n0.392,9.455,10,1.1,26,1760000002000\n" }); const n = s.w.G360Track.pump();
  assert.equal(n, 2); const fx = s.ev.filter(e => e.type === "g360:gps-fix"); assert.equal(fx.length, 2);
  assert.equal(fx[0].detail.lat, 0.391); assert.equal(fx[0].detail.time, 1760000000000); assert.equal(s.pos.length, 2);
  assert.equal(s.pos[1].coords.latitude, 0.392); assert.equal(s.pos[1].timestamp, 1760000002000); assert.equal(s.pos[0].coords.accuracy, 12.5);
});
t("lignes invalides ignorées (rien d'inventé)", () => {
  const s = make({ buffer: "abc\n1,2,3\n95,9,10,1,1,5\n0.4,9.4,8,0.5,20,1760000005000\n\n" }); assert.equal(s.w.G360Track.pump(), 1);
});
t("onPos absent : seul l'événement est émis, sans erreur", () => { const s = make({ withOnPos: false, buffer: "0.4,9.4,8,0.5,20,1760000005000\n" }); assert.equal(s.w.G360Track.pump(), 1); assert.equal(s.pos.length, 0); });
t("onPos qui échoue : n'interrompt pas la lecture", () => {
  const s = make({ buffer: "0.4,9.4,8,0.5,20,1\n0.5,9.5,8,0.5,20,2\n" }); s.w.onPos = () => { throw new Error("x"); }; assert.equal(s.w.G360Track.pump(), 2);
});
t("arrêt : dernière lecture puis boucle stoppée", () => {
  const s = make({ buffer: "0.4,9.4,8,0.5,20,1\n" }); s.w.G360Track.start(); s.push("0.5,9.5,8,0.5,20,2\n"); s.w.G360Track.stop();
  assert.equal(s.ev.filter(e => e.type === "g360:gps-fix").length, 2); assert.ok(s.timers.find(x => x.ms === 3000).dead); assert.equal(s.w.G360Track.active(), false);
});
console.log("\nTests GPS premier plan : " + ok + " réussis, 0 échoué");
