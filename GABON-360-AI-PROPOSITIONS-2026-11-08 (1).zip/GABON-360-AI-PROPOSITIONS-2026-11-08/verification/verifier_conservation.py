#!/usr/bin/env python3
"""Vérifie que les propositions GABON 360 AI conservent les fichiers d'origine et ne remplacent aucune fonction existante.
Usage : python3 verifier_conservation.py <archive_originale.zip> <dossier_propositions> > resultat.md
Lecture seule sur l'archive ; tout le travail se fait dans un dossier temporaire."""
import sys, os, re, zipfile, hashlib, subprocess, tempfile, shutil, glob

ZIP, PROP = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])   # chemins absolus : le script change de dossier de travail
tmp = tempfile.mkdtemp(prefix="g360v_")
out = []
def p(s=""): out.append(s)
def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()
def sh(cmd, cwd=None):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True); return r.returncode, (r.stdout + r.stderr)
bad = []
def check(ok, msg):
    p(("- ✅ " if ok else "- ❌ ") + msg)
    if not ok: bad.append(msg)

p("# Vérification de conservation des fichiers d'origine"); p()
p("## A. Archive d'origine (lecture seule)"); p()
p("- Fichier : `%s`" % os.path.basename(ZIP)); p("- SHA-256 : `%s`" % sha(ZIP)); p("- Taille : %d octets" % os.path.getsize(ZIP))
z = zipfile.ZipFile(ZIP); names = [n for n in z.namelist()]
check(z.testzip() is None, "intégrité de l'archive principale (CRC de toutes les entrées) : correcte")
check(len(names) == 155, "%d entrées (155 attendues)" % len(names))
root = os.path.join(tmp, "orig"); z.extractall(root)
top = os.path.join(root, "GABON-360-AI-test-avatar-central")
inner = sorted(glob.glob(top + "/*.zip"))
check(len(inner) == 6, "%d ZIP internes (6 attendus)" % len(inner))
for i in inner:
    zi = zipfile.ZipFile(i); p("  - `%s` : %d entrées, %s, SHA-256 `%s`" % (os.path.basename(i), len(zi.namelist()), "intègre" if zi.testzip() is None else "CORROMPU", sha(i)[:16] + "…"))
complet = [i for i in inner if i.endswith("GABON-360-AI-complet.zip")][0]
base = os.path.join(tmp, "base"); zipfile.ZipFile(complet).extractall(base)
base = os.path.join(base, "GABON-360-AI-test-avatar-central")

p(); p("## B. Application des propositions sur une copie de « complet »"); p()
work = os.path.join(tmp, "apres"); shutil.copytree(base, work)
for pt in ["TOUT-12-FICHIERS.patch", "13-dictee-native.patch", "14-gps-premier-plan.patch"]:
    rc, o = sh("patch -p1 -s < '%s'" % os.path.join(PROP, "diffs", pt), cwd=work)
    check(rc == 0, "`%s` s'applique sans rejet" % pt)

def files(d):
    r = {}
    for dp, _, fs in os.walk(d):
        for f in fs:
            fp = os.path.join(dp, f); r[os.path.relpath(fp, d)] = fp
    return r
fb, fa = files(base), files(work)
removed = sorted(set(fb) - set(fa)); added = sorted(set(fa) - set(fb))
changed = sorted(f for f in fb if f in fa and sha(fb[f]) != sha(fa[f]))
same = [f for f in fb if f in fa and f not in changed]
check(not removed, "aucun fichier supprimé (%d fichiers d'origine, tous encore présents)" % len(fb))
check(len(changed) == 8, "%d fichiers existants modifiés (8 attendus) : %s" % (len(changed), ", ".join("`%s`" % c for c in changed)))
p("- %d fichiers existants strictement identiques (même SHA-256)" % len(same))
p("- %d fichiers ajoutés :" % len(added))
for a in added: p("  - `%s`" % a)
expected_added_prefix = ("android-ext/",)
other_added = [a for a in added if not a.startswith(expected_added_prefix) and a not in ("api/_cors.js", "gabon360-sync.js", "tests/test-sync.js", ".github/workflows/build-apk-hybride.yml")]
check(not other_added, "aucun ajout inattendu hors des 4 nouveaux fichiers des 12 et du dossier `android-ext/`")
wf = [f for f in fb if f.startswith(".github/workflows/")]
check(all(f in same for f in wf), "les %d workflows d'origine (%s) sont inchangés" % (len(wf), ", ".join(os.path.basename(f) for f in wf)))
check(all(f in same for f in fb if f.startswith("android/")), "le dossier `android/` d'origine est inchangé")
check(all(f in same for f in fb if f.startswith("icons/")), "le dossier `icons/` (logo officiel) est inchangé")

p(); p("## C. Aucune fonction existante n'est remplacée"); p()
fn1 = re.compile(r"function\s+([A-Za-z_$][\w$]*)")
fn2 = re.compile(r"([A-Za-z_$][\w$.]*)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)")
def names_of(path):
    s = open(path, encoding="utf-8", errors="replace").read()
    return set(fn1.findall(s)) | set(fn2.findall(s)), s
for f in ["gabon360-ia.js", "gabon360-modules-addon.js", "gabon360-config.js"]:
    nb, sb = names_of(fb[f]); na, sa = names_of(fa[f])
    check(nb <= na, "`%s` : %d fonctions/affectations de fonction avant, %d après ; aucune disparue (ajoutées : %s)" % (f, len(nb), len(na), sorted(na - nb) or "aucune"))
    dl = [l for l in __import__("difflib").unified_diff(sb.splitlines(), sa.splitlines(), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    p("  - lignes modifiées : %d (retirées %d, ajoutées %d)" % (len(dl), sum(l[0] == "-" for l in dl), sum(l[0] == "+" for l in dl)))
hb = open(fb["index.html"], encoding="utf-8").read(); ha = open(fa["index.html"], encoding="utf-8").read()
inl = re.compile(r"<script(?![^>]*src)[^>]*>(.*?)</script>", re.S)
check(inl.findall(hb) == inl.findall(ha), "`index.html` : le script principal (toute la logique de l'application, %d caractères) est strictement identique" % sum(len(x) for x in inl.findall(hb)))
check(ha.replace('<script src="./gabon360-sync.js"></script>', "") == hb, "`index.html` : la seule différence est la balise `gabon360-sync.js` (et, dans l'APK seulement, les balises des extensions)")
for f in ["api/assistant.js", "api/frontiere.js", "api/frontieres.js", "api/parcs.js"]:
    sa = open(fa[f], encoding="utf-8").read(); sb = open(fb[f], encoding="utf-8").read()
    un = sa.replace('const avecCors=require("./_cors.js");\n', "", 1).replace("module.exports=avecCors(", "module.exports=", 1)
    un = un.rstrip("\n")
    assert un.endswith("});") or un.endswith("}});")
    un = un[:-2] + "}" + ";" if False else un
    # retire la parenthèse fermante ajoutée par l'enveloppe : « ...}); » -> « ...}; »
    un = re.sub(r"\)\s*;\s*$", ";", un) if un.endswith(");") else un
    check(un.strip() == sb.strip(), "`%s` : une fois l'enveloppe CORS retirée, le code est identique à l'original (logique métier inchangée)" % f)
cb = open(fb["gabon360-config.js"], encoding="utf-8").read(); ca = open(fa["gabon360-config.js"], encoding="utf-8").read()
check(ca.startswith(cb.rstrip("\n")), "`gabon360-config.js` : le contenu d'origine est conservé tel quel, seules des lignes sont ajoutées à la fin")
wfb = open(fb[".github/workflows/build-apk-test.yml"], encoding="utf-8").read()
check(".github/workflows/build-apk-test.yml" in same, "le workflow `build-apk-test.yml` d'origine (déclenché sur push) n'est pas touché ; le nouveau est un fichier distinct")

p(); p("## D. Tests exécutés sur le résultat (copie après application des 3 patchs)"); p()
rc, o = sh("node tests/test-ia22.js 2>&1 | tail -1", cwd=work); check("289" in o and "0" in o, "tests des 22 IA : %s" % o.strip())
for t, lab in [("tests/test-sync.js", "synchronisation différée"), ("android-ext/dictee-native/tests/test-stt-native.js", "dictée native"), ("android-ext/gps-premier-plan/tests/test-gps-bridge.js", "GPS en premier plan")]:
    rc, o = sh("node %s 2>&1 | tail -1" % t, cwd=work); check(rc == 0, "tests %s : %s" % (lab, o.strip()))
js = [f for f in fa if f.endswith(".js")]
badjs = [f for f in js if sh("node --check '%s'" % fa[f])[0] != 0]
check(not badjs, "syntaxe de %d fichiers JS : aucune erreur %s" % (len(js), badjs or ""))
for i, b in enumerate(inl.findall(ha)):
    open(os.path.join(tmp, "i.js"), "w", encoding="utf-8").write(b)
    check(sh("node --check '%s'" % os.path.join(tmp, "i.js"))[0] == 0, "script inline %d de `index.html` : syntaxe valide" % i)
p(); p("## Conclusion"); p()
p("**%s**" % ("Tous les contrôles sont réussis." if not bad else "%d contrôle(s) en échec : voir ❌ ci-dessus." % len(bad)))
print("\n".join(out)); shutil.rmtree(tmp, ignore_errors=True); sys.exit(1 if bad else 0)
