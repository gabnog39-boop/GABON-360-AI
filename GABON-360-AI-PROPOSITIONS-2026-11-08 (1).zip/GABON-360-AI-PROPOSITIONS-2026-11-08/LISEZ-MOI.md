# GABON 360 AI — Dossier de propositions (révision 2, 8 novembre 2026)

Rien n'est appliqué à tes fichiers d'origine. Rien n'est poussé sur GitHub. Aucun APK n'a été compilé.

## Documents
- 01-RAPPORT-PREPARATION.md : tableau des 12 fichiers, risques, configuration Android/API, plan de tests, extensions, décisions
- 02-ETUDE-LOCUS-INREACH.md : étude séparée Locus Map et DeLorme/inReach (aucune simulation)
- 03-VERIFICATION-DOMAINE-PRODUCTION.md : ce qui est vérifié sur gabon-360-ai.vercel.app et ce qu'il reste à confirmer dans Vercel
- 04-PROCEDURE-CLE-PERMANENTE.md : création et conservation de la clé de signature définitive
- 05-ETUDE-CARTES-HORS-CONNEXION.md : cartes téléchargeables hors ligne (licences, architecture, phases)
- 06-VERIFICATION-CONSERVATION.md : preuve que les originaux sont conservés et qu'aucune fonction existante n'est remplacée
- SHA256SUMS.txt : empreintes de tous les fichiers de ce dossier

## Dossiers
- diffs/ : un patch par fichier (01 à 12), TOUT-12-FICHIERS.patch, 13-dictee-native.patch, 14-gps-premier-plan.patch, COMPARATIF-workflow-existant-vers-hybride.patch
- fichiers-proposes/ : les 12 fichiers complets proposés
- extensions-proposees/android-ext/ : les deux extensions (dictée native, GPS en premier plan), fichiers complets
- verification/ : script `verifier_conservation.py` pour refaire la vérification toi-même

## Appliquer (après ton autorisation seulement), sur une branche de test, jamais main/principal
Depuis la racine d'une copie de « complet » : `patch -p1 < diffs/TOUT-12-FICHIERS.patch`, puis facultativement `patch -p1 < diffs/13-dictee-native.patch` et `patch -p1 < diffs/14-gps-premier-plan.patch`.
Refaire la vérification : `python3 verification/verifier_conservation.py <archive-originale.zip> <ce-dossier>`
