# Clé de signature permanente de l'APK — procédure de création et de conservation

Statut : **procédure à exécuter plus tard, pour la version définitive.** Les premiers essais utilisent la clé debug (décision du 8 novembre 2026).
Règle d'or : **ne m'envoie jamais le fichier de clé ni ses mots de passe**, ni dans ce chat, ni dans le dépôt.

## 1. Pourquoi cette clé est critique
- Android n'installe une mise à jour **que si elle est signée par la même clé** que la version installée.
- Si la clé est perdue ou divulguée : impossible de mettre à jour les téléphones existants (désinstallation obligatoire, avec perte des données locales) ; en cas de divulgation, quelqu'un d'autre pourrait publier une fausse mise à jour.
- La clé debug du workflow est **recréée à chaque build** : deux APK de test successifs n'ont pas la même signature ; il faut désinstaller le précédent avant d'installer le suivant. C'est acceptable pour les essais, pas pour la version définitive.

## 2. Création (sur ton ordinateur, jamais sur GitHub ni en ligne)
1. Installer le JDK 17 (fournit `keytool`).
2. Commande (une seule ligne ; remplace les valeurs entre chevrons) :
   `keytool -genkeypair -v -keystore gabon360-release.jks -storetype PKCS12 -alias gabon360 -keyalg RSA -keysize 4096 -validity 10950 -dname "CN=GABON 360 AI, O=<organisation>, C=GA"`
3. Choisir un **mot de passe long (phrase de 5 mots ou plus)**, généré par un gestionnaire de mots de passe. Avec PKCS12, le mot de passe de la clé est le même que celui du fichier.
4. Relever l'**empreinte SHA-256 du certificat** : `keytool -list -v -keystore gabon360-release.jks -alias gabon360` (ligne « SHA256 »). La noter dans un document public interne : elle sert à reconnaître l'APK officiel.
5. Validité : 10 950 jours ≈ 30 ans.

## 3. Conservation (règle des trois copies)
| Copie | Support | Contenu |
|---|---|---|
| 1 | Gestionnaire de mots de passe chiffré (coffre) | fichier `.jks` en pièce jointe + mot de passe + alias |
| 2 | Clé USB chiffrée, rangée hors du lieu de travail | fichier `.jks` |
| 3 | Coffre physique ou personne de confiance désignée (le propriétaire reste responsable) | fichier `.jks` sous enveloppe scellée ; le mot de passe **séparément** |
- Jamais : dans le dépôt GitHub, dans une archive partagée, dans un e-mail, dans un chat, dans le code ou un fichier `gradle.properties` versionné.
- Tester la restauration une fois par an (ouvrir la copie 2 et lancer la commande `keytool -list`).
- Noter dans un registre : date de création, empreinte SHA-256, emplacement des trois copies, personnes habilitées.

## 4. Utilisation par GitHub Actions (le jour venu)
1. Convertir le fichier en texte : `base64 -w0 gabon360-release.jks > jks.b64` (copier le contenu).
2. GitHub → Settings → **Secrets and variables → Actions → Secrets** : créer `G360_KEYSTORE_B64`, `G360_KEYSTORE_PASSWORD`, `G360_KEY_ALIAS`. Supprimer ensuite `jks.b64` de l'ordinateur.
3. Le workflow de version définitive (à préparer et à te soumettre en diff avant tout usage) : décode le secret dans un fichier temporaire du runner, signe avec `assembleRelease`, vérifie avec `apksigner verify --print-certs` que l'**empreinte SHA-256 correspond à celle du registre**, puis supprime le fichier temporaire.
4. Les secrets GitHub ne sont pas transmis aux requêtes de tirage (pull requests) de dépôts tiers : restreindre le workflow de version aux branches protégées.

## 5. Si tu distribues par Google Play (décision à part)
Avec « Play App Signing », Google conserve la clé de signature finale et tu gardes une clé d'envoi remplaçable en cas de perte. C'est plus sûr pour une diffusion large ; la distribution directe de l'APK reste possible mais fait reposer toute la sécurité sur ta clé.

## 6. Perte ou divulgation
- **Perdue, non divulguée** : si Play App Signing est utilisé, demande la réinitialisation de la clé d'envoi ; sinon, nouvelle clé et nouvelle application (nouvel identifiant) ou désinstallation/réinstallation sur chaque téléphone, après export des données locales (traces GPX).
- **Divulguée** : même chose, plus communication immédiate aux utilisateurs de ne plus installer d'APK portant l'ancienne empreinte, et changement des secrets (Supabase, Anthropic) par précaution si le dépôt a pu être exposé.

## 7. Liste de contrôle avant la première version définitive
- [ ] Clé créée sur ma machine, trois copies faites, restauration testée
- [ ] Empreinte SHA-256 enregistrée
- [ ] Secrets GitHub créés, `jks.b64` supprimé
- [ ] Diff du workflow de version relu et approuvé
- [ ] APK signé vérifié (`apksigner verify`), installé par-dessus une version précédente signée de la même clé, sans perte de données
