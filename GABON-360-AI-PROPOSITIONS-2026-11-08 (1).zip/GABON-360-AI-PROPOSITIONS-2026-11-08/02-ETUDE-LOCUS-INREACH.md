# GABON 360 AI — Étude d'intégration réelle : Locus Map et DeLorme / inReach

Date : 8 novembre 2026 · Statut : **étude, aucune implémentation, aucune simulation**
Portée : indépendante de l'APK de la proposition 01. Rien ici n'est dans l'APK.

## 1. État actuel dans le projet (vérifié dans les 6 ZIP)

| Élément | Présent dans le code ? |
|---|---|
| Locus Map (API, intent, SDK) | **Non.** Cité seulement dans `DOSSIER-CLAUDE-GABON-360-AI.md` et le rapport de continuité |
| DeLorme / inReach / messagerie satellite | **Non** |
| Garmin | **Partiel** : import/export de fichiers GPX et waypoints ; un agent IA « garmin » qui n'analyse que des données de l'application |
| Meshtastic / LoRa | Non |

Conséquence : l'interface ne doit **rien afficher** de « connecté » pour ces trois fonctions tant qu'une intégration réelle n'a pas été testée sur matériel.

## 2. Locus Map

### Ce que la documentation publique établit
- Locus Map est une application Android ; Asamm publie une bibliothèque **Locus API** (modules `locus-api-core` et `locus-api-android`), distribuée via JitPack. La version 0.10.1 est citée dans la documentation du dépôt.
- Périmètre déclaré : transport d'objets (points, traces, notes de terrain), contrôle de l'enregistrement et en partie de la navigation, aperçus de carte, lecture d'informations (unités, enregistrement en cours), capteurs externes exposés à Locus.
- **Hors périmètre déclaré :** ce n'est pas une bibliothèque cartographique de remplacement ; elle ne fonctionne pas sans l'application Locus Map installée.
- L'intégration passe par des composants Android natifs (service lié / AIDL, intents). Exemple documenté : demander à Locus de renvoyer une position choisie (`ACTION_RECEIVE_LOCATION`).

### Conséquence pour GABON 360 AI
La WebView ne peut pas appeler Locus directement. Il faut un **module natif Android** (Kotlin/Java) qui parle à Locus, exposé à la page par un pont JavaScript comme `AndroidGPS`.

### Options réalistes (de la moins à la plus coûteuse)
| Option | Principe | Avantages | Limites / dépendances |
|---|---|---|---|
| A. Échange par fichiers GPX | GABON 360 exporte un GPX ; Locus l'ouvre (partage Android / « ouvrir avec ») ; et l'inverse | Existe déjà côté GABON 360 ; aucun SDK ; fonctionne même sans lien profond | Manuel ; pas de contrôle de Locus ; à valider sur le TECNO avec la version installée de Locus |
| B. Envoi de points/traces vers Locus via Locus API | Module natif qui crée un point/une trace dans Locus à partir d'une alerte ou d'une mission | Un tap depuis GABON 360 ; navigation vers la cible dans Locus | Locus Map **doit être installé** ; dépendance JitPack ; licence/fonctions Locus (gratuit ou Premium) **à vérifier** ; version d'API à épingler |
| C. Lecture de l'enregistrement en cours | Lire l'état d'enregistrement de Locus et rapatrier une trace | Évite la double saisie de trace | Même dépendances que B ; permissions et cas d'erreur à tester sur appareil |

Recommandation : **A d'abord** (quelques jours, aucun risque), **B ensuite** si l'essai A montre un vrai besoin.

### Ce qu'il faut me fournir pour avancer
Version de Locus Map installée, type de licence, modèle de téléphone, 2 ou 3 traces GPX réelles de forêt (anonymisées si besoin).

## 3. DeLorme / inReach (Garmin)

### Ce que la documentation publique établit
- **DeLorme** est la marque historique des communicateurs satellites **inReach**, aujourd'hui commercialisés et gérés par Garmin (portail Garmin Explore). Des documents d'intégrateurs tiers parlent encore de « DeLorme » pour désigner ces services.
- Les messages inReach passent par le réseau satellite Iridium vers les serveurs Garmin, **pas par le téléphone ni par ton application**.
- Garmin propose un portail développeur « inReach » réservé aux clients **professionnels / entreprise** : trois accès publics sont décrits :
  - **IPC Outbound** : Garmin pousse les messages et positions vers l'URL d'un service web que tu héberges ;
  - **IPC Inbound** : ton service web envoie des messages et commandes vers les appareils (7 services web JSON) ;
  - options sur demande : API SOS, « Enterprise Unlocked ».
- Les guides IPC Inbound (v3.1.1, octobre 2024) et Outbound (v2.0.5, février 2024) sont téléchargeables sur le portail après acceptation des conditions.
- Des intégrateurs (CalTopo, EarthRanger/Gundi) confirment l'usage : compte **Professional** requis pour le portail de connexion ; sinon, seule la position partagée via **MapShare** est possible (partage de position, avec mot de passe facultatif).
- Je n'ai trouvé **aucune API publique** permettant à une application tierce d'envoyer ou de recevoir des messages directement par Bluetooth avec l'appareil. À confirmer auprès de Garmin avant de promettre quoi que ce soit.

### Architecture réaliste (serveur, pas téléphone)
```
inReach ──Iridium──► Serveurs Garmin ──IPC Outbound (HTTPS)──► route Vercel de GABON 360 ──► Supabase (evenements)
inReach ◄─Iridium── Serveurs Garmin ◄─IPC Inbound (HTTPS)──── route Vercel de GABON 360 ◄── action d'un opérateur
```
- L'APK ne parle jamais à Garmin : il lit/écrit dans Supabase comme aujourd'hui. Cela marche donc tout de suite avec la synchronisation différée.
- Une alerte SOS ou un message d'un garde sur le terrain arrive dans le tableau d'alertes ; un opérateur peut répondre depuis l'application via IPC Inbound.

### Options
| Option | Condition | Fonction |
|---|---|---|
| 1. MapShare (lecture de position) | appareils existants, MapShare activé sur Garmin Explore | position et suivi seulement ; **pas de messagerie** ; disponibilité et conditions d'usage du flux **à vérifier** |
| 2. IPC Outbound | compte Garmin **Professional ou Enterprise** + URL HTTPS publique | réception automatique de messages et positions dans GABON 360 |
| 3. IPC Inbound | idem + identifiants IPC | envoi de messages et commandes aux appareils depuis GABON 360 |
| 4. Fonctions sur demande (SOS, chiffrement) | demande d'accès à Garmin | hors périmètre initial |

### Points de vigilance
- **Sécurité** : l'URL IPC Outbound et les identifiants IPC Inbound sont des secrets (variables d'environnement Vercel, jamais dans l'APK ni dans le dépôt) ; validation de l'origine des requêtes entrantes ; journalisation sans données personnelles inutiles.
- **Vie privée** : positions de gardes et de personnes ; base légale, durée de conservation, droits d'accès à définir (RLS Supabase par rôle).
- **Coût et contrat** : abonnement Garmin Professional/Enterprise et forfaits Iridium ; conditions d'usage du portail à lire avant tout développement.
- **Fiabilité** : pas de garantie de délai de livraison des messages satellites ; l'interface doit afficher l'heure d'émission et l'heure de réception, jamais « envoyé » avant l'accusé de Garmin.

### Ce qu'il faut me fournir pour avancer
Modèles d'inReach, type de compte Garmin (Explore personnel / Professional / Enterprise), existence d'un portail « Portal Connect », nombre d'appareils, et les guides IPC téléchargés depuis le portail Garmin.

## 4. Règle « pas de simulation » (à appliquer dans l'interface)
- Tant qu'une intégration n'est pas testée sur matériel : l'écran affiche « **Non connecté — intégration non disponible** ».
- Aucun message, aucune position, aucun accusé de réception n'est généré par l'application elle-même.
- Chaque fonction a un état réel : `non configurée`, `configurée, non testée`, `testée le <date> sur <matériel>`.

## 5. Plan d'étude puis de prototype (après ta décision)

| Phase | Contenu | Livrable | Condition de sortie |
|---|---|---|---|
| E1 | Réponses aux questions « ce qu'il faut me fournir » | fiche matériel et licences | informations reçues |
| E2 | Locus option A : essai GPX GABON 360 → Locus → GABON 360 sur téléphone | procédure + résultats | import/export réussis sur le TECNO |
| E3 | inReach : lecture des guides IPC, choix Outbound seul ou Outbound + Inbound | note de conception | compte Garmin adapté confirmé |
| E4 | Route Vercel de réception (Outbound) en environnement de test, avec un appareil réel | prototype + journal d'essai | un message réel d'un appareil arrive dans `evenements` |
| E5 | Locus option B (si utile) : module natif minimal | prototype + essai terrain | un point GABON 360 apparaît dans Locus |
| E6 | IPC Inbound (réponse opérateur) | prototype + essai terrain | un message envoyé depuis GABON 360 atteint l'appareil |

## 6. Sources consultées (documentation publique, novembre 2026)
- Locus API (dépôt officiel Asamm) : https://github.com/asamm/locus-api — README, wiki « Adding Locus API to project » et « Pick location from Locus Map »
- Locus Map, documentation du service de calcul d'itinéraire : https://docs.locusmap.app/doku.php/manual:advanced:locus_api:routing_service
- Garmin, portail développeur inReach : https://developer.garmin.com/inreach-portal/overview/
- Garmin, guide IPC Inbound v3.1.1 : https://developer.garmin.com/inReach/IPC_Inbound.pdf
- Garmin, guide IPC Outbound v2.0.5 : https://developer.garmin.com/inReach/IPC_Outbound.pdf
- CalTopo, intégrations de localisation (IPC et MapShare) : https://training.caltopo.com/all_users/resources/integrations
- EarthRanger, intégration Garmin inReach : https://earthranger-support.helpjuice.com/en_US/garmin-inreach

Limite : ces sources décrivent les offres telles que publiées ; les conditions commerciales, prix et disponibilité pour le Gabon n'ont pas été vérifiés.
