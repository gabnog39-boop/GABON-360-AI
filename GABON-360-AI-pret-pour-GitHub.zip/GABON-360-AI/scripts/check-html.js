// Contrôle de syntaxe des scripts intégrés à index.html (utilisé par la CI).
const fs = require('fs'), os = require('os'), path = require('path'), { spawnSync } = require('child_process');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi;
let m, i = 0, bad = 0;
while ((m = re.exec(html))) {
  i++;
  const f = path.join(os.tmpdir(), `g360-inline-${i}.js`);
  fs.writeFileSync(f, m[1]);
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status !== 0) { bad++; console.error(`Script intégré #${i} invalide:\n${r.stderr}`); }
}
if (!i) { console.error('Aucun script intégré trouvé'); process.exit(1); }
console.log(`${i} script(s) intégré(s) vérifié(s), ${bad} erreur(s)`);
process.exit(bad ? 1 : 0);
