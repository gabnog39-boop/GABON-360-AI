const test = require('node:test');
const assert = require('node:assert/strict');
const handler = require('../api/assistant');

function responseMock() {
  return {
    statusCode: 200, headers: {}, payload: null,
    setHeader(k, v) { this.headers[k] = v; return this; },
    status(code) { this.statusCode = code; return this; },
    json(payload) { this.payload = payload; return this; }
  };
}
async function call(req, env = {}, fetchImpl = global.fetch) {
  const previous = { key: process.env.ANTHROPIC_API_KEY, model: process.env.ANTHROPIC_MODEL };
  if (env.key === undefined) delete process.env.ANTHROPIC_API_KEY; else process.env.ANTHROPIC_API_KEY = env.key;
  if (env.model === undefined) delete process.env.ANTHROPIC_MODEL; else process.env.ANTHROPIC_MODEL = env.model;
  global.fetch = fetchImpl;
  const res = responseMock();
  try { await handler(req, res); return res; }
  finally {
    if (previous.key === undefined) delete process.env.ANTHROPIC_API_KEY; else process.env.ANTHROPIC_API_KEY = previous.key;
    if (previous.model === undefined) delete process.env.ANTHROPIC_MODEL; else process.env.ANTHROPIC_MODEL = previous.model;
    global.fetch = fetchImpl;
  }
}

test('GET ne signale configuré que si clé et modèle sont présents', async () => {
  assert.equal((await call({method:'GET'}, {key:'k'})).payload.ok, false);
  assert.equal((await call({method:'GET'}, {key:'k', model:'model'})).payload.ok, true);
});
test('refuse les méthodes autres que GET et POST', async () => {
  const r = await call({method:'DELETE'});
  assert.equal(r.statusCode, 405); assert.equal(r.headers.Allow, 'GET, POST');
});
test('rejette JSON invalide et question manquante', async () => {
  const env = {key:'k',model:'m'};
  assert.equal((await call({method:'POST',headers:{authorization:'Bearer t'},body:'{'},env)).statusCode,400);
  assert.equal((await call({method:'POST',headers:{authorization:'Bearer t'},body:{}},env)).statusCode,400);
  assert.equal((await call({method:'POST',headers:{authorization:'Bearer t'},body:{}},env)).statusCode,400);
});
test('rejette le contexte trop volumineux avant les appels externes', async () => {
  const r = await call({method:'POST',headers:{authorization:'Bearer t'},body:{q:'test',ctx:'x'.repeat(12001)}},{key:'k',model:'m'});
  assert.equal(r.statusCode,413);
});
test('ne transmet pas les détails internes Anthropic au client', async () => {
  let n=0;
  const fakeFetch = async url => {
    n++;
    if (String(url).includes('/auth/v1/user')) return {ok:true,json:async()=>({id:'abc'})};
    if (String(url).includes('/rest/v1/profiles')) return {ok:true,json:async()=>[{statut:'actif'}]};
    return {ok:false,json:async()=>({error:{message:'secret internal detail'}})};
  };
  const r = await call({method:'POST',headers:{authorization:'Bearer token'},body:{q:'Explique cette alerte',ctx:'ID: TEST-7842'}},{key:'k',model:'m'},fakeFetch);
  assert.equal(r.statusCode,502); assert.doesNotMatch(JSON.stringify(r.payload),/secret internal detail/); assert.equal(n,3);
});
test('retourne la réponse texte du fournisseur si le parcours est valide', async () => {
  const fakeFetch = async url => {
    if (String(url).includes('/auth/v1/user')) return {ok:true,json:async()=>({id:'abc'})};
    if (String(url).includes('/rest/v1/profiles')) return {ok:true,json:async()=>[{statut:'actif'}]};
    return {ok:true,json:async()=>({content:[{type:'text',text:'Alerte TEST-7842 : localisation non renseignée.'}]})};
  };
  const r = await call({method:'POST',headers:{authorization:'Bearer token'},body:{q:'Explique',ctx:'TEST-7842'}},{key:'k',model:'m'},fakeFetch);
  assert.equal(r.statusCode,200); assert.match(r.payload.text,/TEST-7842/);
});

test('IA spécialisée inconnue refusée (400)', async () => {
  const r = await call({method:'POST',headers:{authorization:'Bearer t'},body:{q:'x',ctx:'y',ai:'inconnue'}},{key:'k',model:'m'});
  assert.equal(r.statusCode,400);
});
test("chaque page a sa propre consigne : l'IA météo n'utilise pas celle de l'avatar", async () => {
  const systems = [];
  const fakeFetch = async (url, opt) => {
    if (String(url).includes('/auth/v1/user')) return {ok:true,json:async()=>({id:'abc'})};
    if (String(url).includes('/rest/v1/profiles')) return {ok:true,json:async()=>[{statut:'actif'}]};
    systems.push(JSON.parse(opt.body).system);
    return {ok:true,json:async()=>({content:[{type:'text',text:'ok'}]})};
  };
  const mk = ai => ({method:'POST',headers:{authorization:'Bearer t'},body:{q:'Rapport',ctx:'{}',ai}});
  assert.equal((await call(mk('mt'),{key:'k',model:'m'},fakeFetch)).statusCode,200);
  assert.equal((await call(mk(undefined),{key:'k',model:'m'},fakeFetch)).statusCode,200);
  assert.match(systems[0], /IA météo/); assert.match(systems[0], /prévisions, pas des mesures/);
  assert.match(systems[1], /avatar central/); assert.doesNotMatch(systems[1], /« IA météo »/);
});

test("conversation : l'historique est transmis en messages alternés, le message courant en dernier", async () => {
  const bodies = [];
  const fakeFetch = async (url, opt) => {
    if (String(url).includes('/auth/v1/user')) return {ok:true,json:async()=>({id:'abc'})};
    if (String(url).includes('/rest/v1/profiles')) return {ok:true,json:async()=>[{statut:'actif'}]};
    bodies.push(JSON.parse(opt.body));
    return {ok:true,json:async()=>({content:[{type:'text',text:'ok'}]})};
  };
  const hist = [{r:'a',t:'orpheline'},{r:'u',t:'Salut'},{r:'a',t:'Bonjour !'},{r:'u',t:'Parle-moi du Gabon'},{r:'u',t:'et des forêts'},{r:'a',t:'Volontiers.'},{r:'u',t:'dernier user sans réponse'}];
  const r = await call({method:'POST',headers:{authorization:'Bearer t'},body:{q:'Et la houle ?',ctx:'{}',hist}},{key:'k',model:'m'},fakeFetch);
  assert.equal(r.statusCode,200);
  const m = bodies[0].messages;
  assert.deepEqual(m.map(x=>x.role),['user','assistant','user','assistant','user']);
  assert.match(m[2].content,/Parle-moi du Gabon\net des forêts/);
  assert.match(m[4].content,/Question : Et la houle \?/);
  assert.match(bodies[0].system,/n'importe quel sujet/);
  assert.match(bodies[0].system,/jamais inventer une donnée en direct/);
});
test('conversation : historique invalide refusé (400)', async () => {
  const mk = hist => ({method:'POST',headers:{authorization:'Bearer t'},body:{q:'x',ctx:'y',hist}});
  for (const bad of ['texte', [{r:'x',t:'a'}], [{r:'u',t:''}], [{r:'u',t:'a'.repeat(701)}], Array(9).fill({r:'u',t:'a'})])
    assert.equal((await call(mk(bad),{key:'k',model:'m'})).statusCode,400);
});
