const test = require('node:test');
const assert = require('node:assert/strict');
const airspace = require('../api/airspace');
const feux = require('../api/feux');

function resMock() {
  return { statusCode: 200, headers: {}, payload: null,
    setHeader(k, v) { this.headers[k] = v; return this; },
    status(c) { this.statusCode = c; return this; },
    json(p) { this.payload = p; return this; } };
}
function mkFetch(role, ext) {
  return async url => {
    const u = String(url);
    if (u.includes('/auth/v1/user')) return { ok: true, json: async () => ({ id: 'abc' }) };
    if (u.includes('/rest/v1/profiles')) return { ok: true, json: async () => [{ statut: 'actif', role }] };
    return ext(u);
  };
}
async function call(handler, req, fetchImpl, env = {}) {
  const prev = global.fetch, pk = process.env.FIRMS_MAP_KEY;
  global.fetch = fetchImpl;
  if (env.FIRMS_MAP_KEY === undefined) delete process.env.FIRMS_MAP_KEY; else process.env.FIRMS_MAP_KEY = env.FIRMS_MAP_KEY;
  const res = resMock();
  try { await handler(req, res); return res; }
  finally { global.fetch = prev; if (pk === undefined) delete process.env.FIRMS_MAP_KEY; else process.env.FIRMS_MAP_KEY = pk; }
}
const get = (token = 't') => ({ method: 'GET', headers: token ? { authorization: 'Bearer ' + token } : {} });
const never = async () => { throw new Error('ne doit pas être appelé'); };

test('espace aérien : POST refusé, sans jeton 401', async () => {
  assert.equal((await call(airspace, { method: 'POST', headers: {} }, never)).statusCode, 405);
  assert.equal((await call(airspace, get(''), never)).statusCode, 401);
});
test('espace aérien : un rôle non autorisé reçoit 403', async () => {
  assert.equal((await call(airspace, get(), mkFetch('ecogarde', never))).statusCode, 403);
});
test('espace aérien : limite de la source (429)', async () => {
  const r = await call(airspace, get(), mkFetch('superviseur', async () => ({ ok: false, status: 429 })));
  assert.equal(r.statusCode, 429);
});
test('espace aérien : analyse des états ADS-B', async () => {
  const states = [
    ['abc123', 'AF123  ', 'France', 1, 1700000000, 9.4, 0.4, 3000, false, 200, 90, 0, null, 3100, '7700'],
    ['def456', '', 'Gabon', 1, 1700000000, 10, -1, null, true, 0, 0, 0, null, null, '1200'],
    ['ghi789', 'XX', 'Sans position', 1, 1, null, null]
  ];
  const r = await call(airspace, get(), mkFetch('analyste', async () => ({ ok: true, json: async () => ({ time: 1700000000, states }) })));
  assert.equal(r.statusCode, 200);
  assert.equal(r.payload.avions.length, 2);
  assert.equal(r.payload.avions[0].indicatif, 'AF123'); assert.equal(r.payload.avions[0].squawk, '7700');
  assert.equal(r.payload.avions[1].sol, true);
  assert.match(r.payload.couverture, /partielle/);
});

test('feux : sans clé FIRMS, 503 explicite', async () => {
  const r = await call(feux, get(), mkFetch('superviseur', never));
  assert.equal(r.statusCode, 503); assert.match(r.payload.error, /FIRMS_MAP_KEY/);
});
test('feux : réponse invalide (clé refusée) → 502', async () => {
  const r = await call(feux, get(), mkFetch('superviseur', async () => ({ ok: true, text: async () => 'Invalid MAP_KEY' })), { FIRMS_MAP_KEY: 'k' });
  assert.equal(r.statusCode, 502);
});
test('feux : lecture du CSV FIRMS', async () => {
  const csv = 'latitude,longitude,bright_ti4,scan,track,acq_date,acq_time,satellite,confidence,version,bright_ti5,frp,daynight\n' +
    '-0.5,11.2,330,0.4,0.4,2026-10-17,0130,N,h,2.0NRT,300,12.5,N\nbad,line\n1.0,12.0,320,0.4,0.4,2026-10-17,1230,N,n,2.0NRT,290,3.1,D\n';
  const r = await call(feux, get(), mkFetch('proprietaire', async () => ({ ok: true, text: async () => csv })), { FIRMS_MAP_KEY: 'k' });
  assert.equal(r.statusCode, 200); assert.equal(r.payload.total, 2);
  assert.equal(r.payload.points[0].confiance, 'h'); assert.equal(r.payload.points[0].lat, -0.5);
  assert.doesNotMatch(JSON.stringify(r.payload), /"k"/);
});
