const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'), path = require('path'), vm = require('vm');

function load(me = { role: 'superviseur' }, extra = {}) {
  const ctx = {
    MODS: [], EVT: [], me, ses: { access_token: 't' }, console, Date, Math, Object, JSON, Promise, Array, String, Number, isNaN, parseFloat,
    setTimeout, clearTimeout, AbortController, URLSearchParams,
    $: () => null, el: () => ({}), document: {}, tab() {}, avSay() {}, llmAsk: async () => {}, loadAll: async () => {}, api: async () => [],
    mkEv: (mod, type, titre, prio, o = {}) => ({ mod, type, titre, prio, lat: o.lat == null ? null : o.lat, lon: o.lon == null ? null : o.lon, statut: o.statut || 'à vérifier', src: o.src || '' })
  };
  Object.assign(ctx, extra);
  ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'gabon360-centre.js'), 'utf8'), ctx);
  return ctx;
}
const sq = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]];

test('toutes les IA sont reliées à l\'avatar : 4 pages réelles + 4 IA en attente de source', () => {
  const c = load();
  assert.deepEqual(c.MODS.map(m => m.id).sort(), ['ea', 'cy', 'dr', 'eo', 'fo', 'mt', 'pa', 'sa'].sort());
  assert.ok(c.MODS.every(m => typeof m.sum === 'function' && m.nom && m.role));
  assert.deepEqual([...c.G360C.tabs].sort(), ['ea', 'eo', 'fo', 'mt']);
});
test('point dans un polygone : trou et multipolygone', () => {
  const { inGeo } = load().G360C._t;
  const poly = { type: 'Polygon', coordinates: [sq(0, 0, 10, 10), sq(4, 4, 6, 6)] };
  assert.equal(inGeo(2, 2, poly), true); assert.equal(inGeo(5, 5, poly), false); assert.equal(inGeo(20, 2, poly), false);
  const multi = { type: 'MultiPolygon', coordinates: [[sq(0, 0, 1, 1)], [sq(5, 5, 6, 6)]] };
  assert.equal(inGeo(5.5, 5.5, multi), true); assert.equal(inGeo(3, 3, multi), false);
});
test('météo : seuils indicatifs → événements à vérifier', () => {
  const c = load(), t = c.G360C._t;
  t.setX({ mt: { ok: true, t: 1, data: [
    { nom: 'Libreville', lat: 0.4, lon: 9.4, rafale: 70, rafaleMax3j: 75, pluieMax3j: 10 },
    { nom: 'Oyem', lat: 1.6, lon: 11.6, rafale: 10, rafaleMax3j: 20, pluieMax3j: 120 }] } });
  const r = t.sumMt();
  assert.equal(r.etat, 'ok'); assert.equal(r.ev.length, 2);
  assert.equal(r.ev.find(e => /Libreville/.test(e.titre)).prio, 'haute');
  assert.equal(r.ev.find(e => /Oyem/.test(e.titre)).prio, 'critique');
  assert.ok(r.ev.every(e => /vérifier/.test(e.statut)));
});
test('source indisponible : aucune donnée inventée, aucun événement', () => {
  const t = load().G360C._t;
  t.setX({ mt: { ok: false, err: 'HTTP 500', t: 1 } });
  const r = t.sumMt();
  assert.equal(r.etat, 'erreur'); assert.equal(r.ev.length, 0); assert.match(r.lines[0], /indisponible/);
});
test('eaux et océan : houle forte et crue', () => {
  const t = load().G360C._t;
  t.setX({ mar: { ok: true, t: 1, data: [{ nom: 'Large de Port-Gentil', lat: -1, lon: 8.3, houle: 1, houleMax24h: 4.2 }] },
    riv: { ok: true, t: 1, data: [{ nom: 'Ogooué (Lambaréné)', lat: -0.7, lon: 10.2, debit: 1000, debitFin: 1500, tendance: 0.5 }] } });
  const r = t.sumEo();
  assert.equal(r.etat, 'ok');
  assert.equal(r.ev.find(e => e.type === 'mer').prio, 'critique');
  assert.equal(r.ev.find(e => e.type === 'eau').prio, 'normale');
  assert.match(r.lines.join(' '), /Pollution et pêche illégale : aucune source connectée/);
});
test('espace aérien : code 7700 = événement critique ; couverture partielle annoncée', () => {
  const t = load().G360C._t;
  t.setX({ ea: { ok: true, t: 1, data: { avions: [
    { icao24: 'a', indicatif: 'AF1', lat: 0, lon: 9, sol: false, squawk: '7700' }, { icao24: 'b', indicatif: '', lat: 1, lon: 10, sol: true, squawk: '1200' }] } } });
  const r = t.sumEa();
  assert.equal(r.ev.length, 1); assert.equal(r.ev[0].prio, 'critique'); assert.match(r.ev[0].titre, /AF1/);
  assert.match(r.lines.join(' '), /pas un radar/);
});
test('espace aérien : rôle non autorisé → réservé', () => {
  const t = load({ role: 'ecogarde' }).G360C._t;
  t.setX({ ea: { ok: false, restreint: true, t: 1 } });
  assert.equal(t.sumEa().etat, 'restreint');
});
test('feux : point chaud dans un parc → événement ; clé absente → en attente', () => {
  const t = load().G360C._t;
  const parcs = { Lopé: { geojson: { type: 'FeatureCollection', features: [{ geometry: { type: 'Polygon', coordinates: [sq(10, -1, 12, 0)] } }] } }, _frontiere: { geojson: { features: [{ geometry: { type: 'Polygon', coordinates: [sq(0, -10, 20, 10)] } }] } } };
  t.setX({ _parcs: parcs, fo: { ok: true, t: 1, data: { total: 2, points: [
    { lat: -0.5, lon: 11, date: '2026-10-17', heure: '0130', confiance: 'h' }, { lat: 1, lon: 5, date: '2026-10-17', heure: '0130', confiance: 'n' }] } } });
  const r = t.sumFo();
  assert.equal(r.ev.length, 1); assert.match(r.ev[0].titre, /parc Lopé/); assert.equal(r.ev[0].prio, 'haute');
  t.setX({ fo: { ok: false, err: 'Source feux non configurée (FIRMS_MAP_KEY manquante côté serveur)', t: 1 } });
  const e = t.sumFo(); assert.equal(e.etat, 'attente'); assert.match(e.lines[0], /FIRMS_MAP_KEY/);
});

/* ---------- Veille automatique ---------- */
function harness(over = {}) {
  const said = [], fetched = [];
  const c = load({ role: 'superviseur' }, Object.assign({
    avSay: (t, u, silent) => said.push({ t, silent: !!silent }),
    EVT: [], LLM: false, renderHome() {}, checkLlm: async () => {},
    llmAsk: async q => { said.push({ t: 'SYNTHESE:' + q, silent: false }); },
    fetch: async (url, opt) => { fetched.push(JSON.parse(opt.body)); return { ok: true, json: async () => ({ text: 'Rapport test' }) }; }
  }, over));
  return { c, said, fetched, a: c.G360C._t.auto };
}
const ev = (mod, prio, titre, extra = {}) => Object.assign({ mod, type: 'météo', prio, titre, statut: 'à vérifier', src: 'S', lat: null, lon: null }, extra);

test('veille : un signalement n\'est annoncé qu\'une fois ; un changement de valeur ne le répète pas ; une aggravation si', () => {
  const { c, a } = harness();
  c.EVT.push(ev('mt', 'haute', 'Rafales prévues jusqu\'à 75 km/h à Libreville'));
  assert.equal(a.fresh().length, 1); assert.equal(a.fresh().length, 0);
  c.EVT.length = 0; c.EVT.push(ev('mt', 'haute', 'Rafales prévues jusqu\'à 78 km/h à Libreville'));
  assert.equal(a.fresh().length, 0);
  c.EVT.length = 0; c.EVT.push(ev('mt', 'critique', 'Rafales prévues jusqu\'à 95 km/h à Libreville'));
  assert.equal(a.fresh().length, 1);
});
test('veille : priorité haute/critique = voix, sinon texte silencieux ; toujours « à vérifier »', () => {
  const { said, a } = harness();
  a.announce([ev('mt', 'normale', 'Info')]);
  assert.equal(said[0].silent, true);
  a.announce([ev('ea', 'critique', 'Aéronef AF1 : urgence générale (code 7700)', { lat: 0, lon: 9 })]);
  assert.equal(said[1].silent, false); assert.match(said[1].t, /critique/); assert.match(said[1].t, /IA espace aérien/); assert.match(said[1].t, /vérifier/);
});
test('veille : une source qui tombe puis revient est annoncée', () => {
  const { c, a } = harness();
  const m = c.MODS.find(x => x.id === 'mt'); m.last = { etat: 'ok' };
  assert.equal(a.healthChanges().length, 0);
  m.last = { etat: 'erreur' };
  const h = a.healthChanges(); assert.equal(h.length, 1); assert.match(h[0].titre, /indisponible/);
  assert.equal(a.healthChanges().length, 0);
  m.last = { etat: 'ok' }; assert.match(a.healthChanges()[0].titre, /rétablie/);
});
test('veille : budget IA limité (8/heure) et délai par IA', () => {
  const { a } = harness();
  assert.equal(a.llmOk('ia:mt', 1800e3), true); assert.equal(a.llmOk('ia:mt', 1800e3), false);
  for (let i = 0; i < 7; i++) assert.equal(a.llmOk('k' + i, 0), true);
  assert.equal(a.llmOk('autre', 0), false);
});
test('veille : cycle complet sans aucun clic — point de situation, annonce, rapport de l\'IA concernée, synthèse', async () => {
  const { c, said, fetched, a } = harness({ LLM: true, loadAll: async () => {} });
  // Les IA sans source connectée (satellites, drones, cybersécurité, paiements) restent « en attente », comme en réel.
  const SANS_SOURCE = ['sa', 'dr', 'cy', 'pa'];
  c.MODS.forEach(m => { m.last = { etat: SANS_SOURCE.includes(m.id) ? 'attente' : 'ok', lines: [m.nom + ' : ok'], ev: [] }; });
  await a.tick(true);
  assert.match(said[0].t, /Point de situation automatique/); assert.match(said[0].t, /IA drones/);
  assert.match(said[0].t, /pas encore alimentées/);
  c.EVT.push(ev('ea', 'critique', 'Aéronef AF1 : urgence générale (code 7700)', { type: 'aéronef' }));
  await a.tick(false);
  assert.ok(said.some(s => /Signalement critique/.test(s.t) && s.silent === false));
  assert.equal(fetched.length, 1); assert.equal(fetched[0].ai, 'ea');
  assert.ok(said.some(s => /Rapport transmis par « IA espace aérien »/.test(s.t)));
  assert.ok(said.some(s => /^SYNTHESE:/.test(s.t)));
});
test('veille : sans IA de rédaction, l\'avatar annonce quand même (aucun appel IA)', async () => {
  const { c, said, fetched, a } = harness({ LLM: false, loadAll: async () => {} });
  c.MODS.forEach(m => { m.last = { etat: 'ok', lines: ['ok'], ev: [] }; });
  await a.tick(true);
  c.EVT.push(ev('al', 'haute', 'Alerte incendie', { type: 'alerte' }));
  await a.tick(false);
  assert.ok(said.some(s => /Alerte incendie/.test(s.t) && s.silent === false));
  assert.equal(fetched.length, 0);
});
test('veille suspendue par l\'opérateur : plus aucune annonce', async () => {
  const { c, said, a } = harness({ loadAll: async () => {} });
  c.MODS.forEach(m => { m.last = { etat: 'ok', lines: ['ok'], ev: [] }; });
  await a.tick(true); a.AUTO.on = false;
  c.EVT.push(ev('al', 'critique', 'Alerte X', { type: 'alerte' }));
  const n = said.length; await a.tick(false);
  assert.equal(said.length, n);
});

/* ---------- Conversation ---------- */
test("civilités : l'avatar répond lui-même aux messages courts de politesse", () => {
  const c = load({ nom: 'Marc', role: 'superviseur' }), s = c.G360C.social;
  assert.match(s('bonjour'), /Bonjour|Bonsoir/); assert.match(s('bonjour'), /Marc/);
  assert.match(s('merci beaucoup'), /plaisir/);
  assert.match(s('ca va'), /Je vais bien/);
  assert.match(s('qui es tu'), /intelligence artificielle/);
  assert.match(s('que peux tu faire'), /situation/);
  assert.match(s('a bientot'), /À bientôt/);
});
test("civilités : une vraie question n'est jamais détournée vers une réponse toute faite", () => {
  const s = load().G360C.social;
  assert.equal(s('bonjour combien d alertes critiques sont ouvertes dans les parcs aujourd hui'), null);
  assert.equal(s('quelle est la houle au large de port gentil'), null);
  assert.equal(s('parle moi des elephants de foret'), null);
  assert.equal(s(''), null);
});
test("ça va : l'avatar ne prétend pas des données qu'il n'a pas (compte réel des IA)", () => {
  const c = load({ role: 'superviseur' }), s = c.G360C.social;
  c.MODS.forEach(m => { m.last = { etat: m.id === 'mt' ? 'ok' : 'attente', lines: ['x'] }; });
  assert.match(s('ca va'), /1 IA sur 8 me transmettent/);
});
