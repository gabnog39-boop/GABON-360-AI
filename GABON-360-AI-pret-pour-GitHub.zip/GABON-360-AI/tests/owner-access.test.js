const test = require('node:test');
const assert = require('node:assert/strict');
const handler = require('../api/owner-access');

const OWNER = '11111111-1111-4111-8111-111111111111';
const USER = '22222222-2222-4222-8222-222222222222';
const ENV = { SUPABASE_URL: 'https://x.supabase.co', SUPABASE_SERVICE_ROLE_KEY: 'svc', OWNER_USER_ID: OWNER };

function resMock() {
  return { statusCode: 200, headers: {}, payload: null,
    setHeader(k, v) { this.headers[k] = v; return this; },
    status(c) { this.statusCode = c; return this; },
    json(p) { this.payload = p; return this; } };
}
async function call(req, env = ENV, fetchImpl) {
  const keys = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'OWNER_USER_ID'];
  const prev = Object.fromEntries(keys.map(k => [k, process.env[k]]));
  keys.forEach(k => { if (env[k] === undefined) delete process.env[k]; else process.env[k] = env[k]; });
  const prevFetch = global.fetch; if (fetchImpl) global.fetch = fetchImpl;
  const res = resMock();
  try { await handler(req, res); return res; }
  finally { keys.forEach(k => { if (prev[k] === undefined) delete process.env[k]; else process.env[k] = prev[k]; }); global.fetch = prevFetch; }
}
const post = (body, token = 'tok') => ({ method: 'POST', headers: token ? { authorization: 'Bearer ' + token } : {}, body });
const okFetch = (callerId, changed = [{ id: USER }]) => async url =>
  String(url).includes('/auth/v1/user') ? { ok: true, json: async () => ({ id: callerId }) } : { ok: true, json: async () => changed };

test('GET refusé (405)', async () => { const r = await call({ method: 'GET', headers: {} }); assert.equal(r.statusCode, 405); });
test('variables serveur absentes (503)', async () => { assert.equal((await call(post({}), {})).statusCode, 503); });
test('sans jeton (401)', async () => { assert.equal((await call(post({ userId: USER, statut: 'actif' }, ''))).statusCode, 401); });
test('UUID invalide (400)', async () => { assert.equal((await call(post({ userId: 'abc', statut: 'actif' }))).statusCode, 400); });
test('statut inattendu (400)', async () => { assert.equal((await call(post({ userId: USER, statut: 'admin' }))).statusCode, 400); });
test('propriétaire non suspendable (409)', async () => { assert.equal((await call(post({ userId: OWNER, statut: 'suspendu' }))).statusCode, 409); });
test('utilisateur ordinaire refusé (403)', async () => {
  const r = await call(post({ userId: USER, statut: 'actif' }), ENV, okFetch(USER)); assert.equal(r.statusCode, 403);
});
test('propriétaire accepté (200)', async () => {
  const r = await call(post({ userId: USER, statut: 'suspendu' }), ENV, okFetch(OWNER)); assert.equal(r.statusCode, 200); assert.equal(r.payload.statut, 'suspendu');
});
test('profil introuvable (404)', async () => {
  const r = await call(post({ userId: USER, statut: 'actif' }), ENV, okFetch(OWNER, [])); assert.equal(r.statusCode, 404);
});
test('session invalide (401)', async () => {
  const r = await call(post({ userId: USER, statut: 'actif' }), ENV, async () => ({ ok: false })); assert.equal(r.statusCode, 401);
});
