const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..');
const png = f => { const b = fs.readFileSync(path.join(root, f)); assert.equal(b.slice(1, 4).toString(), 'PNG'); return [b.readUInt32BE(16), b.readUInt32BE(20)]; };

test('manifeste : installable (nom, démarrage, icônes existantes et de la bonne taille)', () => {
  const m = JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8'));
  assert.equal(m.display, 'standalone'); assert.equal(m.start_url, '/'); assert.ok(m.name && m.short_name);
  for (const i of m.icons) { const [w, h] = png(i.src.replace(/^\//, '')); assert.equal(`${w}x${h}`, i.sizes); }
  assert.ok(m.icons.some(i => i.purpose === 'maskable') && m.icons.some(i => i.sizes === '512x512' && i.purpose === 'any'));
  assert.deepEqual(png('icons/apple-touch-icon.png'), [180, 180]);
});
test("index.html déclare le manifeste, l'icône iPhone et charge les modules", () => {
  const h = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  for (const t of ['rel="manifest"', 'apple-touch-icon', 'theme-color', 'gabon360-centre.js']) assert.ok(h.includes(t), t);
});
function loadSw() {
  const listeners = {}, cached = [];
  const self = { addEventListener: (n, f) => { listeners[n] = f; }, location: { origin: 'https://app.test' }, skipWaiting() {}, clients: { claim() {} } };
  const ctx = { self, caches: { open: async () => ({ add: async u => cached.push(u), put: async () => {} }), keys: async () => [], match: async () => undefined },
    fetch: async () => ({ ok: true, clone() { return this; } }), URL, Response: class { constructor(b, o) { this.b = b; this.status = o && o.status; } }, Promise };
  vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(root, 'sw.js'), 'utf8'), ctx);
  return { listeners, cached };
}
const ev = (url, method = 'GET', mode = 'cors') => { const e = { request: { url, method, mode }, called: false, respondWith() { e.called = true; } }; return e; };
test('service worker : ne touche ni aux routes /api, ni aux autres domaines, ni aux envois', () => {
  const { listeners } = loadSw();
  for (const e of [ev('https://app.test/api/avatar'), ev('https://app.test/api/airspace'), ev('https://xyz.supabase.co/rest/v1/alertes'), ev('https://api.open-meteo.com/v1/forecast'), ev('https://app.test/index.html', 'POST')]) {
    listeners.fetch(e); assert.equal(e.called, false, e.request.url);
  }
});
test("service worker : la coquille de l'application passe par le réseau d'abord", () => {
  const { listeners } = loadSw(); const e = ev('https://app.test/', 'GET', 'navigate'); listeners.fetch(e); assert.equal(e.called, true);
});
test('service worker : précache sans échouer si un fichier manque', async () => {
  const { listeners, cached } = loadSw(); let p; listeners.install({ waitUntil: x => { p = x; } }); await p;
  assert.ok(cached.includes('/index.html') && cached.includes('/manifest.webmanifest'));
});
