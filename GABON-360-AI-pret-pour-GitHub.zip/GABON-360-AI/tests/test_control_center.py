"""Tests de contrat pour les registres et l'état du centre de contrôle."""
import os
import sys
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SERVER = os.path.join(ROOT, "server")
if SERVER not in sys.path:
    sys.path.insert(0, SERVER)

from ai.specialized_registry import SPECIALIZED_AI, event_contract, get_ai
from ai.option_registry import PAGE_OPTIONS, get_option
from monitoring.center_state import build_center_state


class ControlCenterContractTests(unittest.TestCase):
    def test_specialized_ai_keys_are_unique_and_avatar_exists(self):
        keys = [item.key for item in SPECIALIZED_AI]
        self.assertEqual(len(keys), len(set(keys)))
        self.assertGreaterEqual(len(keys), 20)
        self.assertEqual(get_ai("avatar").page, "avatar")

    def test_each_option_references_a_known_ai(self):
        known = {item.key for item in SPECIALIZED_AI}
        self.assertGreaterEqual(len(PAGE_OPTIONS), 40)
        self.assertTrue(all(option.ai in known for option in PAGE_OPTIONS))

    def test_sensitive_actions_keep_permissions_and_human_validation(self):
        for page, option, permission in (("drones", "controle", "admin"), ("cameras", "controle", "admin"), ("proprietaire", "permissions", "owner")):
            item = get_option(page, option)
            self.assertEqual(item.permission, permission)
            self.assertTrue(item.human_validation)

    def test_event_does_not_invent_location(self):
        event = event_contract(module="alertes", source="test", observation="ALERTE_TEST_7842", timestamp="2026-10-16T00:00:00Z")
        self.assertEqual(event["observation"], "ALERTE_TEST_7842")
        self.assertEqual(event["location"], {})
        self.assertTrue(event["requires_human_validation"])

    def test_center_state_does_not_claim_live_satellite_video(self):
        state = build_center_state({"status": "test"}, alerts_total=1)
        self.assertEqual(state["coverage"], "Gabon")
        self.assertEqual(state["alerts"]["total"], 1)
        self.assertTrue(state["alerts"]["validation_required"])
        self.assertFalse(state["live_satellite_video"])


if __name__ == "__main__":
    unittest.main()
