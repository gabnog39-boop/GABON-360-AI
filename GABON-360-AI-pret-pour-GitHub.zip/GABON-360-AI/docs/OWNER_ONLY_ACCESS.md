# GABON 360 AI — Accès contrôlé par le propriétaire

## Ce que ce correctif ajoute

- Route serveur `POST /api/owner-access` : seul l'identifiant Supabase défini par `OWNER_USER_ID` peut modifier le statut d'un profil.
- Les statuts autorisés sont `actif`, `suspendu` et `en_attente`.
- La session du demandeur est vérifiée auprès de Supabase Auth avant toute modification.
- La clé `SUPABASE_SERVICE_ROLE_KEY` reste côté serveur et n'est jamais envoyée au navigateur.
- Les méthodes autres que POST sont refusées, les réponses ne sont pas mises en cache et les erreurs internes ne révèlent pas les secrets.

## Configuration requise dans Vercel (Production, Preview et Development selon l'environnement utilisé)

Définir les variables serveur suivantes :

- `SUPABASE_URL` : URL du projet Supabase.
- `SUPABASE_SERVICE_ROLE_KEY` : clé secrète service-role Supabase, uniquement côté serveur.
- `OWNER_USER_ID` : UUID exact du compte Supabase du propriétaire unique.

Ne jamais mettre la service-role key ou un secret maître dans `index.html`, JavaScript public, dépôt public ou APK.

## Compatibilité de schéma

La route suppose que `public.profiles` contient une colonne `id` égale à l'UUID Auth et une colonne `statut` textuelle. Le statut `actif` est déjà utilisé par `api/assistant.js`. Vérifier le schéma réel avant déploiement. Si `profiles` impose d'autres colonnes obligatoires ou un enum différent, adapter la mise à jour après inspection du schéma, sans supprimer les données.

## Limites connues — à ne pas confondre avec une fonctionnalité achevée

- Cette route permet de modifier un statut si elle est correctement configurée ; elle ne fournit pas encore une interface d'administration utilisateur dans l'application.
- Elle ne crée pas à elle seule un lien de téléchargement privé, ne protège pas un APK déjà copié et ne change pas les réglages de partage GitHub/Vercel.
- Le contrôle de l'avatar dans `api/assistant.js` vérifie actuellement `statut === "actif"`. D'autres API de données doivent aussi vérifier l'identité et le statut avant d'exposer des informations protégées.
- Le propriétaire unique est déterminé par `OWNER_USER_ID` côté serveur, pas par un champ `role` modifiable depuis le client.
- Avant production : confirmer la configuration Supabase, examiner les politiques RLS, ajouter un journal d'audit, tester les comptes autorisés/non autorisés et vérifier le déploiement Vercel réel.

## Test manuel après déploiement

1. Sans jeton : attendre HTTP 401.
2. Avec session d'un utilisateur ordinaire : attendre HTTP 403.
3. Avec session propriétaire et UUID/statut valides : attendre HTTP 200 et vérifier le statut en base.
4. Avec méthode GET : attendre HTTP 405.
5. Avec UUID invalide ou statut inattendu : attendre HTTP 400.
6. Sans variable serveur requise : attendre HTTP 503.

Aucun de ces tests de production n'est considéré comme réalisé par la simple présence du fichier.
