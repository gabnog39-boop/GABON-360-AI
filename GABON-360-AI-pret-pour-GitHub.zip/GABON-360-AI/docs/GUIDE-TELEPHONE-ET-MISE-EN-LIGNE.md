# GABON 360 AI — mise en ligne et installation sur téléphone

## 1. Installer l'application sur le téléphone (une fois le site en ligne)
L'application s'installe depuis son adresse Vercel (https://gabon-360-ai.vercel.app) : c'est le site lui-même, avec icône, plein écran et ouverture rapide.
- **Android (Chrome)** : ouvrez l'adresse, connectez-vous, puis touchez « Installer » dans la carte de l'accueil, ou le menu ⋮ → « Installer l'application ».
- **iPhone (Safari uniquement)** : ouvrez l'adresse, touchez Partager → « Sur l'écran d'accueil ».
- Autorisez le **micro** (conversation vocale) et la **position** (cartes, missions) quand le téléphone le demande.
- Sans connexion, l'application s'ouvre mais n'affiche aucune donnée : tout vient du réseau.
- La reconnaissance vocale fonctionne le mieux avec Chrome sur Android ; sur iPhone elle est limitée.
- Icône provisoire (couleurs du drapeau + « 360 ») : remplacez `icons/icon-192.png`, `icons/icon-512.png`, `icons/icon-maskable-512.png` et `icons/apple-touch-icon.png` par votre logo officiel (mêmes tailles).

## 2. Mettre à jour GitHub et Vercel
1. Sur github.com, ouvrez le dépôt, créez une branche `test`.
2. **Add file → Upload files** : déposez le contenu du zip « mise à jour » (il ne contient que les fichiers nouveaux ou modifiés) en gardant les dossiers. Ne supprimez rien (surtout pas `api/parcs.js`).
3. Vercel crée un aperçu de la branche : testez-le (étape 4), puis fusionnez dans `main` (Pull Request → Merge).

## 3. Réglages (Vercel → Settings → Environment Variables)
`ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL` (conversation libre et rapports des IA), `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `OWNER_USER_ID`, et `FIRMS_MAP_KEY` (page Forêts et feux). Puis redéployez.
Supabase (facultatif) : voir `supabase/LISEZ-MOI.md` — diagnostic en lecture seule d'abord ; la protection reste inactive tant que l'UUID propriétaire n'est pas remplacé.

## 4. À vérifier sur l'aperçu, depuis le téléphone
1. Connexion, puis l'accueil : « Surveillance automatique » affiche des IA reliées.
2. Écrire « bonjour », puis une question libre (« parle-moi des éléphants de forêt ») : l'avatar répond. Sans clé Anthropic, il ne répond qu'aux civilités et aux données.
3. « Conversation vocale » : parler, entendre la réponse, parler de nouveau.
4. Ouvrir Météo, Eaux & océan, Espace aérien, Forêts & feux : données réelles, ou indisponibilité écrite clairement.

## 5. APK Android (facultatif, plus tard)
Le workflow GitHub `build-apk.yml` exige `GABON_360_AI_FINAL_CONSOLIDATED_V183_ICON.zip` à la racine du dépôt (projet Android, absent de mes archives). Une fois ce fichier ajouté : onglet Actions → « Build APK » → Run workflow ; l'APK est téléchargeable dans les artefacts de l'exécution. L'APK n'a pas la conversation libre ni les nouvelles pages tant que son `index.html` n'est pas mis à jour.
