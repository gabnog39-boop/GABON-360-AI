# GABON 360 AI — une IA par page, un seul avatar pour parler aux humains

## Circuit
1. **IA de page** (`MODS` dans `index.html`, + `gabon360-centre.js`) : lit les données réelles de sa page, produit une synthèse et des événements « à vérifier ».
2. **Veille automatique** (aucun clic, aucune question) : toutes les 60 s l'application actualise les IA ; l'avatar annonce lui-même chaque nouveau signalement (une seule fois, sans répéter une simple variation de valeur), les sources qui tombent ou reviennent, et un point de situation toutes les 30 min. Voix pour les priorités haute et critique, bandeau visible sur toutes les pages. Quand un signalement important arrive, l'IA concernée rédige automatiquement son rapport (8 requêtes IA par heure au plus), puis l'avatar fait la synthèse. L'opérateur peut suspendre la veille à l'accueil.
3. **Rapport de l'IA** (facultatif, bouton « Rapport de cette IA → avatar ») : appel `/api/avatar` avec `ai=<id>` ; le serveur applique la consigne propre à cette IA (`api/_specialists.js`) et rejette les identifiants inconnus.
4. **Avatar central** : reçoit synthèses, événements et rapports (contexte `llmAsk`), répond aux humains, cite l'IA source. Le bouton de l'accueil « Facultatif : forcer maintenant un rapport de chaque IA » reste disponible.

## Pages et sources
| Page | Source | Accès | Limites connues |
|---|---|---|---|
| Météo | Open-Meteo (prévision, 8 villes) | tous | modèle, pas de station officielle |
| Eaux et océan | Open-Meteo Marine (houle), GloFAS via Open-Meteo (débit, 5 points) | tous | modèles ; points fleuves à calibrer ; pollution/pêche illégale non connectées |
| Espace aérien | OpenSky Network via `/api/airspace` | superviseurs, analystes | ADS-B communautaire, couverture partielle, pas un radar ; vérifier les conditions d'usage d'OpenSky |
| Forêts et feux | NASA FIRMS via `/api/feux` (`FIRMS_MAP_KEY`) | superviseurs, analystes | point chaud ≠ incendie confirmé ; déforestation non connectée |

Reliées à l'avatar mais **en attente de source** (aucune connexion simulée ; l'avatar le dit dans chaque point de situation) : satellites Sentinel, drones, cybersécurité (journaux), paiements.

**Limite technique** : la veille tourne tant que l'application est ouverte dans le navigateur (les onglets en arrière-plan sont ralentis). Une surveillance 24 h/24 application fermée demande un planificateur côté serveur (Vercel Cron) et des notifications push : non inclus.

## Règles
- Aucune valeur inventée : source en erreur → « indisponible », sans événement.
- Seuils d'alerte **indicatifs** (`SEUILS` dans `gabon360-centre.js`) à fixer avec les services compétents.
- Toute détection reste « à vérifier » par une personne habilitée ; aucune action automatique.
- Ces fonctions ne sont **testées que sur des réponses simulées** : à vérifier en réel après déploiement.

## Conversation avec l'avatar
- **Libre** : avec `ANTHROPIC_API_KEY` et `ANTHROPIC_MODEL`, l'avatar discute de tout sujet, garde le fil des 8 derniers échanges et reste prudent : pour l'état du territoire il n'utilise que ce que les IA lui ont transmis et ne confirme jamais une alerte.
- **Sans IA de conversation** : il répond lui-même aux civilités (bonjour, merci, qui es-tu…) et aux questions sur les données enregistrées.
- **À la voix** : « Conversation vocale » (micro → réponse parlée → micro), s'arrête après deux silences.
- Le champ de saisie accepte 500 caractères par message.
