# GABON 360 AI — mise en ligne (GitHub, Vercel, Supabase, APK)

## 1. GitHub
1. Dans le dépôt privé existant, **fusionnez** ce contenu : ne supprimez pas les fichiers déjà présents qui ne figurent pas ici
   (notamment `api/parcs.js` : `index.html` appelle `/api/parcs` en repli, mais cette route n'est pas dans l'archive reçue).
2. Travaillez sur une branche `test`, ouvrez une Pull Request : la CI (`.github/workflows/ci.yml`) lance les tests.
3. Fusionnez dans `main` seulement quand la CI est verte et que Vercel a validé l'aperçu.

## 2. Vercel — variables d'environnement
Voir `.env.example`. Obligatoires : `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `OWNER_USER_ID`.
`ANTHROPIC_MODEL` est **nouveau** : sans lui, l'IA de l'avatar reste désactivée. `FIRMS_MAP_KEY` (clé gratuite NASA FIRMS) active la page Forêts et feux. Optionnelle : `SUPABASE_ANON_KEY` (sinon la clé publique actuelle est utilisée). Ne jamais mettre la clé `service_role` dans le code, le HTML ou l'APK.

## 3. Supabase
1. Rien n'est obligatoire. Lancer d'abord `supabase/00_diagnostic_lecture_seule.sql` ; la protection `supabase/01_protection_profils_optionnel.sql` n'agit qu'après remplacement de l'UUID propriétaire (annulation : `02`). Sans protection, rien n'empêche un utilisateur de modifier son propre `role`/`statut` si vos règles RLS sont trop larges.
2. Vérifier : avec un compte ordinaire, la modification de son statut doit être refusée.

## 4. Écran Utilisateurs (modifié)
Le changement de **statut** passe maintenant par `/api/owner-access` (propriétaire seul). Si la route n'est pas encore configurée (erreur 503/404), l'écran retombe sur l'ancien enregistrement direct, soumis à vos règles de base. Un administrateur non propriétaire reçoit « Action réservée au propriétaire ».
Le changement de **rôle** reste soumis aux règles de la base.

## 5. APK Android
- `build-apk.yml` est en lancement manuel et exige `GABON_360_AI_FINAL_CONSOLIDATED_V183_ICON.zip` à la racine (projet Android, absent de l'archive).
- Dans l'APK, les appels `/api/...` n'ont pas de domaine : définir `window.G360_API_BASE = "https://gabon-360-ai.vercel.app"` avant le chargement des scripts.

## 6. Essais à faire après déploiement (rien n'est validé par la seule présence des fichiers)
Connexion propriétaire · `GET /api/avatar` (configuré) · question à l'avatar avec un compte actif / suspendu · changement de statut par le propriétaire / refus pour un autre compte · import des parcs · test sur téléphone (voix, GPS).

## 7. IA par page
Voir `docs/IA_PAR_PAGE.md`. Après déploiement : ouvrir chaque nouvelle page (Météo, Eaux & océan, Espace aérien, Forêts & feux), vérifier que les données s'affichent ou que l'indisponibilité est explicite, puis lancer « Demander à chaque IA son rapport » à l'accueil.
