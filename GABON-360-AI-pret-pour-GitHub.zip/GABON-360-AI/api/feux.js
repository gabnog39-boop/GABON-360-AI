// Forêts et feux : points chauds satellitaires NASA FIRMS (VIIRS S-NPP, temps quasi réel) sur 24 h.
// Nécessite FIRMS_MAP_KEY (clé gratuite NASA FIRMS) côté serveur. Un point chaud n'est pas un incendie confirmé.
const { json, timeout, requireUser } = require('./_lib');
const ROLES = ['proprietaire', 'administrateur', 'superviseur', 'analyste'];
const AREA = '8.70,-3.98,14.52,2.32'; // ouest,sud,est,nord
let cache = { t: 0, data: null };

function parseCsv(text) {
  const lines = String(text || '').trim().split(/\r?\n/);
  const head = (lines.shift() || '').split(',');
  if (!head.includes('latitude') || !head.includes('longitude')) return null;
  const ix = n => head.indexOf(n);
  return lines.filter(Boolean).map(l => l.split(',')).map(c => ({
    lat: parseFloat(c[ix('latitude')]), lon: parseFloat(c[ix('longitude')]),
    date: c[ix('acq_date')], heure: c[ix('acq_time')], confiance: c[ix('confidence')],
    frp: parseFloat(c[ix('frp')]), jour_nuit: c[ix('daynight')]
  })).filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon));
}

module.exports = async (req, res) => {
  if (req.method !== 'GET') { res.setHeader('Allow', 'GET'); return json(res, 405, { error: 'Méthode non autorisée' }); }
  const mapKey = process.env.FIRMS_MAP_KEY;
  try {
    const a = await requireUser(req, ROLES);
    if (a.error) return json(res, a.error.status, { error: a.error.msg });
    if (!mapKey) return json(res, 503, { error: 'Source feux non configurée (FIRMS_MAP_KEY manquante côté serveur)' });
    if (cache.data && Date.now() - cache.t < 600000) return json(res, 200, cache.data);
    const r = await timeout(`https://firms.modaps.eosdis.nasa.gov/api/area/csv/${encodeURIComponent(mapKey)}/VIIRS_SNPP_NRT/${AREA}/1`, {}, 15000);
    if (!r.ok) return json(res, 502, { error: 'Source feux indisponible' });
    const pts = parseCsv(await r.text());
    if (!pts) return json(res, 502, { error: 'Réponse de la source feux invalide (clé refusée ?)' });
    const data = { source: 'NASA FIRMS — VIIRS S-NPP (temps quasi réel), 24 h', total: pts.length, points: pts.slice(0, 500) };
    cache = { t: Date.now(), data };
    return json(res, 200, data);
  } catch (e) {
    return json(res, e && e.name === 'AbortError' ? 504 : 500, { error: e && e.name === 'AbortError' ? 'Délai dépassé' : 'Erreur interne feux' });
  }
};
module.exports._parseCsv = parseCsv;
