// Relais serveur facultatif pour l'avatar central. La clé Anthropic reste côté serveur.
const SB = (process.env.SUPABASE_URL || "https://ztucadvgowsdixomoikm.supabase.co").replace(/\/$/, "");
const SUPABASE_PUBLIC_KEY = process.env.SUPABASE_ANON_KEY || "sb_publishable_J1gbjWaEuekRUZ2Z2VpUrQ_CXS645jS";
const MAX_BODY_CHARS = 24000;
const MAX_HIST_TURNS = 8;
const MAX_HIST_CHARS = 700;
const MAX_QUESTION_CHARS = 500;
const { SPECIALISTS, buildSystem } = require("./_specialists");

// Historique → messages alternés user/assistant (commence par user, finit par le message courant).
function buildMessages(hist, finalUser) {
  const out = [];
  for (const h of hist) {
    const role = h.r === "u" ? "user" : "assistant";
    if (!out.length && role !== "user") continue;
    if (out.length && out[out.length - 1].role === role) { out[out.length - 1].content += "\n" + h.t.trim(); continue; }
    out.push({ role, content: h.t.trim() });
  }
  if (out.length && out[out.length - 1].role === "user") out.pop();
  out.push({ role: "user", content: finalUser });
  return out;
}
const MAX_CONTEXT_CHARS = 12000;

function json(res, status, payload) {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  return res.status(status).json(payload);
}
function fetchWithTimeout(url, options = {}, ms = 12000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timer));
}

module.exports = async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  const model = process.env.ANTHROPIC_MODEL;

  if (req.method === "GET") {
    // Ce champ indique uniquement la présence des variables, pas une connexion testée.
    return json(res, 200, { ok: Boolean(apiKey && model), configured: Boolean(apiKey && model) });
  }
  if (req.method !== "POST") {
    res.setHeader("Allow", "GET, POST");
    return json(res, 405, { error: "Méthode non autorisée" });
  }
  if (!apiKey || !model) return json(res, 503, { error: "Service IA non configuré côté serveur" });

  try {
    const auth = req.headers.authorization || "";
    const token = auth.replace(/^Bearer\s+/i, "").trim();
    if (!token || token.length > 4096) return json(res, 401, { error: "Connexion requise" });

    let body = req.body;
    if (typeof body === "string") {
      if (body.length > MAX_BODY_CHARS) return json(res, 413, { error: "Requête trop volumineuse" });
      try { body = JSON.parse(body); } catch { return json(res, 400, { error: "Format de requête invalide" }); }
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) return json(res, 400, { error: "Requête invalide" });
    const question = typeof body.q === "string" ? body.q.trim() : "";
    const context = typeof body.ctx === "string" ? body.ctx : "";
    const aiId = typeof body.ai === "string" ? body.ai : "";
    if (aiId && !SPECIALISTS[aiId]) return json(res, 400, { error: "IA spécialisée inconnue" });
    let hist = [];
    if (body.hist !== undefined) {
      const ok = Array.isArray(body.hist) && body.hist.length <= MAX_HIST_TURNS &&
        body.hist.every(h => h && (h.r === "u" || h.r === "a") && typeof h.t === "string" && h.t.trim() && h.t.length <= MAX_HIST_CHARS);
      if (!ok) return json(res, 400, { error: "Historique de conversation invalide" });
      hist = aiId ? [] : body.hist;
    }
    if (JSON.stringify(body).length > MAX_BODY_CHARS) return json(res, 413, { error: "Requête trop volumineuse" });
    if (!question) return json(res, 400, { error: "Question manquante" });
    if (question.length > MAX_QUESTION_CHARS || context.length > MAX_CONTEXT_CHARS) {
      return json(res, 413, { error: "Question ou contexte trop volumineux" });
    }

    const userResponse = await fetchWithTimeout(`${SB}/auth/v1/user`, {
      headers: { apikey: SUPABASE_PUBLIC_KEY, Authorization: `Bearer ${token}` }
    });
    if (!userResponse.ok) return json(res, 401, { error: "Session invalide" });
    const user = await userResponse.json();
    if (!user || typeof user.id !== "string") return json(res, 401, { error: "Session invalide" });

    const profileResponse = await fetchWithTimeout(`${SB}/rest/v1/profiles?id=eq.${encodeURIComponent(user.id)}&select=statut`, {
      headers: { apikey: SUPABASE_PUBLIC_KEY, Authorization: `Bearer ${token}` }
    });
    if (!profileResponse.ok) return json(res, 503, { error: "Vérification du compte indisponible" });
    const profiles = await profileResponse.json();
    if (!Array.isArray(profiles) || !profiles[0] || profiles[0].statut !== "actif") {
      return json(res, 403, { error: "Compte non actif" });
    }

    const response = await fetchWithTimeout("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model,
        max_tokens: 600,
        system: buildSystem(aiId),
        messages: buildMessages(hist, `Contexte enregistré de la plateforme :\n${context}\n\nQuestion : ${question}`)
      })
    }, 20000);

    if (!response.ok) {
      // Ne pas transmettre au navigateur le message interne du fournisseur.
      return json(res, 502, { error: "Le service IA a refusé la requête ou est indisponible" });
    }
    const result = await response.json();
    const answer = Array.isArray(result.content)
      ? result.content.filter(item => item && item.type === "text").map(item => item.text).join("\n").trim()
      : "";
    if (!answer) return json(res, 502, { error: "Le service IA n'a pas fourni de réponse exploitable" });
    return json(res, 200, { text: answer });
  } catch (error) {
    const timeout = error && error.name === "AbortError";
    return json(res, timeout ? 504 : 500, { error: timeout ? "Délai de connexion dépassé" : "Erreur interne du service IA" });
  }
};
