// Route de compatibilité : l'interface existante appelle /api/avatar.
// La vérification de session et l'appel Anthropic restent centralisés dans assistant.js.
module.exports = require('./assistant');
