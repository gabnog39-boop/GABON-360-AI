// Espace aérien : aéronefs reçus par ADS-B communautaire (OpenSky Network) dans une boîte englobant le Gabon.
// Couverture PARTIELLE : ce n'est pas un radar et cela ne permet pas, seul, de qualifier une intrusion.
// Vérifier les conditions d'utilisation d'OpenSky pour un usage institutionnel/commercial avant mise en production.
const { json, timeout, requireUser } = require('./_lib');
const ROLES = ['proprietaire', 'administrateur', 'superviseur', 'analyste'];
const BBOX = { lamin: -3.98, lomin: 8.70, lamax: 2.32, lomax: 14.52 };
let cache = { t: 0, data: null };

function parse(raw) {
  const states = Array.isArray(raw && raw.states) ? raw.states : [];
  const avions = states.filter(s => Array.isArray(s) && s[5] != null && s[6] != null).slice(0, 300).map(s => ({
    icao24: s[0], indicatif: String(s[1] || '').trim(), pays: s[2], lon: s[5], lat: s[6],
    alt_m: s[7] != null ? s[7] : s[13], sol: !!s[8], vitesse_ms: s[9], cap: s[10], vrate: s[11], squawk: s[14], contact: s[4]
  }));
  return { avions, total_recu: states.length, heure_source: raw && raw.time ? new Date(raw.time * 1000).toISOString() : null };
}

module.exports = async (req, res) => {
  if (req.method !== 'GET') { res.setHeader('Allow', 'GET'); return json(res, 405, { error: 'Méthode non autorisée' }); }
  try {
    const a = await requireUser(req, ROLES);
    if (a.error) return json(res, a.error.status, { error: a.error.msg });
    if (cache.data && Date.now() - cache.t < 30000) return json(res, 200, cache.data);
    const q = new URLSearchParams(BBOX).toString();
    const r = await timeout(`https://opensky-network.org/api/states/all?${q}`, { headers: { Accept: 'application/json' } }, 12000);
    if (!r.ok) return json(res, r.status === 429 ? 429 : 502, { error: r.status === 429 ? 'Limite de la source aérienne atteinte, réessayez plus tard' : 'Source aérienne indisponible' });
    const data = {
      source: 'OpenSky Network (ADS-B communautaire)',
      couverture: 'partielle : seuls les aéronefs avec transpondeur ADS-B reçus par des récepteurs volontaires sont listés',
      boite: BBOX, ...parse(await r.json())
    };
    cache = { t: Date.now(), data };
    return json(res, 200, data);
  } catch (e) {
    return json(res, e && e.name === 'AbortError' ? 504 : 500, { error: e && e.name === 'AbortError' ? 'Délai dépassé' : 'Erreur interne espace aérien' });
  }
};
module.exports._parse = parse;
