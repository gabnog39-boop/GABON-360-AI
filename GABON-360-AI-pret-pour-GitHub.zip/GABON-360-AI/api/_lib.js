// Utilitaires partagés des routes (préfixe « _ » : non exposé comme route).
function config() {
  return {
    sb: (process.env.SUPABASE_URL || 'https://ztucadvgowsdixomoikm.supabase.co').replace(/\/$/, ''),
    key: process.env.SUPABASE_ANON_KEY || 'sb_publishable_J1gbjWaEuekRUZ2Z2VpUrQ_CXS645jS'
  };
}
function json(res, status, payload) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  return res.status(status).json(payload);
}
function timeout(url, options = {}, ms = 10000) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  return fetch(url, { ...options, signal: c.signal }).finally(() => clearTimeout(t));
}
// Vérifie la session Supabase, le statut « actif » et (optionnel) le rôle. Retourne { user, profile } ou { error }.
async function requireUser(req, roles) {
  const { sb, key } = config();
  const token = ((req.headers && req.headers.authorization) || '').replace(/^Bearer\s+/i, '').trim();
  if (!token || token.length > 4096) return { error: { status: 401, msg: 'Connexion requise' } };
  const u = await timeout(`${sb}/auth/v1/user`, { headers: { apikey: key, Authorization: `Bearer ${token}` } });
  if (!u.ok) return { error: { status: 401, msg: 'Session invalide' } };
  const user = await u.json();
  if (!user || typeof user.id !== 'string') return { error: { status: 401, msg: 'Session invalide' } };
  const p = await timeout(`${sb}/rest/v1/profiles?id=eq.${encodeURIComponent(user.id)}&select=statut,role`, { headers: { apikey: key, Authorization: `Bearer ${token}` } });
  if (!p.ok) return { error: { status: 503, msg: 'Vérification du compte indisponible' } };
  const rows = await p.json();
  const profile = Array.isArray(rows) ? rows[0] : null;
  if (!profile || profile.statut !== 'actif') return { error: { status: 403, msg: 'Compte non actif' } };
  if (roles && !roles.includes(profile.role)) return { error: { status: 403, msg: 'Réservé aux superviseurs et analystes' } };
  return { user, profile };
}
module.exports = { json, timeout, requireUser };
