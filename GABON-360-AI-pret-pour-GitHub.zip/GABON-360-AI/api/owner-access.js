// GABON 360 AI — gestion des autorisations réservée au propriétaire.
// Variables Vercel requises : SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, OWNER_USER_ID.
// Ne jamais utiliser la clé service_role dans le navigateur ou dans l'APK.
const MAX_BODY_CHARS = 3000;

function reply(res, status, payload) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Pragma', 'no-cache');
  return res.status(status).json(payload);
}
function timeoutFetch(url, options = {}, ms = 10000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timer));
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return reply(res, 405, { error: 'Méthode non autorisée' });
  }

  const supabaseUrl = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const ownerId = process.env.OWNER_USER_ID;
  if (!supabaseUrl || !serviceKey || !ownerId) {
    return reply(res, 503, { error: 'Gestion propriétaire non configurée côté serveur' });
  }

  try {
    const auth = req.headers.authorization || '';
    const token = auth.replace(/^Bearer\s+/i, '').trim();
    if (!token || token.length > 4096) return reply(res, 401, { error: 'Connexion requise' });

    let body = req.body;
    if (typeof body === 'string') {
      if (body.length > MAX_BODY_CHARS) return reply(res, 413, { error: 'Requête trop volumineuse' });
      try { body = JSON.parse(body); } catch { return reply(res, 400, { error: 'Format invalide' }); }
    }
    if (!body || typeof body !== 'object' || Array.isArray(body) || JSON.stringify(body).length > MAX_BODY_CHARS) {
      return reply(res, 400, { error: 'Requête invalide' });
    }
    const userId = typeof body.userId === 'string' ? body.userId.trim() : '';
    const statut = body.statut;
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(userId)) {
      return reply(res, 400, { error: 'Identifiant utilisateur invalide' });
    }
    if (!['actif', 'suspendu', 'en_attente'].includes(statut)) {
      return reply(res, 400, { error: 'Statut non autorisé' });
    }
    if (userId === ownerId && statut !== 'actif') {
      return reply(res, 409, { error: 'Le compte propriétaire ne peut pas être suspendu par cette route' });
    }

    // Vérifier la session auprès de Supabase Auth, puis comparer son UUID à l'unique propriétaire configuré.
    const who = await timeoutFetch(`${supabaseUrl}/auth/v1/user`, {
      headers: { apikey: serviceKey, Authorization: `Bearer ${token}` }
    });
    if (!who.ok) return reply(res, 401, { error: 'Session invalide' });
    const caller = await who.json();
    if (!caller || caller.id !== ownerId) return reply(res, 403, { error: 'Action réservée au propriétaire' });

    // La clé service_role est utilisée uniquement côté serveur après la vérification stricte du propriétaire.
    const update = await timeoutFetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}`, {
      method: 'PATCH',
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        'Content-Type': 'application/json',
        Prefer: 'return=representation'
      },
      body: JSON.stringify({ statut })
    });
    if (!update.ok) return reply(res, 502, { error: 'Mise à jour du compte impossible' });
    const changed = await update.json();
    if (!Array.isArray(changed) || changed.length !== 1) {
      return reply(res, 404, { error: 'Compte introuvable ou schéma profiles incompatible' });
    }
    return reply(res, 200, { ok: true, userId, statut });
  } catch (err) {
    return reply(res, err && err.name === 'AbortError' ? 504 : 500,
      { error: err && err.name === 'AbortError' ? 'Délai dépassé' : 'Erreur interne de gestion des accès' });
  }
};
