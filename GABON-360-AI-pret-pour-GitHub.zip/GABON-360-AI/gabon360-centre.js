/* GABON 360 AI — IA spécialisées par page, reliées à l'avatar central.
   Ajoute les pages Météo, Eaux et océan, Espace aérien, Forêts et feux.
   Principes : données réelles uniquement (sinon « indisponible »), aucune valeur inventée,
   seuils indicatifs, toute alerte reste « à vérifier » par une personne habilitée.
   Dépend des variables globales de index.html : MODS, EVT, D, mkEv, el, $, me, ses, tab, avSay, llmAsk, loadAll, api. */
(function () {
  'use strict';
  var API = function () { return window.G360_API_BASE || ''; };
  var ROLES_OK = ['proprietaire', 'administrateur', 'superviseur', 'analyste'];
  var BB = { lamin: -3.98, lomin: 8.70, lamax: 2.32, lomax: 14.52 };

  var VILLES = [
    { nom: 'Libreville', lat: 0.4162, lon: 9.4673 }, { nom: 'Port-Gentil', lat: -0.7193, lon: 8.7815 },
    { nom: 'Franceville', lat: -1.6333, lon: 13.5833 }, { nom: 'Oyem', lat: 1.5993, lon: 11.5793 },
    { nom: 'Lambaréné', lat: -0.7001, lon: 10.2406 }, { nom: 'Tchibanga', lat: -2.85, lon: 11.0167 },
    { nom: 'Makokou', lat: 0.5738, lon: 12.8642 }, { nom: 'Koulamoutou', lat: -1.1297, lon: 12.4736 }
  ];
  var MARINS = [
    { nom: 'Large de Libreville', lat: 0.30, lon: 8.80 }, { nom: 'Large de Port-Gentil', lat: -1.00, lon: 8.30 },
    { nom: 'Large de Mayumba', lat: -3.50, lon: 10.20 }
  ];
  var FLEUVES = [
    { nom: 'Ogooué (Lambaréné)', lat: -0.70, lon: 10.23 }, { nom: 'Ogooué (Ndjolé)', lat: -0.18, lon: 10.76 },
    { nom: 'Ivindo (Makokou)', lat: 0.57, lon: 12.86 }, { nom: 'Nyanga (Tchibanga)', lat: -2.85, lon: 11.02 },
    { nom: 'Mpassa (Franceville)', lat: -1.63, lon: 13.58 }
  ];
  // Seuils INDICATIFS (à fixer avec les services compétents) : ils déclenchent une vérification, jamais une conclusion.
  var SEUILS = { rafaleHaute: 60, rafaleCritique: 90, pluieHaute: 50, pluieCritique: 100, houleHaute: 2.5, houleCritique: 4, crueHausse: 0.30 };
  var URG = { '7500': 'détournement présumé (code 7500)', '7600': 'panne radio (code 7600)', '7700': 'urgence générale (code 7700)' };
  var TTL = { mt: 900e3, mar: 900e3, riv: 3600e3, ea: 120e3, fo: 1800e3 };

  var X = {}; // état des sources : X[k] = { ok, data, err, t, restreint }

  function canSup() { try { return ROLES_OK.indexOf(me.role) >= 0; } catch (e) { return false; } }
  function n1(v, u) { return v == null || isNaN(v) ? '—' : (Math.round(v * 10) / 10) + ' ' + u; }
  function tmo(url, opt, ms) {
    var c = new AbortController(), t = setTimeout(function () { c.abort(); }, ms || 9000);
    opt = Object.assign({}, opt || {}, { signal: c.signal });
    return fetch(url, opt).then(function (r) { clearTimeout(t); return r; }, function (e) { clearTimeout(t); throw e; });
  }
  function jget(url, opt, ms) {
    return tmo(url, opt, ms).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) throw new Error((j && j.error) || ('HTTP ' + r.status));
        return j;
      });
    });
  }
  function arr(j) { return Array.isArray(j) ? j : [j]; }
  function ll(list) { return [list.map(function (v) { return v.lat; }).join(','), list.map(function (v) { return v.lon; }).join(',')]; }
  function nearestIdx(times, now) {
    var best = 0, bd = Infinity;
    for (var i = 0; i < times.length; i++) { var d = Math.abs(new Date(times[i] + 'Z').getTime() - now); if (d < bd) { bd = d; best = i; } }
    return best;
  }
  function maxOf(a) { var m = null; (a || []).forEach(function (v) { if (v != null && (m == null || v > m)) m = v; }); return m; }

  /* ---------- Sources ---------- */
  function fMeteo() {
    var p = ll(VILLES);
    return jget('https://api.open-meteo.com/v1/forecast?latitude=' + p[0] + '&longitude=' + p[1] +
      '&current=temperature_2m,precipitation,wind_speed_10m,wind_gusts_10m&daily=precipitation_sum,wind_gusts_10m_max&forecast_days=3&timezone=GMT&wind_speed_unit=kmh')
      .then(function (j) {
        j = arr(j);
        return VILLES.map(function (v, i) {
          var o = j[i] || {}, c = o.current || {}, d = o.daily || {};
          return { nom: v.nom, lat: v.lat, lon: v.lon, temp: c.temperature_2m, pluie: c.precipitation, vent: c.wind_speed_10m, rafale: c.wind_gusts_10m,
            heure: c.time, pluieMax3j: maxOf(d.precipitation_sum), rafaleMax3j: maxOf(d.wind_gusts_10m_max) };
        });
      });
  }
  function fMer() {
    var p = ll(MARINS);
    return jget('https://marine-api.open-meteo.com/v1/marine?latitude=' + p[0] + '&longitude=' + p[1] +
      '&hourly=wave_height,wave_period,sea_surface_temperature&forecast_days=2&timezone=GMT').then(function (j) {
      j = arr(j);
      return MARINS.map(function (v, i) {
        var h = (j[i] || {}).hourly || {}, t = h.time || [], k = nearestIdx(t, Date.now());
        var h24 = (h.wave_height || []).slice(k, k + 24);
        return { nom: v.nom, lat: v.lat, lon: v.lon, houle: (h.wave_height || [])[k], periode: (h.wave_period || [])[k],
          sst: (h.sea_surface_temperature || [])[k], houleMax24h: maxOf(h24), heure: t[k] };
      });
    });
  }
  function fRiv() {
    var p = ll(FLEUVES);
    return jget('https://flood-api.open-meteo.com/v1/flood?latitude=' + p[0] + '&longitude=' + p[1] +
      '&daily=river_discharge&past_days=3&forecast_days=7&timezone=GMT').then(function (j) {
      j = arr(j);
      return FLEUVES.map(function (v, i) {
        var q = ((j[i] || {}).daily || {}).river_discharge || [], a = q[3], b = q[q.length - 1];
        var tend = a != null && b != null && a > 0 ? (b - a) / a : null;
        return { nom: v.nom, lat: v.lat, lon: v.lon, debit: a, debitFin: b, tendance: tend };
      });
    });
  }
  function fAir() {
    return jget(API() + '/api/airspace', { headers: { Authorization: 'Bearer ' + ses.access_token } }, 15000);
  }
  function fFeux() {
    return jget(API() + '/api/feux', { headers: { Authorization: 'Bearer ' + ses.access_token } }, 18000);
  }
  var FN = { mt: fMeteo, mar: fMer, riv: fRiv, ea: fAir, fo: fFeux };

  function refreshOne(k, force) {
    var cur = X[k], age = cur ? Date.now() - cur.t : Infinity;
    var ttl = cur && !cur.ok ? 60e3 : TTL[k];
    if (!force && age < ttl) return Promise.resolve();
    if ((k === 'ea' || k === 'fo') && !canSup()) { X[k] = { ok: false, restreint: true, t: Date.now() }; return Promise.resolve(); }
    if (force && age < 15e3) return Promise.resolve();
    return Promise.resolve().then(FN[k]).then(function (data) { X[k] = { ok: true, data: data, t: Date.now() }; if (k === 'fo') return loadParcs().then(function (pc) { X._parcs = pc; }); },
      function (e) { X[k] = { ok: false, err: (e && e.name === 'AbortError') ? 'délai dépassé' : (e && e.message) || 'erreur', t: Date.now() }; });
  }
  function load(force, only) {
    var keys = only || Object.keys(FN);
    return Promise.all(keys.map(function (k) { return refreshOne(k, force); })).then(function () { return X; }, function () { return X; });
  }

  /* ---------- Géométrie : point dans les parcs ---------- */
  function inRing(x, y, ring) {
    var c = false;
    for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      var xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
      if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) c = !c;
    }
    return c;
  }
  function inPoly(x, y, rings) {
    if (!rings || !rings.length || !inRing(x, y, rings[0])) return false;
    for (var h = 1; h < rings.length; h++) if (inRing(x, y, rings[h])) return false;
    return true;
  }
  function inGeo(lon, lat, geom) {
    if (!geom) return false;
    if (geom.type === 'Polygon') return inPoly(lon, lat, geom.coordinates);
    if (geom.type === 'MultiPolygon') return geom.coordinates.some(function (p) { return inPoly(lon, lat, p); });
    return false;
  }
  function parkOf(lon, lat, parcs) {
    var names = Object.keys(parcs || {});
    for (var i = 0; i < names.length; i++) {
      if (names[i] === '_frontiere') continue;
      var gj = parcs[names[i]] && parcs[names[i]].geojson, fs = gj && (gj.features || (gj.type === 'Feature' ? [gj] : []));
      if ((fs || []).some(function (f) { return inGeo(lon, lat, f && f.geometry); })) return names[i];
    }
    return null;
  }
  var PARCS_CACHE = null;
  function loadParcs() {
    try { if (typeof PKB !== 'undefined' && PKB && Object.keys(PKB).length) return Promise.resolve(PKB); } catch (e) { /* ignore */ }
    if (PARCS_CACHE) return Promise.resolve(PARCS_CACHE);
    return api('/rest/v1/parcs_limites?select=parc,geojson').then(function (r) {
      var o = {}; (r || []).forEach(function (x) { o[x.parc] = x; }); PARCS_CACHE = o; return o;
    }).catch(function () { return {}; });
  }

  /* ---------- IA de chaque page : synthèse + événements pour l'avatar ---------- */
  function ext() { return (typeof D !== 'undefined' && D && D.ext) || X; }
  function srcState(s, nom, cfgMsg) {
    if (!s) return { etat: 'attente', lines: ['Données en cours de chargement…'], ev: [] };
    if (s.restreint) return { etat: 'restreint', lines: ['Réservé aux superviseurs et analystes.'], ev: [] };
    if (!s.ok) {
      var conf = /non configur|manquante/i.test(s.err || '');
      return { etat: conf ? 'attente' : 'erreur', lines: [nom + ' : source indisponible (' + s.err + '). Aucune donnée n\'est inventée.' + (conf && cfgMsg ? ' ' + cfgMsg : '')], ev: [] };
    }
    return null;
  }
  function sumMt() {
    var s = ext().mt, e = srcState(s, 'Météo'); if (e) return e;
    var d = s.data, ev = [], rg = null, pl = null;
    d.forEach(function (v) {
      var g = Math.max(v.rafale || 0, v.rafaleMax3j || 0), p = v.pluieMax3j || 0;
      if (!rg || g > rg.g) rg = { g: g, n: v.nom };
      if (!pl || p > pl.p) pl = { p: p, n: v.nom };
      if (g >= SEUILS.rafaleHaute) ev.push(mkEv('mt', 'météo', 'Rafales prévues jusqu\'à ' + Math.round(g) + ' km/h à ' + v.nom, g >= SEUILS.rafaleCritique ? 'critique' : 'haute', { lat: v.lat, lon: v.lon, statut: 'prévision à vérifier', src: 'Open-Meteo' }));
      if (p >= SEUILS.pluieHaute) ev.push(mkEv('mt', 'météo', 'Pluie prévue jusqu\'à ' + Math.round(p) + ' mm/jour à ' + v.nom, p >= SEUILS.pluieCritique ? 'critique' : 'haute', { lat: v.lat, lon: v.lon, statut: 'prévision à vérifier', src: 'Open-Meteo' }));
    });
    return { etat: 'ok', lines: [d.length + ' villes interrogées (prévision 3 jours) : rafales max ' + n1(rg.g, 'km/h') + ' à ' + rg.n + ', pluie max ' + n1(pl.p, 'mm/jour') + ' à ' + pl.n + '.',
      'Source : Open-Meteo (modèles de prévision, pas des stations officielles). Seuils d\'alerte indicatifs.'], ev: ev };
  }
  function sumEo() {
    var m = ext().mar, r = ext().riv, em = srcState(m, 'Océan'), er = srcState(r, 'Fleuves');
    if (em && er) return em.etat === 'restreint' ? em : { etat: em.etat, lines: em.lines.concat(er.lines), ev: [] };
    var ev = [], lines = [];
    if (m && m.ok) {
      var top = null;
      m.data.forEach(function (v) {
        var h = Math.max(v.houle || 0, v.houleMax24h || 0);
        if (!top || h > top.h) top = { h: h, n: v.nom };
        if (h >= SEUILS.houleHaute) ev.push(mkEv('eo', 'mer', 'Houle prévue jusqu\'à ' + n1(h, 'm') + ' — ' + v.nom, h >= SEUILS.houleCritique ? 'critique' : 'haute', { lat: v.lat, lon: v.lon, statut: 'prévision à vérifier', src: 'Open-Meteo Marine' }));
      });
      lines.push('Mer (large, prévision) : houle max ' + n1(top.h, 'm') + ' — ' + top.n + '.');
    } else lines.push(em.lines[0]);
    if (r && r.ok) {
      var up = r.data.filter(function (v) { return v.tendance != null && v.tendance >= SEUILS.crueHausse; });
      up.forEach(function (v) { ev.push(mkEv('eo', 'eau', 'Débit modélisé en hausse de ' + Math.round(v.tendance * 100) + ' % sur 7 jours — ' + v.nom, 'normale', { lat: v.lat, lon: v.lon, statut: 'modèle à vérifier', src: 'Open-Meteo GloFAS' })); });
      lines.push('Fleuves : ' + r.data.filter(function (v) { return v.debit != null; }).length + '/' + r.data.length + ' points avec valeur de modèle, ' + up.length + ' en hausse marquée.');
    } else lines.push(er.lines[0]);
    lines.push('Valeurs de modèles (pas de capteur ni de station branchés). Pollution et pêche illégale : aucune source connectée.');
    return { etat: (m && m.ok && r && r.ok) ? 'ok' : 'partiel', lines: lines, ev: ev };
  }
  function sumEa() {
    var s = ext().ea, e = srcState(s, 'Espace aérien'); if (e) return e;
    var av = s.data.avions || [], air = av.filter(function (a) { return !a.sol; }), ev = [];
    av.forEach(function (a) {
      var u = URG[String(a.squawk)];
      if (u) ev.push(mkEv('ea', 'aéronef', 'Aéronef ' + (a.indicatif || a.icao24) + ' : ' + u, 'critique', { lat: a.lat, lon: a.lon, statut: 'à vérifier', src: 'OpenSky ADS-B' }));
    });
    return { etat: 'partiel', lines: [av.length + ' aéronef(s) reçu(s) par ADS-B communautaire (' + air.length + ' en vol, ' + (av.length - air.length) + ' au sol), ' + ev.length + ' code(s) d\'urgence.',
      'Couverture partielle : ce n\'est pas un radar. L\'identification des intrusions ou franchissements exige des sources autorisées de l\'État (non connectées).'], ev: ev };
  }
  function sumFo() {
    var s = ext().fo, e = srcState(s, 'Feux', 'Ajouter la clé gratuite NASA FIRMS (FIRMS_MAP_KEY) dans Vercel.'); if (e) return e;
    var pts = s.data.points || [], parcs = ext()._parcs || {}, ev = [], dans = 0, hauts = 0;
    pts.forEach(function (p) {
      p.parc = parkOf(p.lon, p.lat, parcs);
      if (p.confiance === 'h' || p.confiance === 'high') hauts++;
      if (p.parc) {
        dans++;
        ev.push(mkEv('fo', 'feu', 'Point chaud dans le parc ' + p.parc + ' (' + p.date + ' ' + p.heure + ' UTC)', (p.confiance === 'h' || p.confiance === 'high') ? 'haute' : 'normale', { lat: p.lat, lon: p.lon, statut: 'à vérifier', src: 'NASA FIRMS' }));
      }
    });
    if (!dans && pts.length >= 10) ev.push(mkEv('fo', 'feu', pts.length + ' points chauds détectés sur 24 h au Gabon', 'normale', { statut: 'à vérifier', src: 'NASA FIRMS' }));
    return { etat: 'ok', lines: [s.data.total + ' point(s) chaud(s) sur 24 h, dont ' + hauts + ' de confiance élevée et ' + dans + ' dans un parc national' + (Object.keys(parcs).length ? '.' : ' (limites des parcs non chargées).'),
      'Un point chaud est une détection satellitaire de chaleur : ce n\'est pas un incendie confirmé (brûlis agricoles fréquents). Déforestation : aucune source connectée.'], ev: ev };
  }

  /* ---------- Rapport de l'IA spécialisée → avatar central ---------- */
  function dataFor(id) {
    var x = ext();
    if (id === 'mt' && x.mt && x.mt.ok) return x.mt.data;
    if (id === 'eo') return { mer: x.mar && x.mar.ok ? x.mar.data : null, fleuves: x.riv && x.riv.ok ? x.riv.data : null };
    if (id === 'ea' && x.ea && x.ea.ok) {
      var av = x.ea.data.avions || [];
      return { total: av.length, urgences: av.filter(function (a) { return URG[String(a.squawk)]; }), echantillon: av.slice(0, 12) };
    }
    if (id === 'fo' && x.fo && x.fo.ok) return { total: x.fo.data.total, dans_parcs: (x.fo.data.points || []).filter(function (p) { return p.parc; }).slice(0, 15), echantillon: (x.fo.data.points || []).slice(0, 10) };
    return null;
  }
  function specialist(m, out) {
    var ctx = JSON.stringify({
      module: m.nom, role: m.role, etat: m.last && m.last.etat, synthese: m.last && m.last.lines,
      evenements: EVT.filter(function (e) { return e.mod === m.id; }).slice(0, 8).map(function (e) { return { titre: e.titre, priorite: e.prio, statut: e.statut, source: e.src, lat: e.lat, lon: e.lon }; }),
      donnees: dataFor(m.id), horodatage: new Date().toISOString()
    }).slice(0, 11000);
    return fetch(API() + '/api/avatar', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + ses.access_token },
      body: JSON.stringify({ q: 'Rédige le rapport de ton domaine pour l\'avatar central.', ctx: ctx, ai: m.id }) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw new Error(j.error || 'erreur'); if (!j.text) throw new Error('réponse vide'); return j.text; }); })
      .then(function (txt) {
        m.rapportIA = { texte: txt, t: new Date().toISOString() };
        if (out) out.textContent = txt + '\n\n(Rapport rédigé par IA, transmis à l\'avatar central ; à vérifier.)';
        avSay('Rapport transmis par « ' + m.nom + ' » :\n' + txt, 0, true);
        return txt;
      });
  }
  function addSpecialist(box, m) {
    if (box.querySelector('[data-g360-spec]')) return;
    var b = el('button', '', 'Rapport de cette IA → avatar'); b.setAttribute('data-g360-spec', '1');
    var out = el('div', 'note', m.rapportIA ? m.rapportIA.texte : ''); out.style.whiteSpace = 'pre-line'; out.style.marginTop = '6px';
    b.onclick = function () {
      b.disabled = true; out.textContent = 'Rédaction du rapport par ' + m.nom + '…';
      specialist(m, out).catch(function (e) { out.textContent = 'IA de rédaction indisponible (' + e.message + '). La synthèse enregistrée reste transmise à l\'avatar.'; }).then(function () { b.disabled = false; });
    };
    box.append(b, out);
  }
  function runAll(btn, st) {
    var list = MODS.filter(function (m) { return m.last && m.last.etat !== 'restreint'; }), i = 0;
    btn.disabled = true;
    function next() {
      if (i >= list.length) {
        st.textContent = 'Rapports reçus : synthèse de l\'avatar…';
        return llmAsk('Fais une synthèse générale de la situation du territoire pour les opérateurs, à partir des rapports de chaque IA. Signale ce qui est à vérifier en priorité.').then(function () { st.textContent = 'Terminé.'; btn.disabled = false; });
      }
      var m = list[i++]; st.textContent = 'IA ' + i + '/' + list.length + ' : ' + m.nom + '…';
      return specialist(m).catch(function () { /* l'IA de cette page reste sur sa synthèse enregistrée */ }).then(next);
    }
    return loadAll(true).then(next).catch(function (e) { st.textContent = 'Erreur : ' + e.message; btn.disabled = false; });
  }

  /* ---------- Pages ---------- */
  var PAGES = {
    mt: { titre: 'Météo', desc: 'Prévisions Open-Meteo sur 8 villes (vent, rafales, pluie). Modèles de prévision, pas des stations officielles.', label: 'Météo' },
    eo: { titre: 'Eaux et océan', desc: 'Houle au large (Open-Meteo Marine) et débit modélisé des grands fleuves (GloFAS). Aucun capteur ni station branchés.', label: 'Eaux & océan' },
    ea: { titre: 'Espace aérien', desc: 'Aéronefs reçus par ADS-B communautaire (OpenSky). Couverture partielle, pas un radar. Réservé aux superviseurs et analystes.', label: 'Espace aérien' },
    fo: { titre: 'Forêts et feux', desc: 'Points chauds satellitaires NASA FIRMS (24 h) situés par rapport aux parcs nationaux. Réservé aux superviseurs et analystes.', label: 'Forêts & feux' }
  };
  var VIEW = {};
  function mkPage(id) {
    var P = PAGES[id], v = el('div', 'hide'); v.id = 'v-' + id;
    var h = el('div', 'card'), t = el('h2', '', P.titre); t.style.marginTop = '0';
    var bar = el('div', 'row'), rf = el('button', '', 'Actualiser'), st = el('span', 'note', ''); bar.append(rf, st);
    var body = el('div'); h.append(t, el('div', 'note', P.desc), bar); v.append(h, body);
    $('v-us').after(v);
    var b = el('button', '', P.label); b.id = 't-' + id; b.onclick = function () { tab(id); }; $('out2').before(b);
    rf.onclick = function () { rf.disabled = true; st.textContent = 'Actualisation…'; render(id, true).then(function () { rf.disabled = false; }); };
    VIEW[id] = { body: body, st: st };
  }
  function card(titre, lignes, cls) {
    var c = el('div', 'card'); c.append(el('b', '', titre));
    lignes.forEach(function (l) { c.append(el('div', cls || 'note', l)); }); return c;
  }
  function msg(body, s, nom) {
    var e = srcState(s, nom, 'Ajouter la clé gratuite NASA FIRMS (FIRMS_MAP_KEY) dans Vercel.');
    if (e) body.append(card(nom, e.lines)); return !!e;
  }
  var DRAW = {
    mt: function (b) {
      var s = X.mt; if (msg(b, s, 'Météo')) return;
      s.data.forEach(function (v) {
        b.append(card(v.nom, [n1(v.temp, '°C') + ' · vent ' + n1(v.vent, 'km/h') + ' (rafales ' + n1(v.rafale, 'km/h') + ') · pluie ' + n1(v.pluie, 'mm'),
          '3 jours : rafales max ' + n1(v.rafaleMax3j, 'km/h') + ', pluie max ' + n1(v.pluieMax3j, 'mm/jour') + ' · relevé modèle ' + (v.heure || '—') + ' UTC']));
      });
    },
    eo: function (b) {
      var m = X.mar, r = X.riv;
      if (!msg(b, m, 'Océan')) m.data.forEach(function (v) { b.append(card(v.nom, ['Houle ' + n1(v.houle, 'm') + ' (période ' + n1(v.periode, 's') + ') · max 24 h ' + n1(v.houleMax24h, 'm') + ' · mer ' + n1(v.sst, '°C')])); });
      if (!msg(b, r, 'Fleuves')) r.data.forEach(function (v) { b.append(card(v.nom, ['Débit modélisé ' + n1(v.debit, 'm³/s') + ' → ' + n1(v.debitFin, 'm³/s') + ' dans 7 jours' + (v.tendance != null ? ' (' + (v.tendance >= 0 ? '+' : '') + Math.round(v.tendance * 100) + ' %)' : ''), 'Point le plus proche du modèle : à calibrer avec le service hydrologique.'])); });
    },
    ea: function (b) {
      var s = X.ea; if (msg(b, s, 'Espace aérien')) return;
      var av = (s.data.avions || []).slice().sort(function (a, c) { return (URG[String(c.squawk)] ? 1 : 0) - (URG[String(a.squawk)] ? 1 : 0) || (a.sol ? 1 : 0) - (c.sol ? 1 : 0); });
      b.append(card('Source', [s.data.source + ' · reçu ' + (s.data.heure_source || '—'), s.data.couverture]));
      if (!av.length) b.append(card('Aucun aéronef reçu', ['Cela ne prouve pas l\'absence de trafic : la couverture ADS-B est partielle.']));
      av.slice(0, 60).forEach(function (a) {
        var u = URG[String(a.squawk)];
        b.append(card((a.indicatif || a.icao24) + (u ? ' — ' + u : ''), [(a.pays || '—') + ' · ' + (a.sol ? 'au sol' : 'alt. ' + n1(a.alt_m, 'm')) + ' · ' + n1(a.vitesse_ms != null ? a.vitesse_ms * 3.6 : null, 'km/h') + ' · cap ' + n1(a.cap, '°'), a.lat.toFixed(3) + ', ' + a.lon.toFixed(3) + ' · transpondeur ' + (a.squawk || '—')], u ? 'err' : 'note'));
      });
    },
    fo: function (b) {
      var s = X.fo; if (msg(b, s, 'Feux')) return;
      var pts = (s.data.points || []).slice().sort(function (a, c) { return (c.parc ? 1 : 0) - (a.parc ? 1 : 0) || (c.frp || 0) - (a.frp || 0); });
      b.append(card('Source', [s.data.source + ' · ' + s.data.total + ' point(s)', 'Détection de chaleur par satellite : à vérifier sur le terrain avant toute conclusion.']));
      pts.slice(0, 60).forEach(function (p) {
        b.append(card((p.parc ? 'Parc ' + p.parc : 'Hors parc national') + ' · ' + p.date + ' ' + p.heure + ' UTC', ['Confiance ' + (p.confiance || '—') + ' · puissance ' + n1(p.frp, 'MW') + ' · ' + (p.jour_nuit === 'N' ? 'nuit' : 'jour'), p.lat.toFixed(3) + ', ' + p.lon.toFixed(3)], p.parc ? 'err' : 'note'));
      });
    }
  };
  function render(id, force) {
    var V = VIEW[id]; if (!V) return Promise.resolve();
    var keys = { mt: ['mt'], eo: ['mar', 'riv'], ea: ['ea'], fo: ['fo'] }[id];
    return load(force, keys).then(function () { return typeof loadAll === 'function' ? loadAll(!!force) : null; })
      .then(function () {
        V.body.replaceChildren(); DRAW[id](V.body);
        var t = keys.map(function (k) { return X[k] && X[k].t; }).filter(Boolean);
        V.st.textContent = t.length ? 'Mis à jour ' + new Date(Math.max.apply(null, t)).toLocaleTimeString('fr-FR') : '';
      }).catch(function (e) { V.st.textContent = 'Erreur : ' + e.message; });
  }
  function onTab(id) { return render(id, false); }

  function mountHome() {
    var ev = $('avev'); if (!ev || document.getElementById('g360-veille')) return;
    var c = el('div', 'card'); c.id = 'g360-veille';
    var t = el('h3', '', 'Veille automatique des IA'); t.style.marginTop = '0';
    var st = el('div', 'note', 'Démarrage…'); st.id = 'g360-veille-st';
    var row = el('div', 'row'), lab = el('label', 'note', ''), cb = el('input'); cb.type = 'checkbox'; cb.style.cssText = 'width:auto;min-height:0'; cb.checked = !AUTO.on;
    lab.append(cb, document.createTextNode(' Suspendre la veille'));
    cb.onchange = function () { AUTO.on = !cb.checked; setPref(AUTO.on); status(); };
    var nb = el('button', '', 'Actualiser maintenant'); nb.onclick = function () { tick(false); };
    row.append(lab, nb); c.append(t, st, row); ev.parentNode.before(c);
  }

  function mount() {
    if (!$('v-us') || !$('out2')) return;
    Object.keys(PAGES).forEach(mkPage);
    mountHome();
    mountVoice();
    mountInstall();
  }
  function pend(msg) { return function () { return { etat: 'attente', lines: [msg], ev: [] }; }; }
  function register() {
    if (typeof MODS === 'undefined') return;
    [{ id: 'sa', page: 'ho', nom: 'IA satellitaire', role: 'Imagerie Sentinel-2 et détection de changements', sum: pend('IA satellitaire : service Sentinel-2 à configurer ; aucune donnée reçue.') },
     { id: 'dr', page: 'ho', nom: 'IA drones', role: 'Appareils et vols de drones autorisés', sum: pend('IA drones : aucun appareil connecté ; aucune donnée reçue.') },
     { id: 'cy', page: 'ho', nom: 'IA cybersécurité', role: 'Connexions et incidents de sécurité', sum: pend('IA cybersécurité : journaux de connexion à brancher côté serveur ; aucune donnée reçue.') },
     { id: 'pa', page: 'ho', nom: 'IA abonnements et paiements', role: 'Abonnements et paiements vérifiés côté serveur', sum: pend('IA abonnements et paiements : prestataire de paiement à choisir ; aucune donnée reçue.') }
    ].forEach(function (m) { if (!MODS.some(function (x) { return x.id === m.id; })) MODS.push(m); });
    [{ id: 'mt', page: 'mt', nom: 'IA météo', role: 'Vent, rafales et pluie sur les principales villes', sum: sumMt },
     { id: 'eo', page: 'eo', nom: 'IA eaux et océan', role: 'Houle au large et débit des grands fleuves', sum: sumEo },
     { id: 'ea', page: 'ea', nom: 'IA espace aérien', role: 'Aéronefs reçus par ADS-B et codes d\'urgence', sum: sumEa },
     { id: 'fo', page: 'fo', nom: 'IA forêts et feux', role: 'Points chauds satellitaires et parcs nationaux', sum: sumFo }
    ].forEach(function (m) { if (!MODS.some(function (x) { return x.id === m.id; })) MODS.push(m); });
  }


  /* ---------- Veille automatique : les IA remontent, l'avatar annonce sans qu'on le demande ---------- */
  var AUTO = { on: true, started: false, busy: false, timer: null, seen: {}, etat: {}, llmLog: [], lastLLM: {}, lastTick: null, lastPoint: 0, tickMs: 60000, pointMs: 1800000 };
  function pref() { try { return localStorage.getItem('g360_veille') !== 'off'; } catch (e) { return true; } }
  function setPref(v) { try { localStorage.setItem('g360_veille', v ? 'on' : 'off'); } catch (e) { /* ignore */ } }
  var PRIO = { critique: 3, haute: 2, normale: 1 };
  function evKey(e) { return e.mod + '|' + e.prio + '|' + String(e.titre).replace(/[0-9]+([.,][0-9]+)?/g, '#'); }
  function seedSeen() { var now = Date.now(); EVT.forEach(function (e) { AUTO.seen[evKey(e)] = now; }); }
  function fresh() {
    var now = Date.now(), out = [];
    EVT.forEach(function (e) { var k = evKey(e); if (!AUTO.seen[k] || now - AUTO.seen[k] > 6 * 3600e3) { AUTO.seen[k] = now; out.push(e); } });
    return out;
  }
  function modNom(id) { var m = MODS.filter(function (x) { return x.id === id; })[0]; return m ? m.nom : id; }
  function healthChanges() {
    var out = [];
    MODS.forEach(function (m) {
      var cur = m.last && m.last.etat, prev = AUTO.etat[m.id]; AUTO.etat[m.id] = cur;
      if (prev === undefined) { if (cur === 'erreur') out.push({ mod: m.id, type: 'état IA', titre: m.nom + ' : source indisponible', prio: 'normale', statut: 'à vérifier', src: '' }); return; }
      if (cur === 'erreur' && prev !== 'erreur') out.push({ mod: m.id, type: 'état IA', titre: m.nom + ' : source devenue indisponible', prio: 'normale', statut: 'à vérifier', src: '' });
      if (prev === 'erreur' && cur !== 'erreur') out.push({ mod: m.id, type: 'état IA', titre: m.nom + ' : source rétablie', prio: 'normale', statut: 'information', src: '' });
    });
    return out;
  }
  function line(e) {
    return '• ' + e.titre + ' — ' + modNom(e.mod) + ' (priorité ' + e.prio + ', statut : ' + e.statut + (e.src ? ', source : ' + e.src : '') + (e.lat != null ? ', position ' + Number(e.lat).toFixed(3) + ', ' + Number(e.lon).toFixed(3) : '') + ')';
  }
  function banner(texte, crit) {
    if (typeof document === 'undefined' || !document.body || !document.createElement) return;
    var hv = $('v-ho') && !$('v-ho').classList.contains('hide');
    if (hv && !document.hidden) return;
    var b = document.getElementById('g360-banner');
    if (!b) { b = el('div', 'card'); b.id = 'g360-banner'; b.style.cssText = 'position:fixed;left:10px;right:10px;bottom:10px;z-index:9999;margin:0;box-shadow:0 4px 20px rgba(0,0,0,.5);max-height:45vh;overflow:auto'; document.body.append(b); }
    b.style.borderColor = crit ? 'var(--rd)' : 'var(--gr)'; b.replaceChildren();
    var p = el('div', 'note', texte); p.style.whiteSpace = 'pre-line'; p.style.color = 'inherit';
    var r = el('div', 'row'), o = el('button', 'p', 'Ouvrir l\'accueil'), f = el('button', '', 'Fermer');
    o.onclick = function () { b.remove(); tab('ho'); }; f.onclick = function () { b.remove(); };
    r.append(o, f); b.append(el('b', '', 'Avatar central'), p, r);
    clearTimeout(AUTO.bt); if (!crit && typeof setTimeout === 'function') AUTO.bt = setTimeout(function () { try { b.remove(); } catch (e) { /* ignore */ } }, 25000);
  }
  function announce(list) {
    if (!list.length) return;
    list = list.slice().sort(function (a, b) { return (PRIO[b.prio] || 0) - (PRIO[a.prio] || 0); });
    var hi = list.filter(function (e) { return e.prio === 'critique' || e.prio === 'haute'; }), crit = list.some(function (e) { return e.prio === 'critique'; });
    var txt = (crit ? 'Signalement critique reçu des IA :\n' : hi.length ? 'Nouveau signalement important reçu des IA :\n' : 'Information reçue des IA :\n') +
      list.slice(0, 5).map(line).join('\n') + (list.length > 5 ? '\n… et ' + (list.length - 5) + ' autre(s), voir l\'accueil.' : '') +
      '\nCes signalements ne sont pas confirmés : une personne habilitée doit les vérifier.';
    avSay(txt, 0, !hi.length);
    banner(txt, crit);
  }
  function briefing() {
    var hi = EVT.filter(function (e) { return e.prio === 'critique' || e.prio === 'haute'; });
    var att = MODS.filter(function (m) { return m.last && m.last.etat === 'attente'; }).map(function (m) { return m.nom; });
    var txt = 'Point de situation automatique : ' + (EVT.length ? EVT.length + ' signalement(s) en cours, dont ' + hi.length + ' de priorité haute ou critique.' : 'aucun signalement en cours.') +
      (EVT.length ? '\n' + EVT.slice(0, 3).map(line).join('\n') : '') +
      (att.length ? '\nIA pas encore alimentées (sources non connectées) : ' + att.join(', ') + '.' : '');
    avSay(txt, 0, !hi.length); AUTO.lastPoint = Date.now();
  }
  function pointSituation() {
    if (Date.now() - AUTO.lastPoint < AUTO.pointMs) return;
    AUTO.lastPoint = Date.now();
    avSay('Point de situation automatique :\n' + MODS.filter(function (m) { return m.last && m.last.etat !== 'restreint'; }).map(function (m) { return '• ' + m.last.lines[0]; }).join('\n'), 0, true);
  }
  function llmOk(key, cool) {
    var now = Date.now(); AUTO.llmLog = AUTO.llmLog.filter(function (t) { return now - t < 3600e3; });
    if (AUTO.llmLog.length >= 8) return false;
    if (AUTO.lastLLM[key] && now - AUTO.lastLLM[key] < cool) return false;
    AUTO.llmLog.push(now); AUTO.lastLLM[key] = now; return true;
  }
  function llmOn() { try { return typeof LLM !== 'undefined' && LLM === true; } catch (e) { return false; } }
  // Les IA concernées par un signalement important rédigent automatiquement leur rapport ; l'avatar en fait la synthèse.
  function autoReports(nv) {
    if (!llmOn()) return Promise.resolve();
    var ids = []; nv.forEach(function (e) { if ((e.prio === 'critique' || e.prio === 'haute') && !e.type.match(/état IA/) && ids.indexOf(e.mod) < 0) ids.push(e.mod); });
    var crit = nv.some(function (e) { return e.prio === 'critique'; }), chain = Promise.resolve(), done = 0;
    ids.slice(0, 2).forEach(function (id) {
      var m = MODS.filter(function (x) { return x.id === id; })[0];
      if (m && llmOk('ia:' + id, 1800e3)) chain = chain.then(function () { done++; return specialist(m).catch(function () { /* reste sur la synthèse enregistrée */ }); });
    });
    return chain.then(function () {
      if (done && crit && llmOk('synthese', 1200e3)) return llmAsk('Un signalement critique vient d\'être reçu des IA. Fais une synthèse courte pour les opérateurs à partir des rapports des IA et indique ce qu\'il faut vérifier en priorité.');
    });
  }
  function status() {
    var st = $('g360-veille-st'); if (!st) return;
    st.textContent = AUTO.on ? 'Active : les IA transmettent leurs observations à l\'avatar, qui annonce tout nouveau signalement sans qu\'on le lui demande (voix pour les priorités haute et critique). Actualisation toutes les ' + Math.round(AUTO.tickMs / 1000) + ' s' +
      (AUTO.lastTick ? ', dernière à ' + AUTO.lastTick.toLocaleTimeString('fr-FR') : '') + '. ' + (llmOn() ? 'Rapports rédigés par IA : automatiques (limités à 8 par heure).' : 'Rédaction par IA non configurée : annonces à partir des données enregistrées.') : 'Veille suspendue : l\'avatar n\'annonce plus rien tant qu\'elle n\'est pas relancée.';
  }
  function tick(first) {
    if (AUTO.busy || (!AUTO.on && !first)) return Promise.resolve();
    AUTO.busy = true;
    return Promise.resolve().then(function () { return loadAll(true); }).then(function () {
      var h = healthChanges();
      if (first) { seedSeen(); briefing(); return null; }
      var nv = fresh(); announce(nv.concat(h)); pointSituation();
      return autoReports(nv);
    }).then(function () { AUTO.lastTick = new Date(); if (typeof renderHome === 'function') { try { renderHome(); } catch (e) { /* ignore */ } } status(); },
      function () { /* échec de chargement : réessai au prochain cycle */ }).then(function () { AUTO.busy = false; });
  }
  function start() {
    if (AUTO.started) return; AUTO.started = true; AUTO.on = pref(); AUTO.seen = {}; AUTO.etat = {}; AUTO.llmLog = []; AUTO.lastLLM = {};
    var chk = typeof checkLlm === 'function' ? Promise.resolve(checkLlm()).catch(function () { }) : Promise.resolve();
    chk.then(function () { return tick(true); });
    AUTO.timer = setInterval(function () { tick(false); }, AUTO.tickMs);
  }
  function stop() { AUTO.started = false; clearInterval(AUTO.timer); var b = document.getElementById('g360-banner'); if (b) b.remove(); }
  function watch() {
    if (typeof setInterval !== 'function') return;
    setInterval(function () {
      var ok = false; try { ok = !!(me && ses && ses.access_token); } catch (e) { ok = false; }
      if (ok && !AUTO.started) start(); else if (!ok && AUTO.started) stop();
    }, 2000);
  }


  /* ---------- Conversation : civilités locales, conversation vocale mains libres, installation sur téléphone ---------- */
  // n = texte normalisé par l'application (minuscules, sans accents). Ne répond qu'aux messages courts de pure politesse.
  function social(n) {
    n = String(n || '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (!n || n.split(' ').length > 6) return null;
    var nom = ''; try { nom = me && me.nom ? ' ' + me.nom : ''; } catch (e) { /* non connecté */ }
    var hr = new Date().getHours(), salut = (hr >= 18 || hr < 5) ? 'Bonsoir' : 'Bonjour';
    if (/^(au revoir|a bientot|a plus|a demain|bonne nuit|bonne soiree|bonne journee)\b/.test(n)) return 'À bientôt' + nom + '. Je continue la veille : vous serez informé de tout nouveau signalement dès votre retour.';
    if (/^(bonjour|salut|bonsoir|coucou|hello|hey|salam|mbolo)\b/.test(n)) return salut + nom + '. Je suis là et je suis la situation du territoire avec les IA de chaque page. Que puis-je faire pour vous ?';
    if (/\b(merci|je te remercie|je vous remercie)\b/.test(n)) return 'Avec plaisir. Je reste disponible : posez-moi une question quand vous voulez.';
    if (/(ca va|comment vas tu|comment allez vous|tu vas bien|vous allez bien)/.test(n)) {
      var live = 0, tot = 0; try { MODS.forEach(function (m) { tot++; if (m.last && (m.last.etat === 'ok' || m.last.etat === 'partiel')) live++; }); } catch (e) { /* ignore */ }
      return 'Je vais bien, merci de demander. Je fonctionne normalement' + (tot ? ' : ' + live + ' IA sur ' + tot + ' me transmettent des données en ce moment' : '') + '. Et vous, comment puis-je vous aider ?';
    }
    if (/(qui es tu|tu es qui|qui etes vous|presente toi|presentez vous|comment t appelles|comment tu t appelles)/.test(n))
      return 'Je suis l\'avatar central de GABON 360 AI. Les IA de chaque page me transmettent ce qu\'elles observent (météo, eaux et océan, espace aérien, forêts et feux, alertes, missions…), je vous l\'annonce et je réponds à vos questions. Je suis une intelligence artificielle, pas une personne.';
    if (/(que sais tu faire|que peux tu faire|que savez vous faire|a quoi tu sers|a quoi sers tu|tu peux m aider|^aide$|^aide moi$)/.test(n))
      return 'Je peux vous résumer la situation, vous annoncer les nouveaux signalements, ouvrir une page, expliquer un événement, et discuter de tout autre sujet. Dites par exemple « situation générale », « ouvre la carte » ou posez-moi simplement une question.';
    return null;
  }

  var VOICE = { on: false, listening: false, empty: 0, btn: null };
  function setVoice(on) {
    VOICE.on = !!on; VOICE.empty = 0;
    if (VOICE.btn) VOICE.btn.textContent = 'Conversation vocale : ' + (VOICE.on ? 'activée' : 'désactivée');
  }
  function listen() {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!VOICE.on || VOICE.listening) return;
    if (!SR) { setVoice(false); avSay('La reconnaissance vocale n\'est pas disponible sur ce navigateur (Chrome sur Android fonctionne le mieux). Utilisez le clavier.', 0, true); return; }
    var r = new SR(), got = false; r.lang = 'fr-FR'; VOICE.listening = true;
    r.onresult = function (e) { got = true; VOICE.empty = 0; try { ask(e.results[0][0].transcript); } catch (x) { /* ignore */ } };
    r.onerror = function () { /* permission refusée ou silence : géré dans onend */ };
    r.onstart = function () { try { AV.set('listen'); } catch (x) { /* ignore */ } };
    r.onend = function () {
      VOICE.listening = false;
      try { if (AV && AV.S && AV.S.st === 'listen') AV.S.st = 'idle'; } catch (x) { /* ignore */ }
      if (got || !VOICE.on) return;
      if (++VOICE.empty >= 2) { setVoice(false); avSay('Je ne vous entends plus : j\'arrête l\'écoute. Touchez « Conversation vocale » pour reprendre.', 0, true); }
      else setTimeout(listen, 300);
    };
    try { r.start(); } catch (e) { VOICE.listening = false; }
  }
  // Appelé par index.html à la fin de chaque réponse parlée : en conversation vocale, l'avatar se remet à écouter.
  function afterSpeak() { if (VOICE.on && !VOICE.listening) setTimeout(listen, 450); }
  function mountVoice() {
    var mic = $('avmic'); if (!mic || document.getElementById('g360-conv')) return;
    var b = el('button', '', ''); b.id = 'g360-conv'; VOICE.btn = b; setVoice(false);
    b.onclick = function () {
      if (VOICE.on) { setVoice(false); return; }
      try { AVV = true; var sp = $('avspk'); if (sp) sp.textContent = 'Voix : activée'; } catch (e) { /* ignore */ }
      setVoice(true); avSay('Je vous écoute. Parlez, je réponds à voix haute ; dites-moi quand vous voulez arrêter en touchant le bouton.', 0, false);
    };
    mic.after(b);
  }

  var INSTALL = { evt: null };
  function standalone() {
    try { return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true; } catch (e) { return false; }
  }
  function mountInstall() {
    var anchor = $('avev'); if (!anchor || document.getElementById('g360-install') || standalone()) return;
    var c = el('div', 'card'); c.id = 'g360-install';
    var t = el('h3', '', 'Installer l\'application sur ce téléphone'); t.style.marginTop = '0';
    var ua = (navigator.userAgent || ''), ios = /iphone|ipad|ipod/i.test(ua);
    var note = el('div', 'note', ios
      ? 'Sur iPhone : ouvrez cette page dans Safari, touchez le bouton Partager, puis « Sur l\'écran d\'accueil ».'
      : 'Sur Android : touchez « Installer » ci-dessous, ou le menu ⋮ du navigateur puis « Installer l\'application ».');
    var b = el('button', 'p', 'Installer'); b.style.display = ios ? 'none' : '';
    b.onclick = function () {
      if (INSTALL.evt) { INSTALL.evt.prompt(); INSTALL.evt = null; } else note.textContent = 'Utilisez le menu ⋮ du navigateur, puis « Installer l\'application » ou « Ajouter à l\'écran d\'accueil ».';
    };
    c.append(t, note, b); anchor.parentNode.before(c);
  }
  if (typeof window !== 'undefined' && window.addEventListener) {
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); INSTALL.evt = e; });
    window.addEventListener('appinstalled', function () { var c = document.getElementById('g360-install'); if (c) c.remove(); });
  }
  if (typeof navigator !== 'undefined' && navigator.serviceWorker && typeof location !== 'undefined' && (location.protocol === 'https:' || location.hostname === 'localhost') && window.addEventListener) {
    window.addEventListener('load', function () { navigator.serviceWorker.register('/sw.js').catch(function () { /* hors PWA : sans conséquence */ }); });
  }

  window.G360C = {
    tabs: Object.keys(PAGES), load: load, onTab: onTab, addSpecialist: addSpecialist, runAll: runAll, social: social, afterSpeak: afterSpeak,
    _t: { auto: { AUTO: AUTO, evKey: evKey, fresh: fresh, seedSeen: seedSeen, healthChanges: healthChanges, announce: announce, briefing: briefing, llmOk: llmOk, tick: tick, autoReports: autoReports }, inGeo: inGeo, parkOf: parkOf, sumMt: sumMt, sumEo: sumEo, sumEa: sumEa, sumFo: sumFo, setX: function (o) { X = o; }, SEUILS: SEUILS }
  };
  register();
  mount();
  watch();
})();
