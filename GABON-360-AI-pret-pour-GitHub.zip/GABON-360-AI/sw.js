/* GABON 360 AI — service worker : installation sur téléphone et ouverture sans réseau (coquille de l'application seulement).
   Les données (Supabase, /api/*, météo, cartes) ne sont JAMAIS mises en cache ici : sans réseau, l'application s'ouvre mais n'affiche aucune donnée. */
const VERSION = 'g360-v1';
const SHELL = ['/', '/index.html', '/gabon360-centre.js', '/gabon360-avatar-relay.js', '/gabon360-modules-addon.js', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => Promise.allSettled(SHELL.map(u => c.add(u)))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;          // Supabase, météo, cartes : le navigateur s'en charge
  if (url.pathname.startsWith('/api/')) return;             // routes serveur : jamais en cache
  // Réseau d'abord (les mises à jour arrivent tout de suite), cache en secours hors connexion.
  e.respondWith(fetch(req).then(res => {
    if (res && res.ok) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); }
    return res;
  }).catch(() => caches.match(req).then(r => r || (req.mode === 'navigate' ? caches.match('/index.html') : undefined))
    .then(r => r || new Response('Hors connexion', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }))));
});
