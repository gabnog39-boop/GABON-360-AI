# Supabase — rien d'obligatoire

L'application du jour ne crée **aucune table** et ne change **aucune donnée** : les nouvelles pages lisent des sources externes, et `/api/owner-access` utilise la table `profiles` existante. Ces scripts sont facultatifs.

1. `00_diagnostic_lecture_seule.sql` : lecture seule. Lancez-le dans Supabase → SQL Editor et gardez le résultat (colonnes, règles RLS, déclencheurs).
2. `01_protection_profils_optionnel.sql` : empêche un utilisateur ordinaire de changer son propre `role` ou `statut`. **Inactif tant que vous ne remplacez pas l'UUID** par celui d'`OWNER_USER_ID`. À lancer d'abord sur une copie ou une branche Supabase si vous en avez une.
3. `02_annuler_protection.sql` : retire la protection.

Essai après activation : avec un compte ordinaire, changer son propre statut doit échouer ; avec le compte propriétaire, depuis l'écran Utilisateurs, cela doit réussir.
Ces scripts n'ont pas été exécutés par moi (pas de base disponible) : le diagnostic et un essai sur copie sont la bonne première étape.
