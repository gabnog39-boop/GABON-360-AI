-- GABON 360 AI — PROTECTION FACULTATIVE des colonnes role et statut de public.profiles.
-- Ne supprime et ne modifie AUCUNE donnée. Rien n'est obligatoire : l'application fonctionne sans ce script.
-- Sécurités :
--   * s'arrête sans rien créer si public.profiles n'a pas les colonnes role et statut ;
--   * reste INACTIF (laisse tout passer) tant que l'UUID du propriétaire ci-dessous n'est pas remplacé ;
--   * ne se déclenche que lorsque role ou statut changent (les autres modifications de profil ne sont pas concernées).
-- Une fois actif : statut = modifiable seulement par la route serveur /api/owner-access ou depuis le SQL Editor ;
--                  role   = modifiable seulement par le propriétaire (ou le SQL Editor / le serveur).
-- Annulation immédiate : 02_annuler_protection.sql

do $$
begin
  if not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'profiles' and column_name = 'role')
  or not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'profiles' and column_name = 'statut') then
    raise exception 'public.profiles n''a pas les colonnes role et statut : rien n''a été créé.';
  end if;
end $$;

create or replace function public.g360_protect_profiles()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  owner_id constant uuid := '00000000-0000-0000-0000-000000000000'; -- REMPLACER par la valeur d'OWNER_USER_ID pour activer
  claims jsonb := coalesce(nullif(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
  v_role text := coalesce(nullif(current_setting('request.jwt.claim.role', true), ''), claims ->> 'role', '');
  is_admin_db boolean := v_role = 'service_role' or session_user in ('postgres', 'supabase_admin');
begin
  if owner_id = '00000000-0000-0000-0000-000000000000'::uuid then
    return new; -- non configuré : aucun effet
  end if;
  if new.statut is distinct from old.statut and not is_admin_db then
    raise exception 'Le statut ne peut être modifié que par le propriétaire (route /api/owner-access)';
  end if;
  if new.role is distinct from old.role and not (is_admin_db or auth.uid() = owner_id) then
    raise exception 'Le rôle ne peut être modifié que par le propriétaire';
  end if;
  return new;
end;
$$;

drop trigger if exists g360_protect_profiles on public.profiles;
create trigger g360_protect_profiles
  before update of role, statut on public.profiles
  for each row execute function public.g360_protect_profiles();
