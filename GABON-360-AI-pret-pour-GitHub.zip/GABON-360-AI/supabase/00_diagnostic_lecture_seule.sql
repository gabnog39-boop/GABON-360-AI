-- GABON 360 AI — DIAGNOSTIC EN LECTURE SEULE.
-- Ne modifie rien. À lancer dans Supabase > SQL Editor ; copiez le résultat (colonne « diagnostic »).
select jsonb_build_object(
  'colonnes', (select jsonb_agg(column_name || ':' || data_type order by ordinal_position)
               from information_schema.columns where table_schema = 'public' and table_name = 'profiles'),
  'rls_active', (select relrowsecurity from pg_class where oid = 'public.profiles'::regclass),
  'politiques', (select coalesce(jsonb_agg(jsonb_build_object('nom', policyname, 'commande', cmd, 'roles', roles, 'using', qual, 'with_check', with_check)), '[]'::jsonb)
                 from pg_policies where schemaname = 'public' and tablename = 'profiles'),
  'declencheurs', (select coalesce(jsonb_agg(tgname), '[]'::jsonb)
                   from pg_trigger where tgrelid = 'public.profiles'::regclass and not tgisinternal)
) as diagnostic;

-- Facultatif, à lancer séparément (échoue sans effet si les colonnes role/statut n'existent pas) :
-- select role, statut, count(*) from public.profiles group by 1, 2 order by 1, 2;
