-- GABON 360 AI — ANNULE la protection de 01 (retour exact à l'état d'avant). Aucune donnée touchée.
drop trigger if exists g360_protect_profiles on public.profiles;
drop function if exists public.g360_protect_profiles();
