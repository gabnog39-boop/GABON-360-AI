/* Relais additif : les fiches créées dans le panneau local peuvent être expliquées
   par l'avatar central. Aucun flux externe ni accès privilégié n'est simulé. */
(function () {
  'use strict';
  if (window.__G360_AVATAR_RELAY_INSTALLED__) return;
  window.__G360_AVATAR_RELAY_INSTALLED__ = true;
  window.addEventListener('g360:avatar-message', async function (event) {
    const detail = event && event.detail;
    if (!detail || detail.source !== 'modules-addon' || !detail.record) return;
    const record = detail.record;
    const recordData = {
      origine: 'module local du navigateur',
      id: record.id || null,
      module: record.moduleName || record.module || 'inconnu',
      titre: record.title || 'Sans titre',
      priorite: record.priority || 'non précisée',
      statut: record.status || 'nouveau',
      date_creation: record.createdAt || null,
      champs: Array.isArray(record.fields) ? record.fields.map(function (f) {
        return { champ: String(f.label || ''), valeur: String(f.value || '') };
      }) : []
    };
    const prompt = 'Explique cette fiche locale en français. Commence par résumer les champs réellement fournis. Distingue explicitement les faits enregistrés, les hypothèses et les données manquantes. Ne déduis pas une position, une cause, une source externe ni une confirmation qui ne figurent pas dans la fiche. Indique les vérifications utiles. Fiche : ' + JSON.stringify(recordData);
    try {
      if (typeof window.avSay === 'function') window.avSay('Analyse de la fiche en cours…', 0, true);
      if (typeof window.llmAsk === 'function') {
        await window.llmAsk(prompt, recordData);
      } else {
        throw new Error('La fonction IA de l’avatar n’est pas disponible dans cette version.');
      }
    } catch (error) {
      if (typeof window.avSay === 'function') window.avSay('Impossible d’analyser cette fiche avec l’IA : ' + (error && error.message ? error.message : 'erreur inconnue') + '. Les données locales restent enregistrées.', 0, true);
    }
  });
})();
