package ga.gabon360.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.objects.ObjectDetection;
import com.google.mlkit.vision.objects.ObjectDetector;
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private LocationManager locationManager;
    private ImageLabeler imageLabeler;
    private ObjectDetector objectDetector;
    private final Object visionLock = new Object();
    private static final int REQ_AUDIO = 7001;
    private static final int REQ_LOCATION = 7002;
    private static final int REQ_CAMERA = 7003;
    private static final int REQ_CAPTURE = 7004;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.FRENCH); });
        ImageLabelerOptions labelOptions = new ImageLabelerOptions.Builder()
                .setConfidenceThreshold(0.55f).build();
        imageLabeler = ImageLabeling.getClient(labelOptions);
        ObjectDetectorOptions objectOptions = new ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableMultipleObjects()
                .enableClassification()
                .build();
        objectDetector = ObjectDetection.getClient(objectOptions);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(request.getResources());
                    else { request.deny(); requestAudioPermission(); }
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) callback.invoke(origin, true, false);
                else { callback.invoke(origin, false, false); requestLocationPermission(); }
            }
        });
        web.addJavascriptInterface(new Bridge(), "G360");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void requestAudioPermission(){ if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); }
    private void requestLocationPermission(){ if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); }
    private void requestCamera(){ if (checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA); else openCamera(); }

    private void openCamera(){
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, REQ_CAPTURE);
        else web.evaluateJavascript("window.onNativeCamera('');", null);
    }

    private void startRecognition(){
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { web.evaluateJavascript("window.onNativeVoiceError('Reconnaissance vocale indisponible sur cet appareil');", null); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestAudioPermission(); return; }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { web.evaluateJavascript("window.onNativeVoiceState('Écoute…');", null); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { web.evaluateJavascript("window.onNativeVoiceState('Traitement…');", null); }
            public void onError(int e) { web.evaluateJavascript("window.onNativeVoiceError('Erreur micro : "+e+"');", null); }
            public void onResults(Bundle b) {
                ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(r!=null && !r.isEmpty()) web.evaluateJavascript("window.onNativeVoice("+org.json.JSONObject.quote(r.get(0))+");", null);
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int a, Bundle b) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez à GABON 360 AI");
        recognizer.startListening(i);
    }

    private void getLocation(){
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) { requestLocationPermission(); return; }
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        try {
            Location last=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(last==null) last=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(last!=null) sendLocation(last);
            locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, new LocationListener(){public void onLocationChanged(Location l){sendLocation(l);} public void onProviderEnabled(String p){} public void onProviderDisabled(String p){} public void onStatusChanged(String p,int s,Bundle b){}}, null);
        } catch(Exception e){ web.evaluateJavascript("window.onNativeLocationError('GPS indisponible');", null); }
    }
    private void sendLocation(Location l){ web.evaluateJavascript("window.onNativeLocation("+l.getLatitude()+","+l.getLongitude()+","+l.getAccuracy()+");", null); }

    private void analyzeVisionBitmap(Bitmap bitmap){
        if(bitmap==null) return;
        final InputImage image=InputImage.fromBitmap(bitmap,0);
        web.evaluateJavascript("window.onNativeVisionStatus('Analyse IA locale en cours…');",null);
        final org.json.JSONArray labelsJson=new org.json.JSONArray();
        final org.json.JSONArray objectsJson=new org.json.JSONArray();
        final int[] pending={2};
        final boolean[] failed={false};
        Runnable finish=()->{
            if(--pending[0]>0) return;
            try{
                org.json.JSONObject out=new org.json.JSONObject();
                out.put("engine","ML Kit — IA locale embarquée");
                out.put("offlineCapable",true);
                out.put("timestamp",System.currentTimeMillis());
                out.put("labels",labelsJson);
                out.put("objects",objectsJson);
                out.put("status",failed[0]?"PARTIELLE":"OK");
                web.evaluateJavascript("window.onNativeVisionResult("+org.json.JSONObject.quote(out.toString())+");",null);
            }catch(Exception e){ web.evaluateJavascript("window.onNativeVisionError('Résultat IA invalide');",null); }
        };
        imageLabeler.process(image).addOnSuccessListener(labels->{
            for(ImageLabel l:labels){
                try{ org.json.JSONObject x=new org.json.JSONObject(); x.put("text",l.getText()); x.put("confidence",Math.round(l.getConfidence()*1000)/1000.0); labelsJson.put(x); }catch(Exception ignored){}
            }
        }).addOnFailureListener(e->{failed[0]=true;}).addOnCompleteListener(t->finish.run());
        objectDetector.process(image).addOnSuccessListener(objects->{
            for(com.google.mlkit.vision.objects.DetectedObject o:objects){
                try{
                    org.json.JSONObject x=new org.json.JSONObject();
                    x.put("id",o.getTrackingId()==null?-1:o.getTrackingId());
                    android.graphics.Rect r=o.getBoundingBox();
                    org.json.JSONObject box=new org.json.JSONObject(); box.put("left",r.left); box.put("top",r.top); box.put("right",r.right); box.put("bottom",r.bottom); x.put("box",box);
                    org.json.JSONArray cats=new org.json.JSONArray();
                    for(com.google.mlkit.vision.objects.DetectedObject.Label c:o.getLabels()){
                        org.json.JSONObject z=new org.json.JSONObject(); z.put("text",c.getText()); z.put("confidence",Math.round(c.getConfidence()*1000)/1000.0); cats.put(z);
                    }
                    x.put("categories",cats); objectsJson.put(x);
                }catch(Exception ignored){}
            }
        }).addOnFailureListener(e->{failed[0]=true;}).addOnCompleteListener(t->finish.run());
    }

    private void saveText(String name,String text){
        try {
            if(android.os.Build.VERSION.SDK_INT>=29){
                android.content.ContentValues v=new android.content.ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/GABON_360_AI");
                Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u!=null){try(OutputStream o=getContentResolver().openOutputStream(u)){o.write(text.getBytes("UTF-8"));}}
            } else { File d=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); d.mkdirs(); File f=new File(d,name); try(FileOutputStream o=new FileOutputStream(f)){o.write(text.getBytes("UTF-8"));} MediaScannerConnection.scanFile(this,new String[]{f.getAbsolutePath()},null,null); }
            web.evaluateJavascript("window.onNativeSaved('"+name.replace("'","\\'")+"');",null);
        }catch(Exception e){web.evaluateJavascript("window.onNativeSaveError('"+e.getMessage().replace("'","\\'")+"');",null);}
    }

    private void share(String text){ Intent s=new Intent(Intent.ACTION_SEND); s.setType("text/plain"); s.putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(s,"Partager GABON 360 AI")); }

    public class Bridge {
        @JavascriptInterface public void speak(String text){runOnUiThread(()->{if(tts!=null){tts.stop();tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"g360");}});}
        @JavascriptInterface public void stopSpeak(){runOnUiThread(()->{if(tts!=null)tts.stop();});}
        @JavascriptInterface public void startVoice(){runOnUiThread(()->startRecognition());}
        @JavascriptInterface public void stopVoice(){runOnUiThread(()->{if(recognizer!=null)recognizer.stopListening();});}
        @JavascriptInterface public void getLocation(){runOnUiThread(()->MainActivity.this.getLocation());}
        @JavascriptInterface public void saveReport(String name,String text){runOnUiThread(()->saveText(name,text));}
        @JavascriptInterface public void share(String text){runOnUiThread(()->MainActivity.this.share(text));}
        @JavascriptInterface public void camera(){runOnUiThread(()->requestCamera());}
        @JavascriptInterface public void analyzeVisionImage(){
            web.evaluateJavascript("window.onNativeVisionStatus('Pour analyser une image, utilisez Capturer terrain.');",null);
        }
        @JavascriptInterface public String getNetworkStatus(){
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            Network n=cm.getActiveNetwork(); NetworkCapabilities c=n!=null?cm.getNetworkCapabilities(n):null;
            boolean online=c!=null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            String transport="NONE";
            if(c!=null){ if(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) transport="WIFI"; else if(c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) transport="CELLULAR"; else if(c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) transport="ETHERNET"; else if(c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) transport="VPN"; else transport="OTHER"; }
            boolean satellite=false;
            if(android.os.Build.VERSION.SDK_INT>=31 && c!=null){ try{ satellite=c.hasTransport(NetworkCapabilities.TRANSPORT_SATELLITE); }catch(Throwable ignored){} }
            return "{\"online\":"+online+",\"satellite\":"+satellite+",\"transport\":\""+transport+"\"}";
        }

        @JavascriptInterface public void syncToBackend(String url, String payload, String token){
            new Thread(() -> {
                HttpURLConnection c=null;
                try{
                    URL u=new URL(url);
                    c=(HttpURLConnection)u.openConnection();
                    c.setConnectTimeout(8000); c.setReadTimeout(12000); c.setRequestMethod("POST");
                    c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                    c.setRequestProperty("Accept","application/json");
                    if(token!=null && !token.trim().isEmpty()) c.setRequestProperty("Authorization","Bearer "+token.trim());
                    byte[] body=payload.getBytes("UTF-8"); c.setFixedLengthStreamingMode(body.length);
                    try(OutputStream out=c.getOutputStream()){out.write(body);}
                    int code=c.getResponseCode();
                    String detail="HTTP "+code;
                    try(java.io.InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream()){
                        if(in!=null){byte[] b=new byte[512];int n=in.read(b);if(n>0)detail=new String(b,0,n,"UTF-8").replace("\n"," ").substring(0,Math.min(180,n));}
                    }catch(Exception ignored){}
                    JSONObject r=new JSONObject(); r.put("ok",code>=200&&code<300); r.put("status",code); r.put("detail",detail);
                    final String out=r.toString(); runOnUiThread(()->web.evaluateJavascript("window.onBackendSync("+JSONObject.quote(out)+");",null));
                }catch(Exception e){
                    try{JSONObject r=new JSONObject();r.put("ok",false);r.put("status",0);r.put("detail",e.getClass().getSimpleName()+": "+e.getMessage());final String out=r.toString();runOnUiThread(()->web.evaluateJavascript("window.onBackendSync("+JSONObject.quote(out)+");",null));}catch(Exception ignored){}
                }finally{if(c!=null)c.disconnect();}
            }).start();
        }

        @JavascriptInterface public void probeInfrastructure(){
            new Thread(() -> {
                JSONArray out = new JSONArray();
                String[] names={"UGEO WMS","UGEO WFS","GABON 360 API"};
                String[] urls={"https://ugeo.univga.com/geoserver/wms?SERVICE=WMS&REQUEST=GetCapabilities&VERSION=1.1.1","https://ugeo.univga.com/geoserver/wfs?SERVICE=WFS&REQUEST=GetCapabilities&VERSION=2.0.0","https://ugeo.univga.com/api/v2/datasets/"};
                for(int i=0;i<urls.length;i++){
                    JSONObject x=new JSONObject();
                    try{
                        HttpURLConnection c=(HttpURLConnection)new URL(urls[i]).openConnection();
                        c.setConnectTimeout(6000); c.setReadTimeout(8000); c.setRequestMethod("GET");
                        int code=c.getResponseCode();
                        x.put("name",names[i]); x.put("url",urls[i]); x.put("http",code); x.put("online",code>=200&&code<400);
                        c.disconnect();
                    }catch(Exception e){ try{x.put("name",names[i]);x.put("url",urls[i]);x.put("http",0);x.put("online",false);x.put("error",e.getClass().getSimpleName());}catch(Exception ignored){} }
                    out.put(x);
                }
                final String payload=out.toString();
                runOnUiThread(() -> web.evaluateJavascript("window.onInfrastructureProbe("+JSONObject.quote(payload)+");",null));
            }).start();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQ_CAMERA && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) openCamera();
        if(requestCode==REQ_AUDIO && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) web.evaluateJavascript("window.onNativeVoiceState('Microphone autorisé');", null);
        if(requestCode==REQ_LOCATION && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) getLocation();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data); if(requestCode==REQ_CAPTURE){if(resultCode==RESULT_OK && data!=null && data.getExtras()!=null){Bitmap b=(Bitmap)data.getExtras().get("data");try{ByteArrayOutputStream o=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,82,o);String x=Base64.encodeToString(o.toByteArray(),Base64.NO_WRAP); analyzeVisionBitmap(b); web.evaluateJavascript("window.onNativeCamera('data:image/jpeg;base64,"+x+"');",null);}catch(Exception e){web.evaluateJavascript("window.onNativeCamera('');",null);}}else web.evaluateJavascript("window.onNativeCamera('');",null);}}
    @Override protected void onDestroy(){if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();if(imageLabeler!=null)imageLabeler.close();if(objectDetector!=null)objectDetector.close();super.onDestroy();}
}
