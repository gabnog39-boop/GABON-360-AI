#!/usr/bin/env python3
"""Icône Android : génère les icônes adaptatives et les tailles mipmap à partir de l'image OFFICIELLE
déjà présente dans le projet (res/drawable-nodpi/ic_launcher.png). N'invente aucune image, ne touche pas
à la photo de l'avatar, ne supprime rien (l'ancien drawable reste en place). Idempotent.
Usage : python3 scripts/inject_adaptive_icon_v1.py <dossier_projet_android>"""
import sys, re
from pathlib import Path
from PIL import Image, ImageDraw

root = Path(sys.argv[1] if len(sys.argv) > 1 else "android_project")
cands = list(root.rglob("app/src/main/res/drawable-nodpi/ic_launcher.png"))
if not cands:
    sys.exit("ERREUR : icône officielle res/drawable-nodpi/ic_launcher.png introuvable — rien généré.")
res = cands[0].parents[1]                      # .../res
manifest = res.parent / "AndroidManifest.xml"
src = Image.open(cands[0]).convert("RGB")
if src.size[0] < 432 or src.size[1] < 432:
    sys.exit("ERREUR : image source trop petite (%s)." % (src.size,))

# Couleur de fond adaptatif = moyenne des pixels du bord de l'image officielle (pas de couleur inventée)
w, h = src.size
edge = [src.getpixel((x, y)) for x in range(0, w, 8) for y in (0, h - 1)] + \
       [src.getpixel((x, y)) for y in range(0, h, 8) for x in (0, w - 1)]
bg = tuple(sum(c[i] for c in edge) // len(edge) for i in range(3))
bg_hex = "#%02X%02X%02X" % bg

# 1) Premier plan adaptatif : logo à ~64 % (zone sûre de 66/108 dp), fond transparent
S = 432
fg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
inner = int(S * 0.64)
fg.paste(src.resize((inner, inner), Image.LANCZOS), ((S - inner) // 2, (S - inner) // 2))
fg.save(res / "drawable-nodpi" / "ic_launcher_foreground.png", optimize=True)

# 2) Couleur de fond
(res / "values").mkdir(exist_ok=True)
(res / "values" / "ic_launcher_background.xml").write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">%s</color>\n</resources>\n' % bg_hex,
    encoding="utf-8")

# 3) Descripteurs adaptatifs (Android 8+)
(res / "mipmap-anydpi-v26").mkdir(exist_ok=True)
xml = ('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
       '    <background android:drawable="@color/ic_launcher_background"/>\n'
       '    <foreground android:drawable="@drawable/ic_launcher_foreground"/>\n</adaptive-icon>\n')
for n in ("ic_launcher.xml", "ic_launcher_round.xml"):
    (res / "mipmap-anydpi-v26" / n).write_text(xml, encoding="utf-8")

# 4) Icônes classiques (Android < 8) : carrée et ronde
for d, px in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
    (res / ("mipmap-" + d)).mkdir(exist_ok=True)
    sq = src.resize((px, px), Image.LANCZOS)
    sq.save(res / ("mipmap-" + d) / "ic_launcher.png", optimize=True)
    m = Image.new("L", (px * 4, px * 4), 0); ImageDraw.Draw(m).ellipse((0, 0, px * 4 - 1, px * 4 - 1), fill=255)
    m = m.resize((px, px), Image.LANCZOS)
    rd = Image.new("RGBA", (px, px), (0, 0, 0, 0)); rd.paste(sq, (0, 0), m)
    rd.save(res / ("mipmap-" + d) / "ic_launcher_round.png", optimize=True)

# 5) Manifeste : pointer vers les mipmap (seuls les deux attributs d'icône changent)
t = manifest.read_text(encoding="utf-8")
t2 = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ic_launcher"', t, count=1)
t2 = re.sub(r'android:roundIcon="[^"]*"', 'android:roundIcon="@mipmap/ic_launcher_round"', t2, count=1)
if 'android:roundIcon=' not in t2:
    t2 = t2.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher_round"', 1)
assert 'android:icon="@mipmap/ic_launcher"' in t2 and 'android:roundIcon="@mipmap/ic_launcher_round"' in t2
manifest.write_text(t2, encoding="utf-8")
print("Icône adaptative générée depuis", cands[0], "- fond", bg_hex, "- manifeste mis à jour")
