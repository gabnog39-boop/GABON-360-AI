# GABON 360 AI V290 — functional Android build

Cette version remplace la maquette locale précédente par une application Android réellement interactive en mode local : navigation par modules, événements, alertes, missions, audit, rapport JSON, commande vocale native, synthèse vocale native, GPS, caméra du téléphone et contrôles OWNER de démonstration.

Les données satellite, SIG officiel, caméras distantes, drones, météo et paiement restent des intégrations serveur à brancher sur l'infrastructure de production. L'application ne prétend pas être connectée à ces flux tant qu'ils ne sont pas configurés.

Le workflow GitHub Actions compile directement le projet Android présent dans le dépôt.


## V157 — Centre national de situation
- Carte Leaflet réelle du Gabon avec fond OpenStreetMap.
- Couches UGEO WMS : provinces, routes, hydrographie, aires protégées et localités.
- Interprétation d'une position par contexte cartographique.
- Événements géolocalisés sur la carte et chaîne opérationnelle.
- Avatar animé avec états veille/parole et commande vocale/TTS native.
- Les données d'observation restent distinctes des preuves : validation humaine requise.


## V157 — Centre opérationnel unifié
- Interface runtime unifiée : `app/src/main/assets/index.html` embarque CSS + JavaScript opérationnel.
- Cartographie OSM + couches WMS UGEO : provinces, départements, routes, hydrographie, localités, aires protégées.
- Recherche territoriale par Nominatim et interprétation de position par géocodage inverse.
- Fond satellite optionnel et fond relief.
- Événements géolocalisés, validation humaine, alertes, missions, rapports et audit local.
- Avatar animé avec synthèse vocale et commandes vocales natives.
- Les flux drone/caméra distants restent désactivés tant qu'une source autorisée n'est pas configurée.


## V158 — Centre territorial renforcé
- WFS UGEO pour enrichir le contexte province/département/localité/aire protégée sur les clics carte.
- Création d'observation directement depuis une position cartographique, avec validation humaine.
- Météo Open-Meteo par position.
- Contrôles d'opacité des couches SIG.
- Recherche cartographique et fond satellite/relief conservés.
- Avatar : état parler/veille + clignement visuel léger, sans prétendre à une détection biométrique.
- Les flux drone/caméra restent explicitement soumis à une source autorisée et à la validation humaine.


## V159 — Navigation terrain
- Mode téléphone pour patrouilleurs : GPS haute précision, cap/boussole, destination, distance et orientation.
- Trace de patrouille avec points GPS exportables.
- Moteur local d'aide à la décision : précision GPS, météo, hydrographie et contexte cartographique.
- Satellite présenté comme source d'observation territoriale, jamais comme flux garanti en direct.
- Les risques automatiques restent des indications et ne remplacent pas la vérification humaine sur le terrain.


## V160 — Terrain hors-ligne + liaison satellite
- Fonctionnement local sans Wi‑Fi/réseau mobile : GPS, navigation, boussole, cartes en cache et règles terrain.
- File locale de données (store-and-forward) pour observations et positions.
- Détection Android du transport réseau SATELLITE lorsque le matériel/OS expose cette capacité.
- Synchronisation lorsque la connectivité revient.
- Annonces vocales de situation au patrouilleur.
- La connectivité satellite dépend d’un équipement/service satellite compatible ; elle n’est pas créée par l’application elle-même.

## V161 — Assistant de patrouille hors connexion
- Mode forêt sans Wi‑Fi ni réseau mobile.
- GPS, navigation, trace et observations conservés localement.
- File locale de synchronisation lorsque la connexion revient.
- Moteur d’alertes vocales locales pour GPS, destination et état de navigation.
- Préparation d’un secteur de mission hors ligne.
- Les données satellite distantes ne sont pas présentées comme du temps réel hors connexion.

## V161 — Assistant de patrouille hors connexion
- Mode forêt utilisable sans Wi-Fi ni réseau mobile.
- GPS, boussole, navigation, traces et observations conservés localement.
- File locale de synchronisation quand une connexion revient.
- Alertes vocales locales pour perte/imprécision GPS, cap indisponible et proximité de destination.
- Préparation d’un secteur de mission pour usage terrain.
- La liaison satellite est traitée comme un moyen de synchronisation lorsque du matériel/service compatible est disponible.
- L’imagerie satellite distante n’est pas présentée comme du temps réel hors connexion.


## V162 — Cartographie hors connexion
- Préparation d’un secteur de patrouille.
- Téléchargement de tuiles OpenStreetMap dans le Cache Storage du WebView.
- Utilisation du cache lorsque la connexion disparaît.
- Trace, GPS, alertes locales et file de synchronisation conservés.
- La carte hors ligne nécessite une préparation préalable du secteur lorsque le réseau est disponible.


### V165 — Vision IA locale
La caméra terrain déclenche maintenant une analyse ML Kit embarquée sur le téléphone. Les modèles de base sont intégrés à l'application afin que l'analyse puisse fonctionner hors connexion après installation. Les résultats restent indicatifs et doivent être validés par le patrouilleur.

### V166 — Carte territoriale GABON 360
La carte principale utilise désormais la couche territoriale déjà intégrée au projet GABON 360 comme référence. Les fonds de tuiles OSM/Esri/OpenTopoMap ne sont plus utilisés comme fond cartographique principal et aucun téléchargement automatique de nouvelles tuiles n'est effectué. Les couches provinces, départements, routes, eaux, parcs protégés et localités restent activables individuellement. Pour un vrai fonctionnement cartographique 100 % hors connexion, les données territoriales devront à terme être embarquées localement dans l'application.

## V183 final consolidated candidate
The V183 package consolidates the current application features into one Android project. Historical version archives are intentionally not shipped as separate applications.
