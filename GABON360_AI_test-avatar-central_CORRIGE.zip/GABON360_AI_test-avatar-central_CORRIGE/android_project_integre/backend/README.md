# GABON 360 AI — Centre serveur V176

Centre central local pour GABON 360 AI : SQLite, synchronisation, heartbeat, état des appareils et tableau de contrôle `/center`.

## Démarrage
```bash
export GABON360_SERVER_TOKEN='CHANGER_CE_JETON'
python3 server.py
```
- `GET /health` : santé
- `GET /center` : tableau de contrôle web
- `POST /api/v1/sync` : synchronisation
- `POST /api/v1/heartbeat` : présence appareil
- `GET /api/v1/state` : appareils et état réseau
- `GET /api/v1/events` : événements
- `GET /api/v1/alerts` : alertes
- `GET /api/v1/missions` : missions
- `GET /api/v1/patrols` : patrouilles

Le serveur utilise SQLite sans dépendance Python externe. Le jeton est configuré côté serveur et saisi dans l'application.

Pour Internet, utiliser un reverse-proxy HTTPS (Caddy/Nginx) et ne pas exposer directement le port HTTP 8080.


## V176 — Centre national de situation
Ajout de /api/v1/summary, /api/v1/audit et /api/v1/device/<device_id>, tableau /center actualisé automatiquement, compteurs nationaux, activité récente et traçabilité appareil.


## V177 — Command Grid
- `/api/v1/geo` fournit les positions opérationnelles disponibles.
- `/api/v1/record/<type>/<id>` permet les mises à jour d'état auditées.
- Le statut EN LIGNE du centre est recalculé avec une fenêtre de fraîcheur de 180 secondes.
- Les observations de patrouille sont normalisées dans les enregistrements centraux.
