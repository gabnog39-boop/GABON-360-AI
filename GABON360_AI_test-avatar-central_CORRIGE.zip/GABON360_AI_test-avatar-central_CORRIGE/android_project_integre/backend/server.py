#!/usr/bin/env python3
import os, json, sqlite3, uuid, datetime, hmac
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

HOST=os.getenv('GABON360_HOST','0.0.0.0'); PORT=int(os.getenv('GABON360_PORT','8080'))
DB=os.getenv('GABON360_DB','gabon360.db'); TOKEN=os.getenv('GABON360_SERVER_TOKEN','')
MAX_BODY=2*1024*1024

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.executescript('''CREATE TABLE IF NOT EXISTS devices(device_id TEXT PRIMARY KEY,last_seen TEXT,online INTEGER,satellite INTEGER,transport TEXT,gps TEXT,app_version TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS syncs(id TEXT PRIMARY KEY,device_id TEXT,received_at TEXT,payload TEXT);
CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT,device_id TEXT,type TEXT,record_id TEXT,received_at TEXT,payload TEXT,UNIQUE(device_id,type,record_id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT,device_id TEXT,action TEXT,detail TEXT);''')
    return c

def auth(h):
    if not TOKEN: return True
    return hmac.compare_digest(h.get('Authorization',''), 'Bearer '+TOKEN)

def jloads(x, default=None):
    try: return json.loads(x)
    except Exception: return default if default is not None else {}

def recent(c, typ, limit=200):
    rows=c.execute('select * from records where type=? order by received_at desc limit ?', (typ,limit)).fetchall()
    return [dict(id=r['record_id'],device_id=r['device_id'],received_at=r['received_at'],**jloads(r['payload'])) for r in rows]

class H(BaseHTTPRequestHandler):
    server_version='GABON360-CENTER/181'
    def sendj(self,code,obj):
        b=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self): self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Headers','Content-Type, Authorization'); self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS'); self.end_headers()
    def center(self):
        html='''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GABON 360 AI — Centre national</title><style>body{font-family:system-ui;background:#06100b;color:#edf8ef;margin:0;padding:16px}.top{position:sticky;top:0;background:#08150f;padding:10px 0;z-index:2}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}.card{background:#102019;border:1px solid #29503a;border-radius:14px;padding:14px}.big{font-size:28px;font-weight:800}.muted{opacity:.68}.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}button,input{padding:10px;border-radius:9px;border:1px solid #355744;background:#0d1c15;color:#eef7f0}button{cursor:pointer}section{margin-top:16px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:800px){.cols{grid-template-columns:1fr}}pre{white-space:pre-wrap;word-break:break-word;max-height:340px;overflow:auto}.ok{color:#b8f5c5}.warn{color:#ffe5a8}.danger{color:#ffb4b4}.item{padding:9px;border-bottom:1px solid #21402f}.pill{display:inline-block;padding:3px 7px;border-radius:99px;background:#183325;margin:2px;font-size:12px}</style></head><body><div class="top"><h1>🇬🇦 GABON 360 AI — Centre national de situation</h1><div class="muted">V176 · données reçues, traçables et soumises aux règles de validation humaine</div><div class="toolbar"><input id="t" placeholder="Jeton serveur" type="password"><button onclick="localStorage.g360token=q('t').value;load()">Connexion</button><button onclick="load()">Actualiser</button></div></div><div class="grid" id="k"></div><section class="cols"><div class="card"><h2>Événements récents</h2><div id="events"></div></div><div class="card"><h2>Alertes</h2><div id="alerts"></div></div></section><section class="cols"><div class="card"><h2>Missions</h2><div id="missions"></div></div><div class="card"><h2>Patrouilles</h2><div id="patrols"></div></div></section><section class="card"><h2>Appareils / terrain</h2><div id="devices"></div></section><section class="card"><h2>Audit</h2><pre id="audit"></pre></section><script>const q=id=>document.getElementById(id);function h(){return {'Authorization':'Bearer '+(localStorage.g360token||q('t').value)}}async function api(p){let r=await fetch(p,{headers:h(),cache:'no-store'});let j=await r.json();if(!r.ok)throw new Error(j.error||r.status);return j}function esc(s){return String(s??'').replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]))}function list(arr){return (arr||[]).slice(0,20).map(x=>'<div class=item><b>'+esc(x.title||x.name||x.type||x.id||'Élément')+'</b><div class=muted>'+esc(x.zone||x.status||x.priority||x.received_at||'')+'</div></div>').join('')||'<div class=muted>Aucune donnée</div>'}async function load(){try{let [s,e,a,m,p,d,u]=await Promise.all([api('/api/v1/summary'),api('/api/v1/events'),api('/api/v1/alerts'),api('/api/v1/missions'),api('/api/v1/patrols'),api('/api/v1/state'),api('/api/v1/audit?limit=60')]);q('k').innerHTML=[['Appareils',s.devices.total],['En ligne',s.devices.online],['Événements',s.records.event],['Alertes ouvertes',s.records.alert_open],['Missions actives',s.records.mission_active],['Patrouilles',s.records.patrol],['Satellite signalé',s.devices.satellite],['Dernière activité',s.last_activity||'—']].map((x,i)=>'<div class=card><div class=muted>'+x[0]+'</div><div class=big>'+esc(x[1])+'</div></div>').join('');q('events').innerHTML=list(e.items);q('alerts').innerHTML=list(a.items);q('missions').innerHTML=list(m.items);q('patrols').innerHTML=list(p.items);q('devices').innerHTML=(d.devices||[]).map(x=>'<div class=item><b>'+esc(x.device_id)+'</b> <span class=pill>'+ (x.online?'EN LIGNE':'HORS LIGNE')+'</span> <span class=pill>'+esc(x.transport||'NONE')+'</span><div class=muted>Dernier signal: '+esc(x.last_seen)+' · GPS: '+esc(x.gps)+' · App: '+esc(x.app_version)+'</div></div>').join('')||'<div class=muted>Aucun appareil</div>';q('audit').textContent=(u.items||[]).map(x=>x.at+'  '+x.action+'  '+x.device_id+'  '+x.detail).join('\\n')||'Aucun audit';}catch(e){q('k').innerHTML='<div class="card danger">Erreur: '+esc(e.message)+'</div>'}}if(localStorage.g360token)q('t').value=localStorage.g360token;load();setInterval(load,15000)</script></body></html>'''
        b=html.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        p=urlparse(self.path); path=p.path; qs=parse_qs(p.query)
        if path=='/health': return self.sendj(200,{'ok':True,'service':'GABON 360 AI Centre','version':'181.0-national-ai-engine','time':now()})
        if path=='/center': return self.center()
        if not auth(self.headers): return self.sendj(401,{'ok':False,'error':'AUTH_REQUIRED'})
        c=db()
        if path=='/api/v1/state':
            d=c.execute('select * from devices order by last_seen desc').fetchall(); return self.sendj(200,{'ok':True,'devices':[dict(x) for x in d],'server_time':now()})
        if path=='/api/v1/summary':
            now_dt=datetime.datetime.now(datetime.timezone.utc)
            rows=c.execute('select * from devices order by last_seen desc').fetchall()
            fresh=[]
            for r in rows:
                try: age=(now_dt-datetime.datetime.fromisoformat(r['last_seen'].replace('Z','+00:00'))).total_seconds()
                except Exception: age=10**9
                fresh.append((r,age))
            cnt=lambda typ:c.execute('select count(*) n from records where type=?',(typ,)).fetchone()['n']
            open_alert=c.execute("select count(*) n from records where type='alert' and upper(coalesce(json_extract(payload,'$.status'),'')) not in ('RESOLUE','FERMEE','CLOTUREE')").fetchone()['n']
            active_m=c.execute("select count(*) n from records where type='mission' and upper(coalesce(json_extract(payload,'$.status'),'')) not in ('TERMINEE','TERMINÉE','CLOTUREE','CLOTURÉE')").fetchone()['n']
            high_alert=c.execute("select count(*) n from records where type='alert' and upper(coalesce(json_extract(payload,'$.priority'),json_extract(payload,'$.severity'),''))='HAUTE'").fetchone()['n']
            last=c.execute('select max(received_at) t from records').fetchone()['t']
            return self.sendj(200,{'ok':True,'devices':{'total':len(rows),'online':sum(1 for _,age in fresh if age<=180),'reported_online':sum(1 for r,_ in fresh if r['online']),'satellite':sum(1 for r,_ in fresh if r['satellite']),'stale':sum(1 for _,age in fresh if age>180)},'records':{'event':cnt('event'),'alert':cnt('alert'),'alert_open':open_alert,'alert_high':high_alert,'mission':cnt('mission'),'mission_active':active_m,'patrol':cnt('patrol')},'last_activity':last,'server_time':now()})
        if path=='/api/v1/situation':
            # Situation fusion: descriptive prioritization only; no automatic enforcement decision.
            alerts=recent(c,'alert',200); events=recent(c,'event',200); missions=recent(c,'mission',200); patrols=recent(c,'patrol',200)
            def rank(x):
                v=str(x.get('priority',x.get('severity',''))).upper()
                return {'CRITIQUE':4,'CRITICAL':4,'HAUTE':3,'HIGH':3,'MOYENNE':2,'MEDIUM':2,'BASSE':1,'LOW':1}.get(v,0)
            ranked=sorted(alerts,key=lambda x:(rank(x),x.get('received_at','')),reverse=True)
            high=[x for x in ranked if rank(x)>=3 and str(x.get('status','')).upper() not in ('RESOLUE','FERMEE','CLOTUREE','CLOTURÉE')]
            areas={}
            for x in alerts+events:
                zone=x.get('zone') or x.get('province') or x.get('department') or x.get('territory')
                if zone: areas[str(zone)]=areas.get(str(zone),0)+1
            hotspots=sorted([{'zone':k,'signals':v} for k,v in areas.items()],key=lambda x:x['signals'],reverse=True)[:20]
            return self.sendj(200,{'ok':True,'generated_at':now(),'principles':['signal fusion','human validation','traceability','no automatic enforcement decision'],'priority_alerts':high[:20],'hotspots':hotspots,'counts':{'alerts':len(alerts),'events':len(events),'missions':len(missions),'patrols':len(patrols)}})
        if path=='/api/v1/digital-twin':
            # Représentation descriptive du territoire opérationnel: aucune inférence géographique non sourcée.
            devices=c.execute('select * from devices order by last_seen desc').fetchall()
            layers=['provinces','departements','routes','rivières','lacs','localités','aires protégées','événements','alertes','missions','patrouilles']
            counts={}
            for typ in ('event','alert','mission','patrol'):
                counts[typ]=c.execute('select count(*) n from records where type=?',(typ,)).fetchone()['n']
            gps=[]
            for r in devices:
                g=jloads(r['gps'],{}) or {}
                if isinstance(g,dict) and g.get('lat') is not None and g.get('lon') is not None:
                    gps.append({'kind':'device','id':r['device_id'],'lat':g['lat'],'lon':g['lon'],'at':r['last_seen'],'online':bool(r['online']),'transport':r['transport']})
            return self.sendj(200,{'ok':True,'schema':'gabon360.digital-twin.v1','generated_at':now(),'territory':{'country':'Gabon','status':'CENTRE_OPERATIONNEL','layers':layers},'counts':counts,'devices':len(devices),'positions':gps,'data_principles':['source traceability','time awareness','human validation','no invented territorial facts']})
        if path=='/api/v1/ai/status':
            return self.sendj(200,{'ok':True,'engine':'GABON360-SPATIAL-AI','version':'180.0','mode':'explainable-rule-engine','capabilities':['multi-source-correlation','temporal-analysis','spatial-context','data-quality','human-validation-gate'],'specialized_vision_model':False})
        if path=='/api/v1/ai/analyze':
            # Deterministic, explainable decision-support only. Never an enforcement decision.
            lim=min(int(qs.get('limit',['100'])[0]),300)
            alerts=recent(c,'alert',lim); events=recent(c,'event',lim); patrols=recent(c,'patrol',lim); missions=recent(c,'mission',lim)
            nowdt=datetime.datetime.now(datetime.timezone.utc)
            def age_hours(x):
                t=x.get('received_at') or x.get('at')
                try:return max(0,(nowdt-datetime.datetime.fromisoformat(str(t).replace('Z','+00:00'))).total_seconds()/3600)
                except:return 9999
            high=[x for x in alerts if str(x.get('priority') or x.get('severity') or '').upper() in ('HAUTE','HIGH','CRITIQUE','CRITICAL')]
            opena=[x for x in alerts if str(x.get('status') or '').upper() not in ('RESOLUE','FERMEE','CLOTUREE','CLOTURÉE')]
            recent_events=[x for x in events if age_hours(x)<=24]
            gps=[x for x in patrols if x.get('lat') is not None and x.get('lon') is not None]
            signals=[]; score=0.0
            if high: score+=0.45; signals.append({'source':'ALERTES','finding':f'{len(high)} alerte(s) de priorité élevée','weight':0.45})
            if len(opena)>=3: score+=0.15; signals.append({'source':'ALERTES','finding':f'{len(opena)} alertes ouvertes','weight':0.15})
            if recent_events: score+=0.15; signals.append({'source':'EVENEMENTS','finding':f'{len(recent_events)} événement(s) reçu(s) sur 24 h','weight':0.15})
            if gps: score+=0.10; signals.append({'source':'PATROUILLES','finding':f'{len(gps)} observation(s) géolocalisée(s)','weight':0.10})
            if missions: score+=0.05; signals.append({'source':'MISSIONS','finding':f'{len(missions)} mission(s) connue(s)','weight':0.05})
            score=min(score,0.95)
            if high: priority='HAUTE'
            elif opena or recent_events: priority='MOYENNE'
            else: priority='BASSE'
            action={'HAUTE':'Vérifier les sources, localiser les éléments concernés et demander une validation humaine avant toute décision.','MOYENNE':'Surveiller, corréler les sources disponibles et programmer une vérification terrain si nécessaire.','BASSE':'Maintenir la veille et attendre de nouveaux signaux fiables.'}[priority]
            return self.sendj(200,{'ok':True,'schema':'gabon360.ai-analysis.v1','generated_at':now(),'engine':'GABON360-SPATIAL-AI/180','state':'ANALYSE','confidence':round(score,2),'priority':priority,'proposed_action':action,'signals':signals,'counts':{'alerts_open':len(opena),'alerts_high':len(high),'events_24h':len(recent_events),'patrols_geolocated':len(gps),'missions':len(missions)},'human_validation_required':True,'limitations':['rule-based decision support','not proof','no autonomous enforcement','no specialized terrain vision model']})
        if path=='/api/v1/ai/situation':
            # Intelligence spatiale/temps: regroupe les signaux géolocalisés proches et récents.
            # Ce moteur est une aide à la décision, pas une preuve ni une décision autonome.
            import math
            hours=max(1.0,min(float(qs.get('hours',['24'])[0]),168.0)); radius=max(1.0,min(float(qs.get('radius_km',['15'])[0]),100.0))
            cutoff=(datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(hours=hours)).isoformat()
            pts=[]
            for typ in ('event','alert','mission','patrol'):
                rows=c.execute('select record_id,device_id,received_at,payload from records where type=? and received_at>=? order by received_at desc limit 1000',(typ,cutoff)).fetchall()
                for r in rows:
                    x=jloads(r['payload'],{}) or {}; lat=x.get('lat'); lon=x.get('lon')
                    try: lat=float(lat); lon=float(lon)
                    except: continue
                    pts.append({'kind':typ,'id':r['record_id'],'device_id':r['device_id'],'at':r['received_at'],'lat':lat,'lon':lon,'priority':str(x.get('priority') or x.get('severity') or '').upper(),'status':str(x.get('status') or '').upper(),'title':x.get('title') or x.get('name') or typ})
            def hav(a,b):
                R=6371.0088; p1=math.radians(a['lat']);p2=math.radians(b['lat']);dp=math.radians(b['lat']-a['lat']);dl=math.radians(b['lon']-a['lon']);qv=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2;return 2*R*math.asin(min(1,math.sqrt(qv)))
            clusters=[]
            for pt in pts:
                best=None;bd=10**9
                for i,cl in enumerate(clusters):
                    d=hav(pt,cl['centroid'])
                    if d<=radius and d<bd: best=i;bd=d
                if best is None:
                    clusters.append({'centroid':{'lat':pt['lat'],'lon':pt['lon']},'points':[pt],'radius_km':0.0})
                else:
                    cl=clusters[best]; cl['points'].append(pt)
                    n=len(cl['points']); cl['centroid']['lat']=(cl['centroid']['lat']*(n-1)+pt['lat'])/n; cl['centroid']['lon']=(cl['centroid']['lon']*(n-1)+pt['lon'])/n; cl['radius_km']=max(cl['radius_km'],bd)
            out=[]
            for i,cl in enumerate(clusters):
                ps=cl['points']; kinds=sorted(set(x['kind'] for x in ps)); high=sum(x['priority'] in ('HAUTE','HIGH','CRITIQUE','CRITICAL') for x in ps); confirmed=sum(x['status'] in ('CONFIRME','CONFIRMÉ','CONFIRMÉE','VALIDÉ','VALIDEE') for x in ps); devices=len(set(x['device_id'] for x in ps))
                density=min(1.0,len(ps)/8); diversity=min(1.0,len(kinds)/4); corroboration=min(1.0,devices/3); highf=min(1.0,high/3)
                score=min(0.95,0.25*density+0.25*diversity+0.25*corroboration+0.25*highf)
                priority='HAUTE' if score>=0.70 else ('MOYENNE' if score>=0.35 else 'BASSE')
                out.append({'cluster_id':f'Z{i+1:03d}','centroid':cl['centroid'],'radius_km':round(cl['radius_km'],2),'signals':len(ps),'sources':kinds,'devices':devices,'high_priority_signals':high,'human_confirmed_signals':confirmed,'confidence':round(score,2),'priority':priority,'recommended_action':'Demander une vérification terrain et croiser les sources avant toute décision.' if priority=='HAUTE' else ('Maintenir la surveillance et rechercher une seconde source.' if priority=='MOYENNE' else 'Maintenir la veille.'),'items':ps[:30]})
            out.sort(key=lambda x:(x['confidence'],x['signals']),reverse=True)
            return self.sendj(200,{'ok':True,'schema':'gabon360.ai-situation.v1','engine':'GABON360-SPATIAL-AI/181','generated_at':now(),'window_hours':hours,'cluster_radius_km':radius,'signals_total':len(pts),'zones':out[:100],'principles':['spatial clustering','temporal window','source diversity','human validation','no autonomous enforcement'],'limitations':['clusters are analytical zones, not official administrative boundaries','no specialized terrain classifier','confidence is a decision-support score, not probability of an event']})
        if path=='/api/v1/ai/explain':
            typ=str(qs.get('type',[''])[0]); rid=str(qs.get('id',[''])[0])
            if not typ or not rid:return self.sendj(400,{'ok':False,'error':'TYPE_AND_ID_REQUIRED'})
            r=c.execute('select * from records where type=? and record_id=? order by id desc limit 1',(typ,rid)).fetchone()
            if not r:return self.sendj(404,{'ok':False,'error':'RECORD_NOT_FOUND'})
            x=jloads(r['payload'],{}) or {}
            factors=[]
            if x.get('priority'): factors.append({'factor':'priority','value':x.get('priority'),'meaning':'priorité déclarée par la source'})
            if x.get('status'): factors.append({'factor':'status','value':x.get('status'),'meaning':'état courant du signal'})
            if x.get('validation') or x.get('validated_by'): factors.append({'factor':'human_validation','value':x.get('validation') or x.get('validated_by'),'meaning':'validation humaine enregistrée'})
            if x.get('lat') is not None and x.get('lon') is not None: factors.append({'factor':'geolocation','value':{'lat':x.get('lat'),'lon':x.get('lon')},'meaning':'position fournie par la source'})
            return self.sendj(200,{'ok':True,'schema':'gabon360.ai-explain.v1','engine':'GABON360-SPATIAL-AI/181','record':{'type':typ,'id':rid,'device_id':r['device_id'],'received_at':r['received_at']},'factors':factors,'raw_fields':list(x.keys()),'human_validation_required':True})
        if path=='/api/v1/timeline':
            lim=min(int(qs.get('limit',['100'])[0]),500); rows=c.execute('select type,record_id,device_id,received_at,payload from records order by received_at desc limit ?',(lim,)).fetchall()
            return self.sendj(200,{'ok':True,'items':[{'type':r['type'],'record_id':r['record_id'],'device_id':r['device_id'],'at':r['received_at'],'title':(jloads(r['payload'],{}) or {}).get('title') or (jloads(r['payload'],{}) or {}).get('name') or r['type'],'status':(jloads(r['payload'],{}) or {}).get('status'),'priority':(jloads(r['payload'],{}) or {}).get('priority')} for r in rows]})
        if path=='/api/v1/geo':
            lim=min(int(qs.get('limit',['300'])[0]),1000); points=[]
            for r in c.execute('select device_id,gps,last_seen,online,satellite,transport,app_version from devices').fetchall():
                g=jloads(r['gps'],{}) or {}
                if isinstance(g,dict) and g.get('lat') is not None and g.get('lon') is not None: points.append({'kind':'device','id':r['device_id'],'lat':g.get('lat'),'lon':g.get('lon'),'at':r['last_seen'],'online':bool(r['online']),'satellite':bool(r['satellite']),'transport':r['transport'],'app_version':r['app_version']})
            for typ in ('event','alert','mission','patrol'):
                for r in c.execute('select record_id,device_id,received_at,payload from records where type=? order by received_at desc limit ?', (typ,lim)).fetchall():
                    x=jloads(r['payload'],{}) or {}; lat=x.get('lat'); lon=x.get('lon')
                    if lat is None or lon is None: continue
                    points.append({'kind':typ,'id':r['record_id'],'device_id':r['device_id'],'lat':lat,'lon':lon,'at':r['received_at'],'title':x.get('title') or x.get('name') or x.get('type') or typ,'priority':x.get('priority') or x.get('severity'),'status':x.get('status')})
            return self.sendj(200,{'ok':True,'points':points[:lim],'server_time':now()})
        mapping={'/api/v1/events':'event','/api/v1/alerts':'alert','/api/v1/missions':'mission','/api/v1/patrols':'patrol'}
        if path in mapping:
            lim=min(int(qs.get('limit',['200'])[0]),1000); return self.sendj(200,{'ok':True,'items':recent(c,mapping[path],lim)})
        if path=='/api/v1/audit':
            lim=min(int(qs.get('limit',['200'])[0]),1000); rows=c.execute('select * from audit order by id desc limit ?',(lim,)).fetchall(); return self.sendj(200,{'ok':True,'items':[dict(x) for x in rows]})
        if path.startswith('/api/v1/device/'):
            did=path.split('/')[-1]; r=c.execute('select * from devices where device_id=?',(did,)).fetchone();
            if not r:return self.sendj(404,{'ok':False,'error':'DEVICE_NOT_FOUND'})
            rows=c.execute('select * from records where device_id=? order by received_at desc limit 100',(did,)).fetchall(); return self.sendj(200,{'ok':True,'device':dict(r),'records':[dict(type=x['type'],record_id=x['record_id'],received_at=x['received_at'],payload=jloads(x['payload'])) for x in rows]})
        return self.sendj(404,{'ok':False,'error':'NOT_FOUND'})
    def do_POST(self):
        p=urlparse(self.path).path
        if not auth(self.headers): return self.sendj(401,{'ok':False,'error':'AUTH_REQUIRED'})
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n>MAX_BODY:return self.sendj(413,{'ok':False,'error':'PAYLOAD_TOO_LARGE'})
            data=json.loads(self.rfile.read(n) or b'{}')
        except Exception:return self.sendj(400,{'ok':False,'error':'INVALID_JSON'})
        c=db(); received=now()
        if p.startswith('/api/v1/record/'):
            parts=p.strip('/').split('/')
            if len(parts)<4: return self.sendj(400,{'ok':False,'error':'INVALID_RECORD_PATH'})
            typ=parts[2].rstrip('s'); rid='/'.join(parts[3:]); body=data if isinstance(data,dict) else {}
            row=c.execute('select * from records where type=? and record_id=? order by id desc limit 1',(typ,rid)).fetchone()
            if not row: return self.sendj(404,{'ok':False,'error':'RECORD_NOT_FOUND'})
            payload=jloads(row['payload'],{}) or {}; changed=[]
            for key in ('status','priority','validation','validated_by','note'):
                if key in body: payload[key]=body[key]; changed.append(key)
            c.execute('update records set payload=? where id=?',(json.dumps(payload,ensure_ascii=False),row['id']))
            c.execute('insert into audit(at,device_id,action,detail) values(?,?,?,?)',(received,row['device_id'],'RECORD_UPDATE',json.dumps({'type':typ,'record_id':rid,'changed':changed},ensure_ascii=False)))
            c.commit(); return self.sendj(200,{'ok':True,'type':typ,'record_id':rid,'payload':payload,'server_time':received})
        if p in ('/api/v1/sync','/api/v1/heartbeat'):
            device=str(data.get('device_id') or data.get('device',{}).get('device_id') or 'unknown')
            if p.endswith('sync') and data.get('schema')!='gabon360.sync.v1': return self.sendj(400,{'ok':False,'error':'INVALID_SCHEMA'})
            dev=data.get('device',{}) if isinstance(data.get('device'),dict) else data
            c.execute('''INSERT INTO devices(device_id,last_seen,online,satellite,transport,gps,app_version,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET last_seen=excluded.last_seen,online=excluded.online,satellite=excluded.satellite,transport=excluded.transport,gps=excluded.gps,app_version=excluded.app_version,updated_at=excluded.updated_at''',(device,received,int(bool(dev.get('online',True))),int(bool(dev.get('satellite',False))),str(dev.get('transport','')),json.dumps(dev.get('gps',{}),ensure_ascii=False),str(data.get('app_version',dev.get('app_version',''))),received))
            if p.endswith('sync'):
                sid=str(uuid.uuid4()); c.execute('insert into syncs values(?,?,?,?)',(sid,device,received,json.dumps(data,ensure_ascii=False))); accepted=[]
                patrol_payload=data.get('patrol',[]) or []
                if isinstance(patrol_payload,dict): patrol_payload=patrol_payload.get('observations',[]) or []
                for typ,key in [('events','event_id'),('alerts','alert_id'),('missions','mission_id'),('patrol','id')]:
                    vals=patrol_payload if typ=='patrol' else (data.get(typ,[]) or []); vals=vals if isinstance(vals,list) else [vals]
                    for item in vals:
                        if isinstance(item,dict):
                            rid=str(item.get(key) or item.get('id') or uuid.uuid4());
                            try:c.execute('insert into records(device_id,type,record_id,received_at,payload) values(?,?,?,?,?)',(device,typ.rstrip('s'),rid,received,json.dumps(item,ensure_ascii=False)));accepted.append({'type':typ,'id':rid})
                            except sqlite3.IntegrityError:accepted.append({'type':typ,'id':rid,'duplicate':True})
                c.execute('insert into audit(at,device_id,action,detail) values(?,?,?,?)',(received,device,'SYNC',json.dumps({'accepted':len(accepted),'sync_id':sid})));c.commit();return self.sendj(200,{'ok':True,'sync_id':sid,'accepted_ids':accepted,'server_time':received})
            c.execute('insert into audit(at,device_id,action,detail) values(?,?,?,?)',(received,device,'HEARTBEAT',json.dumps({'transport':dev.get('transport',''),'satellite':bool(dev.get('satellite',False))})));c.commit();return self.sendj(200,{'ok':True,'server_time':received})
        return self.sendj(404,{'ok':False,'error':'NOT_FOUND'})
    def log_message(self,*a): pass

if __name__=='__main__':
    print(f'GABON 360 AI Centre V180 listening on {HOST}:{PORT}')
    ThreadingHTTPServer((HOST,PORT),H).serve_forever()
