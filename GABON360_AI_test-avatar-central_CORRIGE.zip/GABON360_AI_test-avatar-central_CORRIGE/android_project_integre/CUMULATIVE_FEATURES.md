# GABON 360 AI — V155 UNIFIED FUNCTIONAL

Cette version unifie dans une seule application Android les capacités cumulées développées jusqu'à V155.

## Fonctions opérationnelles locales
- Centre de situation
- carte locale interactive avec événements
- 13 parcs nationaux + 9 provinces
- couches SIG de démonstration
- sources / état / rafraîchissement
- alertes et prise en compte
- événements + validation humaine
- missions + clôture
- scénario bout-en-bout
- historique et audit local
- rapports JSON + sauvegarde Android
- partage de rapport
- commande texte
- reconnaissance vocale native Android
- synthèse vocale native Android
- avatar animé pendant la parole
- GPS du téléphone
- caméra du téléphone
- contrôle OWNER local (suspension/réactivation)
- paramètres et persistance locale

## Capacités backend cumulées embarquées comme références
Les bundles backend V123 à V154 sont inclus dans `app/src/main/assets/backend_versions/` afin de conserver l'architecture et les évolutions dans un seul projet.
Ils ne sont pas exécutés comme serveur dans l'APK : un déploiement backend sécurisé reste nécessaire pour les vrais flux satellite, SIG, caméras, drones, paiements, authentification et données opérationnelles.

## Principe
L'application ne présente pas les données de démonstration comme des flux réels. Les connexions production doivent être ajoutées côté serveur sécurisé.


### V158
- Enrichissement territorial par WFS UGEO.
- Observation cartographique → événement → validation humaine.
- Météo contextuelle.
- Opacité des couches.
- Amélioration avatar et limites explicites de la vision.


## V165 — Vision IA locale embarquée
- Analyse réelle des captures caméra directement sur Android avec ML Kit groupé dans l'APK.
- Modèles embarqués utilisables hors connexion après installation.
- Étiquettes avec score de confiance et détection d'objets avec boîtes lorsque le moteur les fournit.
- Résultats géolocalisés et ajoutés à la file de synchronisation des patrouilles.
- Annonce vocale uniquement pour les signaux dépassant le seuil de confiance, avec validation humaine recommandée.
- Les fonctions spécialisées (feu, fumée, arbre tombé, braconnage, etc.) restent réservées à un futur modèle entraîné pour le terrain.

## V166 — Carte territoriale GABON 360 comme carte de référence
- Remplacement du fond OSM/Esri/OpenTopoMap par la couche territoriale GABON 360 déjà utilisée par le projet.
- La carte de référence combine dans une même couche les provinces, départements, hydrographie, aires protégées, routes et localités disponibles dans le SIG existant.
- Suppression des téléchargements de tuiles cartographiques externes.
- Le bouton de préparation cartographique recentre désormais le territoire national au lieu de télécharger une nouvelle carte.
- Le mode hors connexion ne prétend plus disposer d'une carte externe téléchargée automatiquement.
- Limites cartographiques du territoire ajoutées pour éviter une dérive visuelle hors Gabon.
- V166: versionCode 298.

## V175 — Centre central opérationnel
- Tableau de contrôle web `/center`.
- Identification persistante de l'appareil dans synchronisation et heartbeat.
- Version centrale 175.0.
- État appareils et présence centralisés.
- Authentification Bearer côté API.

## V175 — Centre central opérationnel
- Tableau de contrôle web `/center`.
- Identification persistante de l'appareil dans synchronisation et heartbeat.
- Version centrale 175.0.
- État appareils et présence centralisés.
- Authentification Bearer côté API.


## V176 — Centre national de situation
- Tableau central enrichi et auto-actualisé.
- Résumé opérationnel national : appareils, connectivité, événements, alertes ouvertes, missions actives, patrouilles.
- API summary/audit/device.
- Déduplication serveur des enregistrements.
- Traçabilité par appareil et audit des synchronisations.


### V177 — Command Grid
- grille de situation centrale renforcée
- fraîcheur des appareils et statut en ligne calculé côté serveur
- flux géolocalisé `/api/v1/geo`
- mise à jour auditée des enregistrements
- accusés de réception de synchronisation exploités côté client
- observations de patrouille normalisées côté serveur


## V178 — Strategic Command
- Centre serveur version 178.
- Endpoint /api/v1/situation pour fusion descriptive des signaux, alertes prioritaires et zones de concentration.
- Principe explicite : validation humaine et aucune décision coercitive automatique.
- Client version 178, clé de synchronisation dédiée.


## V179 — Digital Twin territorial
- `/api/v1/digital-twin` : état territorial opérationnel descriptif, couches, positions et compteurs.
- `/api/v1/timeline` : chronologie centrale des événements/alertes/missions/patrouilles.
- Version Android 179.0-digital-twin / serveur GABON360-CENTER/179.
- Aucune information territoriale n’est inventée ; les décisions sensibles restent soumises à validation humaine.


## V180 — Intelligence spatiale explicable
- Moteur de raisonnement opérationnel local + serveur.
- Corrélation alertes/événements/patrouilles/missions.
- Score de confiance explicable et priorité descriptive.
- Action proposée avec validation humaine obligatoire.
- Endpoint `/api/v1/ai/status` et `/api/v1/ai/analyze`.
- Aucun verdict automatique ni décision coercitive.
- Fallback local lorsque le centre serveur est indisponible.


## V181 — Intelligence nationale spatiale
- Regroupement spatio-temporel des signaux géolocalisés.
- Diversité des sources/appareils, priorités et validation humaine prises en compte.
- API `/api/v1/ai/situation` et `/api/v1/ai/explain`.
- Zones analytiques explicitement distinctes des frontières administratives.
- Score de confiance présenté comme aide à la décision, jamais comme probabilité ou preuve.
- Version Android 181.0-national-ai-engine.


## V182 — Commandes vérifiées + conversation vocale avec consentement
- Correction des boutons de navigation terrain manquants : destination, démarrage/arrêt, GPS, boussole, point de trace, export et synchronisation hors connexion.
- Mode conversation vocale explicite : activation volontaire, indicateur visible, aucune conservation audio par l’application, transcription uniquement pour interaction IA.
- Permissions Android audio/localisation/caméra conservées avec retours de permission.
- L’écoute cachée ou l’enregistrement des conversations de tiers n’est pas implémenté.
