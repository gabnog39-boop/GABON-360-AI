const parks=['Akanda','Birougou','Ivindo','Loango','Lopé','Mayumba','Minkébé','Monts de Cristal','Moukalaba-Doudou','Mwagna','Pongara','Waka','Plateaux Batéké'];
const provinces=['Estuaire','Haut-Ogooué','Moyen-Ogooué','Ngounié','Nyanga','Ogooué-Ivindo','Ogooué-Lolo','Ogooué-Maritime','Woleu-Ntem'];
const modules=[['dashboard','🏠 Centre'],['sources','🛰️ Sources'],['alerts','🚨 Alertes'],['events','📋 Événements'],['history','🕒 Historique'],['mapmod','🗺️ SIG'],['missions','🧭 Missions'],['logistics','📦 Logistique'],['reports','📑 Rapports'],['vision','📹 VISION'],['owner','🔐 OWNER'],['settings','⚙️ Paramètres']];
const steps=['Observation','Corrélation multisource','Création événement','Priorisation','Position sur carte','Alerte avatar','Validation humaine','Audit'];
const WMS='https://ugeo.univga.com/geoserver/wms';
const state=JSON.parse(localStorage.getItem('g360_v171')||localStorage.getItem('g360_v169')||'null')||{events:[],alerts:[],missions:[],audit:[],sources:[{name:'Carte territoriale GABON 360',type:'CARTOGRAPHIE NATIVE',state:'SOURCE PRINCIPALE'},{name:'Moteur SIG territorial GABON 360',type:'SIG',state:'OPÉRATIONNEL'},{name:'Satellite',type:'SATELLITE',state:'OPTIONNEL'},{name:'Météo',type:'WEATHER',state:'PRÊT'},{name:'Drones autorisés',type:'DRONE',state:'PRÊT'},{name:'Caméras autorisées',type:'CAMERA',state:'PRÊT'}],service:true,settings:{notif:true,anim:true}};
let map,gabon360Base,adminLayer,deptLayer,roadsLayer,waterLayer,parksLayer,placesLayer,eventsLayer,searchMarker,positionMarker;
function save(){localStorage.setItem('g360_v171',JSON.stringify(state));renderAll()} function stamp(){return new Date().toLocaleString('fr-FR')} function audit(action,detail=''){state.audit.unshift({at:stamp(),action,detail});state.audit=state.audit.slice(0,200)}
function toast(t){const x=document.getElementById('toast');x.textContent=t;x.style.display='block';clearTimeout(window.__toast);window.__toast=setTimeout(()=>x.style.display='none',2400)}
function go(id){document.querySelectorAll('.panel').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.id===id));window.scrollTo({top:0,behavior:'smooth'})}
function buildTabs(){document.getElementById('tabs').innerHTML=modules.map(([id,n],i)=>`<button class="tab ${i===0?'active':''}" data-id="${id}" onclick="go('${id}')">${n}</button>`).join('')}
function renderSteps(done=[]){document.getElementById('steps').innerHTML=steps.map((s,i)=>`<div class="item">${done.includes(i)?'✅':'⬜'} <b>${i+1}. ${s}</b></div>`).join('')}
function renderAll(){document.getElementById('kEvents').textContent=state.events.length;document.getElementById('kAlerts').textContent=state.alerts.filter(a=>a.status==='OUVERTE').length;document.getElementById('kMissions').textContent=state.missions.filter(m=>m.status!=='TERMINÉE').length;document.getElementById('kSources').textContent=state.sources.length;document.getElementById('kFeatures').textContent=mapFeatureCount();document.getElementById('serviceState').textContent=state.service?'ACTIF':'SUSPENDU';document.getElementById('status').textContent=state.service?'● Système prêt':'● Service suspendu';document.getElementById('sourcesList').innerHTML=state.sources.map(s=>`<div class="item"><b>${s.name}</b> <span class="badge">${s.type}</span> <span class="badge">${s.state}</span><div class="meta">Dernière vérification : ${s.checkedAt||'à l\'initialisation'}</div></div>`).join('');document.getElementById('eventsList').innerHTML=state.events.map(e=>`<div class="item"><b>#${e.id} · ${e.title}</b><div class="meta">${e.zone} · ${e.time} · priorité ${e.priority}</div><p>${e.status==='A_VERIFIER'?'Validation humaine requise.':'Statut : '+e.status}</p>${e.status==='A_VERIFIER'?`<button class="btn ok" onclick="validateEvent(${e.id},'CONFIRMÉ')">Confirmer</button><button class="btn alt" onclick="validateEvent(${e.id},'ÉCARTÉ')">Écarter</button>`:''}</div>`).join('')||'<div class="item">Aucun événement.</div>';document.getElementById('alertsList').innerHTML=state.alerts.map(a=>`<div class="item"><b>🚨 ${a.title}</b> <span class="badge dangerTxt">${a.priority}</span><div class="meta">${a.time} · source ${a.source}</div><p>${a.status}</p>${a.status==='OUVERTE'?`<button class="btn ok" onclick="ackAlert(${a.id})">Prendre en compte</button>`:''}</div>`).join('')||'<div class="item">Aucune alerte ouverte.</div>';document.getElementById('missionsList').innerHTML=state.missions.map(m=>`<div class="item"><b>🧭 ${m.title}</b><div class="meta">${m.time} · ${m.status}</div>${m.status!=='TERMINÉE'?`<button class="btn ok" onclick="finishMission(${m.id})">Terminer</button>`:''}</div>`).join('')||'<div class="item">Aucune mission.</div>';document.getElementById('audit').textContent=state.audit.map(a=>`${a.at}  ${a.action}  ${a.detail}`).join('\n')||'Aucune entrée.';document.getElementById('miniAudit').textContent=state.audit.slice(0,8).map(a=>`${a.at}  ${a.action}`).join('\n')||'Aucune opération.';document.getElementById('parks').innerHTML=parks.map((p,i)=>`<div class="item"><b>🇬🇦 ${p}</b><div class="meta">Couche parc · PN-${String(i+1).padStart(2,'0')}</div></div>`).join('');document.getElementById('provinces').innerHTML=provinces.map(p=>`<div class="item"><b>${p}</b><div class="meta">Couche administrative</div></div>`).join('');document.getElementById('layers').innerHTML=['Provinces','Départements','Routes','Rivières','Localités','Parcs'].map(x=>`<button class="btn alt" onclick="layer('${x}')">${x}</button>`).join('');document.getElementById('notif').checked=state.settings.notif;document.getElementById('anim').checked=state.settings.anim;document.getElementById('avatar').classList.toggle('live',state.settings.anim);syncEventMarkers()}
const GABON360_TERRITORY={name:'Gabon',bbox:[[-3.98,8.65],[2.35,14.6]],provinces:provinces.length,parks:parks.length,source:'GABON 360 · couche territoriale canonique',externalBasemap:false};
function territorySearch(q){const needle=String(q||'').trim().toLowerCase();if(!needle)return null;const names=[...parks,...provinces,'Gabon','Libreville','Port-Gentil','Franceville','Oyem','Lambaréné','Mouila','Makokou','Tchibanga','Koulamoutou','Lastoursville','Bitam','Moanda'];const hit=names.find(x=>x.toLowerCase().includes(needle)||needle.includes(x.toLowerCase()));return hit||null}
function initMap(){map=L.map('map',{zoomControl:true,preferCanvas:true,worldCopyJump:false,maxBounds:[[-5.2,6.8],[3.4,16.2]],maxBoundsViscosity:.8}).setView([-0.72,11.55],6);
  gabon360Base=L.tileLayer.wms(WMS,{layers:'geonode:gadm41_GAB_1,geonode:gadm41_GAB_2,geonode:gis_osm_water_a_free_1,geonode:gis_osm_waterways_free_1,geonode:gis_osm_protected_areas_a_free_1,geonode:gis_osm_roads_free_1,geonode:gis_osm_places_free_1',format:'image/png',transparent:false,opacity:.96,version:'1.1.1',attribution:'GABON 360 · couche territoriale'}).addTo(map);
  adminLayer=L.tileLayer.wms(WMS,{layers:'geonode:gadm41_GAB_1',format:'image/png',transparent:true,opacity:.72,attribution:'GABON 360'});deptLayer=L.tileLayer.wms(WMS,{layers:'geonode:gadm41_GAB_2',format:'image/png',transparent:true,opacity:.48,attribution:'GABON 360'});roadsLayer=L.tileLayer.wms(WMS,{layers:'geonode:gis_osm_roads_free_1',format:'image/png',transparent:true,opacity:.82,attribution:'GABON 360'});waterLayer=L.tileLayer.wms(WMS,{layers:'geonode:gis_osm_waterways_free_1,geonode:gis_osm_water_a_free_1',format:'image/png',transparent:true,opacity:.82,attribution:'GABON 360'});parksLayer=L.tileLayer.wms(WMS,{layers:'geonode:gis_osm_protected_areas_a_free_1',format:'image/png',transparent:true,opacity:.62,attribution:'GABON 360'});placesLayer=L.tileLayer.wms(WMS,{layers:'geonode:gis_osm_places_free_1',format:'image/png',transparent:true,opacity:.92,attribution:'GABON 360'});eventsLayer=L.layerGroup().addTo(map);L.control.layers({'Carte territoriale GABON 360':gabon360Base},{'Provinces':adminLayer,'Départements':deptLayer,'Routes':roadsLayer,'Rivières/Lacs':waterLayer,'Parcs protégés':parksLayer,'Villes/localités':placesLayer,'Événements':eventsLayer},{collapsed:false}).addTo(map);map.on('click',e=>interpretPosition(e.latlng.lat,e.latlng.lng));loadSigLayers();}
function mapFeatureCount(){return (adminLayer&&map.hasLayer(adminLayer)?1:0)+(deptLayer&&map.hasLayer(deptLayer)?1:0)+(roadsLayer&&map.hasLayer(roadsLayer)?1:0)+(waterLayer&&map.hasLayer(waterLayer)?1:0)+(parksLayer&&map.hasLayer(parksLayer)?1:0)+(placesLayer&&map.hasLayer(placesLayer)?1:0)+state.events.length}
function loadSigLayers(){[adminLayer,deptLayer,roadsLayer,waterLayer,parksLayer,placesLayer].forEach(x=>{if(x&&map&& !map.hasLayer(x))x.addTo(map)});document.getElementById('layerState').textContent='Carte territoriale GABON 360 · provinces · départements · routes · hydrographie · parcs · localités';audit('SIG_CHARGÉ','carte territoriale canonique GABON 360');save();toast('Carte territoriale GABON 360 chargée')}
function zoomGabon(){map.fitBounds([[-3.98,8.65],[2.35,14.6]]);audit('CARTE_RECENTRÉE','Gabon');save()}
function toggleSatellite(){toast('La carte territoriale GABON 360 reste le fond de référence. Aucun autre fond cartographique ne sera téléchargé.');if(gabon360Base){gabon360Base.setOpacity(.96);if(!map.hasLayer(gabon360Base))gabon360Base.addTo(map)}audit('CARTE_GABON360','fond canonique conservé');save()}
function layer(x){const m={'Provinces':adminLayer,'Départements':deptLayer,'Routes':roadsLayer,'Rivières':waterLayer,'Localités':placesLayer,'Parcs':parksLayer};const l=m[x];if(l){if(map.hasLayer(l))map.removeLayer(l);else l.addTo(map);document.getElementById('layerState').textContent='Couche '+x+' '+(map.hasLayer(l)?'activée':'masquée');}audit('COUCHE_SIG',x);save()}
async function interpretPosition(lat,lon){
 document.getElementById('mapCoords').textContent=`Position ${lat.toFixed(5)}, ${lon.toFixed(5)} · interprétation par le moteur territorial GABON 360`;
 document.getElementById('mapContext').textContent='Territoire national · analyse des couches GABON 360';
 const inside=lat>=GABON360_TERRITORY.bbox[0][0]&&lat<=GABON360_TERRITORY.bbox[1][0]&&lon>=GABON360_TERRITORY.bbox[0][1]&&lon<=GABON360_TERRITORY.bbox[1][1];
 const ctx=inside?'Gabon · carte territoriale GABON 360':'Hors emprise cartographique nationale';
 const visible=[];[[adminLayer,'provinces'],[deptLayer,'départements'],[roadsLayer,'routes'],[waterLayer,'hydrographie'],[parksLayer,'aires protégées'],[placesLayer,'localités']].forEach(([l,n])=>{if(l&&map.hasLayer(l))visible.push(n)});
 document.getElementById('mapContext').textContent=ctx+' · couches actives : '+(visible.join(', ')||'aucune');
 document.getElementById('mapCoords').textContent=`${lat.toFixed(5)}, ${lon.toFixed(5)} · source : GABON 360`;
 L.popup().setLatLng([lat,lon]).setContent(`<b>GABON 360 AI · Moteur territorial</b><br>${ctx}<br><small>Coordonnées : ${lat.toFixed(5)}, ${lon.toFixed(5)}</small><br><small>Couches actives : ${visible.join(', ')||'aucune'}</small><br><small>La carte de référence reste la carte territoriale GABON 360.</small>`).openOn(map);
 audit('INTERPRÉTATION_POSITION',`${lat.toFixed(5)},${lon.toFixed(5)} · ${ctx}`);save();
}
function addDemoEvent(){const id=Date.now(),lat=-0.72+(Math.random()-.5)*2.1,lon=11.55+(Math.random()-.5)*3.8;state.events.unshift({id,title:'Anomalie territoriale à vérifier',zone:'Gabon · position simulée',time:stamp(),priority:'HAUTE',status:'A_VERIFIER',lat,lon,source:'SIMULATION'});state.alerts.unshift({id:id+1,title:'Nouvelle anomalie à vérifier',priority:'HAUTE',time:stamp(),source:'corrélation locale',status:'OUVERTE',lat,lon});audit('ÉVÉNEMENT_CRÉÉ','#'+id+' @ '+lat.toFixed(4)+','+lon.toFixed(4));save();map.setView([lat,lon],9);speakText('Une anomalie de démonstration a été positionnée sur la carte. Validation humaine requise.')}
function validateEvent(id,status){const e=state.events.find(x=>x.id===id);if(!e)return;e.status=status;audit('VALIDATION_HUMAINE','#'+id+' '+status);save();speakText(status==='CONFIRMÉ'?'Événement confirmé après validation humaine.':'Événement écarté après validation humaine.')}
function ackAlert(id){const a=state.alerts.find(x=>x.id===id);if(!a)return;a.status='PRISE_EN_COMPTE';audit('ALERTE_PRISE_EN_COMPTE','#'+id);save();toast('Alerte prise en compte')}
function newMission(){createLogisticsMission()}
function finishMission(id){const m=state.missions.find(x=>x.id===id);if(m){m.status='TERMINÉE';audit('MISSION_TERMINÉE','#'+id);save()}}
const LOGISTICS_KEY='g360_logistics_v171';
let logistics=JSON.parse(localStorage.getItem(LOGISTICS_KEY)||'null')||{fuel:100,water:100,battery:100,food:100,medical:100,vehicles:1,team:1,equipment:[],notes:'',lastCheck:null};
function saveLogistics(){localStorage.setItem(LOGISTICS_KEY,JSON.stringify(logistics));renderLogistics()}
function renderLogistics(){
 const ids=['logFuel','logWater','logBattery','logFood','logMedical','logVehicles','logTeam','logNotes','logLastCheck'];
 const vals=[logistics.fuel+'%',logistics.water+'%',logistics.battery+'%',logistics.food+'%',logistics.medical+'%',logistics.vehicles,logistics.team,logistics.notes||'Aucune note',logistics.lastCheck||'Jamais'];
 ids.forEach((id,i)=>{const e=document.getElementById(id);if(e)e.textContent=vals[i]});
 const readiness=logistics.fuel>=30&&logistics.water>=30&&logistics.battery>=40&&logistics.food>=30&&logistics.medical>=30&&logistics.vehicles>0&&logistics.team>0;
 const e=document.getElementById('logReadiness');if(e){e.textContent=readiness?'PRÊTE':'À PRÉPARER';e.className=readiness?'badge':'badge dangerTxt'}
}
function updateLogistics(){
 const n=id=>Number(document.getElementById(id)?.value||0);
 logistics.fuel=Math.max(0,Math.min(100,n('fuelInput'))); logistics.water=Math.max(0,Math.min(100,n('waterInput'))); logistics.battery=Math.max(0,Math.min(100,n('batteryInput'))); logistics.food=Math.max(0,Math.min(100,n('foodInput'))); logistics.medical=Math.max(0,Math.min(100,n('medicalInput'))); logistics.vehicles=Math.max(0,n('vehiclesInput')); logistics.team=Math.max(0,n('teamInput')); logistics.notes=(document.getElementById('logNotesInput')?.value||'').trim(); logistics.lastCheck=stamp(); audit('CONTROLE_LOGISTIQUE',`carburant ${logistics.fuel}% · eau ${logistics.water}% · batterie ${logistics.battery}% · équipe ${logistics.team}`); saveLogistics(); toast('Contrôle logistique enregistré');
}
function prepareMissionLogistics(){
 const checks=[['Carburant',logistics.fuel,30],['Eau',logistics.water,30],['Batterie',logistics.battery,40],['Vivres',logistics.food,30],['Médical',logistics.medical,30],['Véhicule',logistics.vehicles,1],['Équipe',logistics.team,1]];
 const missing=checks.filter(x=>x[1]<x[2]).map(x=>x[0]);
 const status=missing.length?'À PRÉPARER':'PRÊTE'; audit('PRÉPARATION_MISSION',status+(missing.length?' · manque: '+missing.join(', '):''));
 const e=document.getElementById('logPlan');if(e)e.innerHTML=`<div class="item"><b>🧭 Préparation opérationnelle : ${status}</b><div class="meta">${missing.length?'Éléments à compléter : '+esc(missing.join(', ')):'Ressources minimales disponibles.'}</div><p>Dernier contrôle : ${logistics.lastCheck||'non effectué'}</p></div>`; toast(missing.length?'Mission à préparer.':'Ressources minimales prêtes.');
}
function createLogisticsMission(){
 const id=Date.now(); const readiness=logistics.fuel>=30&&logistics.water>=30&&logistics.battery>=40&&logistics.food>=30&&logistics.medical>=30&&logistics.vehicles>0&&logistics.team>0;
 state.missions.unshift({id,title:'Mission terrain '+id.toString().slice(-4),time:stamp(),status:readiness?'PLANIFIÉE':'À PRÉPARER',logistics:{...logistics}}); audit('MISSION_CRÉÉE','#'+id+' · logistique '+(readiness?'OK':'À PRÉPARER')); save(); toast(readiness?'Mission créée et prête à planifier.':'Mission créée avec préparation logistique requise.');
}

function runScenario(){let i=0;renderSteps([]);const timer=setInterval(()=>{renderSteps(Array.from({length:i+1},(_,x)=>x));document.getElementById('prog').style.width=((i+1)/steps.length*100)+'%';i++;if(i===steps.length){clearInterval(timer);addDemoEvent();audit('SCÉNARIO_COMPLET','8 étapes exécutées');save();}},350)}
function resetScenario(){renderSteps([]);document.getElementById('prog').style.width='0%';toast('Scénario réinitialisé')}
function refreshSources(){state.sources.forEach(s=>s.checkedAt=stamp());audit('SOURCES_ACTUALISÉES',state.sources.length+' sources');save();toast('Sources actualisées')}
function locate(){if(window.G360)G360.getLocation();else toast('Position native indisponible')}
window.onNativeLocation=(lat,lon,acc)=>{audit('POSITION_GPS',lat.toFixed(5)+','+lon.toFixed(5)+' ±'+Math.round(acc)+'m');save();if(map){map.setView([lat,lon],15);L.circleMarker([lat,lon],{radius:9,color:'#69bfff',fillOpacity:.9}).addTo(eventsLayer).bindPopup('Position du téléphone · précision ±'+Math.round(acc)+' m').openPopup();interpretPosition(lat,lon)}};
window.onNativeLocationError=m=>toast(m);
function speakText(t){document.getElementById('speech').textContent=t;const av=document.getElementById('avatar'),p=document.getElementById('avatarPulse');av.classList.add('speaking');p.textContent='● EN TRAIN DE PARLER';if(window.G360)G360.speak(t);else if('speechSynthesis'in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='fr-FR';u.onend=()=>{av.classList.remove('speaking');p.textContent='● EN VEILLE'};speechSynthesis.speak(u)}setTimeout(()=>{av.classList.remove('speaking');p.textContent='● EN VEILLE'},Math.max(2500,t.length*55))}
function speak(){speakText(document.getElementById('speech').textContent)} function stopVoice(){if(window.G360)G360.stopSpeak();if('speechSynthesis'in window)speechSynthesis.cancel();document.getElementById('avatar').classList.remove('speaking');document.getElementById('avatarPulse').textContent='● EN VEILLE'}
function voice(){if(window.G360){document.getElementById('voiceState').textContent='● Écoute…';G360.startVoice()}else document.getElementById('voiceState').textContent='Micro natif indisponible'}
window.onNativeVoice=text=>{document.getElementById('voiceState').textContent='Commande : '+text;document.getElementById('cmd').value=text;if(typeof handleConversationTranscript==='function')handleConversationTranscript(text);else command(text)};window.onNativeVoiceState=s=>document.getElementById('voiceState').textContent=s;window.onNativeVoiceError=s=>document.getElementById('voiceState').textContent=s;
function command(text){const c=(text||document.getElementById('cmd').value).trim().toLowerCase();if(!c)return;if(c.includes('carte')||c.includes('sig')||c.includes('territoire')){go('dashboard');zoomGabon();speakText('J’ouvre la carte territoriale et je recentre le Gabon.')}else if(c.includes('alerte')){go('alerts');speakText('J’ouvre les alertes.')}else if(c.includes('source')){go('sources');speakText('J’ouvre les sources.')}else if(c.includes('mission')){go('missions');speakText('J’ouvre les missions.')}else if(c.includes('rapport')){go('reports');speakText('J’ouvre les rapports.')}else if(c.includes('caméra')||c.includes('camera')){go('vision');speakText('J’ouvre VISION.')}else if(c.includes('position')||c.includes('gps')){locate();speakText('Je demande la position du téléphone.')}else if(c.includes('suspend')){go('owner');speakText('Le contrôle OWNER est ouvert.')}else if(c.includes('test')||c.includes('scénario')){go('dashboard');runScenario();speakText('Je lance la corrélation de test.')}else{speakText('Commande reçue : '+text+'. Les actions disponibles sont carte, alertes, sources, missions, rapports, caméra, position et scénario.')}}
function exportReport(){const r={generated_at:stamp(),version:'181.0-national-ai-engine',events:state.events,alerts:state.alerts,missions:state.missions,sources:state.sources,audit:state.audit,cartography:{provider:'GABON 360 / couche territoriale',layers:['provinces','roads','waterways','protected_areas','places']}};const text=JSON.stringify(r,null,2);document.getElementById('reportPreview').textContent=text.slice(0,12000);if(window.G360)G360.saveReport('gabon360-rapport-'+Date.now()+'.json',text);toast('Rapport généré')}
function shareReport(){const text=JSON.stringify({generated_at:stamp(),events:state.events,alerts:state.alerts,missions:state.missions},null,2);if(window.G360)G360.share(text);else if(navigator.clipboard)navigator.clipboard.writeText(text);toast('Rapport préparé')}
function camera(){if(window.G360)G360.camera();else toast('Caméra native indisponible')}
window.onNativeCamera=data=>{if(data){document.getElementById('cameraPreview').innerHTML='<img style="width:100%;border-radius:12px;margin:8px 0" src="'+data+'"><div class="note">Capture locale · non transmise à un serveur.</div>';audit('CAPTURE_CAMERA','capture locale');save()}else toast('Capture annulée')};
function toggleService(){state.service=!state.service;audit('OWNER_SERVICE_CONTROL',state.service?'REACTIVÉ':'SUSPENDU');save();speakText(state.service?'Service local réactivé.':'Service local suspendu.')}
function ownerAudit(){go('history');speakText('Ouverture de l’audit OWNER.')}
function saveSettings(){state.settings.notif=document.getElementById('notif').checked;state.settings.anim=document.getElementById('anim').checked;audit('PARAMÈTRES','mis à jour');save()}
function clearHistory(){state.audit=[];save();toast('Historique local effacé')} function resetApp(){localStorage.removeItem('g360_v169');location.reload()}
// V165 — Vision IA locale embarquée : analyse d'image sur le téléphone
const VISION_KEY='g360_vision_v165';
let visionState=JSON.parse(localStorage.getItem(VISION_KEY)||'null')||{captures:[],last:null,engine:'ML Kit local'};
function saveVision(){localStorage.setItem(VISION_KEY,JSON.stringify(visionState));renderVision()}
function renderVision(){
 const st=document.getElementById('visionState');if(st)st.textContent=visionState.last?('Dernière analyse : '+(visionState.last.kind||'capture')):'Aucune analyse';
 const vg=document.getElementById('visionGPS');if(vg)vg.textContent=fieldNav.lat?fmtNum(fieldNav.lat,5)+', '+fmtNum(fieldNav.lon,5):'—';
 const vl=document.getElementById('visionLink');if(vl)vl.textContent=navigator.onLine?'EN LIGNE':'HORS LIGNE';
 const feed=document.getElementById('visionFeed');if(feed)feed.innerHTML=(visionState.captures||[]).slice(0,10).map(x=>{const ai=x.ai||{};const labs=(ai.labels||[]).slice(0,6).map(l=>`${l.text} (${Math.round((l.confidence||0)*100)}%)`).join(' · ');const objs=(ai.objects||[]).length;return `<div class="item"><b>🧠 ${x.kind||'VISION'}</b> <span class="badge">${x.confidence||'À confirmer'}</span><div class="meta">${x.time||''} · ${x.lat!=null?x.lat.toFixed(5)+', '+x.lon.toFixed(5):'position inconnue'} · ${x.link||'LOCAL'}</div><div>${labs||'Aucun libellé au-dessus du seuil.'}${objs?` · ${objs} objet(s) localisé(s)`:''}</div><div class="meta">Moteur : ${ai.engine||visionState.engine||'IA locale'} · ${ai.offlineCapable?'hors connexion après installation du modèle':'modèle non confirmé'}</div><div>${x.note||''}</div></div>`}).join('')||'<div class="item">Aucune analyse caméra.</div>';
}
function saveVisionAnalysis(result){
 let ai={};try{ai=typeof result==='string'?JSON.parse(result):result||{}}catch(e){ai={status:'ERREUR'} }
 const now=new Date().toISOString();const labels=ai.labels||[];const objects=ai.objects||[];
 const high=labels.filter(x=>(x.confidence||0)>=0.70);
 const kinds=high.map(x=>String(x.text||'').toLowerCase());
 let kind='ANALYSE TERRAIN';
 if(kinds.some(x=>x.includes('person')||x.includes('human')||x.includes('people')))kind='PRÉSENCE HUMAINE · À VÉRIFIER';
 else if(kinds.some(x=>x.includes('animal')||x.includes('mammal')||x.includes('bird')))kind='ANIMAL · À VÉRIFIER';
 else if(kinds.some(x=>x.includes('vehicle')||x.includes('car')||x.includes('truck')))kind='VÉHICULE · À VÉRIFIER';
 else if(kinds.some(x=>x.includes('plant')||x.includes('tree')||x.includes('forest')))kind='VÉGÉTATION';
 const obs={id:'V165-'+Date.now(),kind,time:now,lat:fieldNav.lat,lon:fieldNav.lon,accuracy:fieldNav.accuracy,confidence:high.length?('CONFIANCE ≥ 70% · '+high.length+' signal(s)'):'FAIBLE / À VÉRIFIER',link:navigator.onLine?'CONNEXION DISPONIBLE':'HORS CONNEXION',ai,note:'Analyse automatique locale. Les résultats sont des indications et ne constituent pas une identification certaine.'};
 visionState.last=obs;visionState.captures.unshift(obs);visionState.captures=visionState.captures.slice(0,50);saveVision();queueOffline('VISION_AI_ANALYSIS',obs);addPatrolObservation('VISION IA',kind,{source:'IA_LOCALE_ML_KIT',confidence:obs.confidence,ai});audit('VISION_AI_ANALYSIS',obs.id);save();
 if(high.length){const speech='Analyse locale terminée. '+high.slice(0,3).map(x=>x.text+' à '+Math.round(x.confidence*100)+' pour cent').join(', ')+'. Vérification humaine recommandée.';speakText(speech);toast('IA locale : '+high.length+' signal(s)');}else toast('IA locale : aucun signal fort');
}
function onNativeVisionStatus(msg){const el=document.getElementById('visionAIStatus');if(el)el.textContent=msg||'Analyse locale';}
function onNativeVisionResult(result){onNativeVisionStatus('Analyse locale terminée');saveVisionAnalysis(result)}
function onNativeVisionError(msg){onNativeVisionStatus(msg||'Erreur du moteur IA local');toast(msg||'Erreur vision IA')}
function analyzeTerrainCapture(data){if(!data)return;onNativeVisionStatus('L’analyse IA est lancée automatiquement par le téléphone.');toast('Analyse IA locale en cours…')}
function cameraForPatrol(){go('vision');if(window.G360)G360.camera();else toast('Caméra native indisponible')}
function announceVisionLimit(){speakText('La caméra utilise maintenant une analyse IA locale embarquée. Les résultats sont indicatifs et doivent être vérifiés par le patrouilleur. Les détections spécialisées comme feu, fumée, arbre tombé ou braconnage nécessitent un modèle entraîné spécifiquement pour ces cas.')}
function createManualVisionObservation(){
 const types=['Obstacle','Animal','Personne','Véhicule','Arbre ou chute','Trace ou indice','Dégradation','Autre'];const choice=prompt('Type d’observation :\n'+types.map((x,i)=>(i+1)+'. '+x).join('\n'),'1');const idx=Number(choice)-1;if(idx<0||idx>=types.length)return;
 const note=prompt('Décrivez ce que vous observez :','Observation terrain')||'';const now=new Date().toISOString();const o={id:'OBS-'+Date.now(),kind:types[idx],time:now,lat:fieldNav.lat,lon:fieldNav.lon,accuracy:fieldNav.accuracy,note,confidence:'CONFIRMÉE PAR PATROUILLEUR',link:navigator.onLine?'CONNEXION DISPONIBLE':'HORS CONNEXION'};
 visionState.last=o;visionState.captures.unshift(o);visionState.captures=visionState.captures.slice(0,50);saveVision();queueOffline('OBSERVATION_VISION',o);addPatrolObservation(types[idx],note,{source:'OBSERVATION_TERRAIN',lat:o.lat,lon:o.lon});speakText(types[idx]+' enregistré à la position actuelle.');audit('OBSERVATION_VISION',types[idx]);save();
}
function onVisionCapture(data){if(!data){toast('Capture annulée');return}const box=document.getElementById('cameraPreview');if(box)box.innerHTML='<img style="width:100%;border-radius:12px;margin:8px 0" src="'+data+'"><div class="note">Capture locale · analyse IA embarquée en cours.</div><div class="row"><button class="btn alt" onclick="createManualVisionObservation()">＋ Observation terrain</button></div>';audit('CAPTURE_CAMERA','capture locale V165');renderVision()}
window.onNativeCamera=onVisionCapture;

async function runNationalAI(){
 const base=(infraState?.backendUrl||'').replace(/\/$/,''); let x=null;
 if(base&&fieldLink?.online){try{const h={};if(syncState?.token)h.Authorization='Bearer '+syncState.token;const r=await fetch(base+'/api/v1/ai/situation?hours=24&radius_km=15',{headers:h,cache:'no-store'});if(r.ok)x=await r.json()}catch(e){}}
 const box=document.getElementById('nationalAI'); if(!box)return;
 if(!x){box.innerHTML='<div class="item">Serveur IA indisponible. Configure la passerelle pour lancer l’analyse nationale.</div>';toast('IA nationale : serveur indisponible');return;}
 const zones=x.zones||[]; box.innerHTML=(zones.length?zones.slice(0,8).map(z=>`<div class="item"><b>🧠 ${z.cluster_id} · priorité ${z.priority}</b><div class="meta">${z.signals} signal(s) · ${z.sources.join(', ')} · ${z.devices} source(s)/appareil(s) · confiance ${Math.round(z.confidence*100)}%</div><div>${z.recommended_action}</div><div class="meta">Centre : ${Number(z.centroid.lat).toFixed(5)}, ${Number(z.centroid.lon).toFixed(5)} · rayon analytique ${z.radius_km} km</div></div>`).join(''):'<div class="item">Aucun regroupement géolocalisé récent.</div>')+`<div class="meta">${x.signals_total||0} signal(s) analysé(s) · fenêtre ${x.window_hours||24} h · ${x.principles?.join(' · ')||''}</div>`;
 audit('AI_NATIONAL_SITUATION',`${zones.length} zone(s) · ${x.signals_total||0} signal(s)`); speakText('Analyse nationale terminée. Les zones sont des regroupements analytiques et nécessitent une validation humaine.');
}

buildTabs();renderSteps([]);renderAll();initMap();speakText('Bonjour. GABON 360 AI V169 est prêt. Le centre territorial est en ligne.');

function searchPlace(){const q=(document.getElementById('mapSearch')?.value||'').trim();if(!q)return toast('Entrez une ville, localité, parc ou province');const hit=territorySearch(q);if(!hit){toast('Lieu non trouvé dans le registre local GABON 360');return}if(searchMarker)map.removeLayer(searchMarker);const center=map.getCenter();searchMarker=L.marker(center).addTo(map).bindPopup(`<b>${hit}</b><br>Référentiel territorial GABON 360 · utilisez les couches pour localiser précisément.`).openPopup();map.setView(center,Math.max(map.getZoom(),8));document.getElementById('mapContext').textContent=`Référentiel local : ${hit} · GABON 360`;audit('RECHERCHE_LOCALE',hit);save()}
function toggleTerrain(){toast('Le relief externe est désactivé : GABON 360 utilise uniquement sa carte territoriale.');audit('RELIEF','désactivé - aucun fond externe');}


// V160 — mode hors-ligne + liaison satellite
let fieldLink={online:navigator.onLine,satellite:false,lastCheck:null,queue:[]};
function initFieldLink(){
  try{fieldLink.queue=JSON.parse(localStorage.getItem('g360_field_queue')||'[]')}catch(e){fieldLink.queue=[]}
  window.addEventListener('online',()=>{fieldLink.online=true;refreshFieldLink();syncFieldQueue()});
  window.addEventListener('offline',()=>{fieldLink.online=false;refreshFieldLink()});
  if(window.G360&&G360.getNetworkStatus){try{const raw=G360.getNetworkStatus();const n=JSON.parse(raw);fieldLink.online=!!n.online;fieldLink.satellite=!!n.satellite;fieldLink.network=n.transport||'INCONNUE';}catch(e){}}
  refreshFieldLink();
  setInterval(refreshFieldLink,12000);
}
function refreshFieldLink(){
  if(window.G360&&G360.getNetworkStatus){try{const n=JSON.parse(G360.getNetworkStatus());fieldLink.online=!!n.online;fieldLink.satellite=!!n.satellite;fieldLink.network=n.transport||'INCONNUE';}catch(e){}}
  const mode=fieldNav.active?'TERRAIN':'STANDARD';
  const label=fieldLink.satellite?'🛰️ LIAISON SATELLITE':fieldLink.online?'🌐 CONNECTÉ':'📴 HORS LIGNE';
  const detail=fieldLink.satellite?'Réseau satellite détecté par Android. Synchronisation possible selon le matériel et le fournisseur.':fieldLink.online?'Connexion disponible. Les données critiques restent mises en file si le réseau tombe.':'Aucune connexion IP. GABON 360 AI continue localement avec GPS, carte en cache, boussole, règles terrain et alertes locales.';
  const a=document.getElementById('fieldLinkStatus'); if(a)a.textContent=label;
  const b=document.getElementById('fieldLinkDetail'); if(b)b.textContent=detail;
  const q=document.getElementById('fieldQueue'); if(q)q.textContent=fieldLink.queue.length+' élément(s) en attente';
  const s=document.getElementById('satStatus'); if(s&&fieldLink.satellite)s.textContent='🛰️ Liaison satellite détectée';
  fieldLink.lastCheck=Date.now();
}
function queueFieldData(type,payload){
  fieldLink.queue.push({id:Date.now(),type,payload,created_at:new Date().toISOString(),status:'EN_ATTENTE'});
  try{localStorage.setItem('g360_field_queue',JSON.stringify(fieldLink.queue))}catch(e){}
  refreshFieldLink();
}
function syncFieldQueue(){
  if(!fieldLink.online||!fieldLink.queue.length)return;
  // Architecture store-and-forward : l'envoi réel au serveur sera branché à l'API sécurisée.
  audit('SYNCHRONISATION','Réseau disponible : '+fieldLink.queue.length+' élément(s) prêts à être synchronisés.');
  const n=fieldLink.queue.length;
  fieldLink.queue=[];
  try{localStorage.setItem('g360_field_queue','[]')}catch(e){}
  refreshFieldLink();
  if(n)speakText(n+' donnée'+(n>1?'s':'')+' de terrain prête'+(n>1?'s':'')+' pour synchronisation.');
}
function queueCurrentObservation(){
  if(!fieldNav.lat){toast('Obtenez d’abord une position GPS');return}
  queueFieldData('POSITION_PATROUILLE',{lat:fieldNav.lat,lon:fieldNav.lon,accuracy:fieldNav.accuracy,heading:fieldNav.heading,at:new Date().toISOString()});
  audit('DONNEE_HORS_LIGNE','position mise en file');
  speakText(fieldLink.online?'Position enregistrée et prête à synchroniser.':'Aucune connexion : position enregistrée localement, synchronisation automatique dès qu’une liaison est disponible.');
}
function announceFieldSituation(){
  const parts=[];
  if(fieldNav.lat)parts.push('Position '+fieldNav.lat.toFixed(5)+' '+fieldNav.lon.toFixed(5)+', précision '+Math.round(fieldNav.accuracy||0)+' mètres.');
  if(fieldNav.destination)parts.push(document.getElementById('navInstruction')?.textContent||'Navigation active.');
  const risk=document.getElementById('fieldHazards')?.innerText||''; if(risk)parts.push(risk.replace(/\n+/g,'. '));
  parts.push(fieldLink.satellite?'Liaison satellite détectée.':fieldLink.online?'Connexion disponible.':'Mode hors ligne actif. Les informations sont conservées sur le téléphone.');
  speakText(parts.join(' '));
}


// V162 — Cartographie réellement préchargeable pour le terrain
const MAP_PACK_KEY='g360_map_pack_v162';
let mapPackState=JSON.parse(localStorage.getItem(MAP_PACK_KEY)||'null')||{name:'',lat:null,lon:null,minZoom:10,maxZoom:14,tiles:0,created:null};
function saveMapPack(){localStorage.setItem(MAP_PACK_KEY,JSON.stringify(mapPackState));renderMapPackStatus()}
function renderMapPackStatus(){const el=document.getElementById('offlineMapStatus');if(!el)return;el.textContent=mapPackState.name?`Carte territoriale GABON 360 : ${mapPackState.name||'territoire national'} · aucune tuile externe téléchargée.`:'Carte territoriale GABON 360 : aucune carte externe à télécharger.'}
function lon2tile(lon,z){return Math.floor((lon+180)/360*Math.pow(2,z))}
function lat2tile(lat,z){const r=lat*Math.PI/180;return Math.floor((1-Math.asinh(Math.tan(r))/Math.PI)/2*Math.pow(2,z))}
function tile2url(x,y,z){return null}
function tileCountForBounds(lat,lon,delta,z){const x1=lon2tile(lon-delta,z),x2=lon2tile(lon+delta,z),y1=lat2tile(lat+delta,z),y2=lat2tile(lat-delta,z);return Math.max(0,(x2-x1+1)*(y2-y1+1))}
async function cacheTile(url){return false}
async function downloadOfflineMapPack(){toast('Téléchargement de cartes externes désactivé. La carte territoriale GABON 360 est utilisée directement.');audit('CARTE_OFFLINE','aucun téléchargement externe');}
function registerOfflineTileCache(){return false}
function useOfflineMapFallback(){if(!map)return;if(!navigator.onLine){toast('Hors connexion : aucune carte externe n’est téléchargée. La carte territoriale GABON 360 reste la référence et nécessite ses données disponibles localement pour un vrai mode 100 % hors connexion.');}}
window.addEventListener('load',()=>{renderMapPackStatus()});
window.addEventListener('offline',()=>{setTimeout(useOfflineMapFallback,300)});


// V163 — Centre de situation des patrouilles + IA terrain
const PATROL_KEY='g360_patrol_v163';
let patrolState=JSON.parse(localStorage.getItem(PATROL_KEY)||'null')||{active:false,id:'PAT-LOCAL',name:'Patrouilleur',last:null,track:[],observations:[],link:'HORS_LIGNE'};
function savePatrol(){localStorage.setItem(PATROL_KEY,JSON.stringify(patrolState));renderPatrolCenter()}
function renderPatrolCenter(){
  const p=document.getElementById('patrolStatus'); if(p)p.textContent=patrolState.active?'🟢 PATROUILLE ACTIVE':'⚪ PATROUILLE INACTIVE';
  const l=document.getElementById('patrolLink'); if(l)l.textContent=fieldLink?.satellite?'🛰️ SATELLITE':fieldLink?.online?'🌐 RÉSEAU':'📴 HORS LIGNE';
  const q=document.getElementById('patrolPending'); if(q)q.textContent=(fieldLink?.queue?.length||0)+' en attente';
  const pos=document.getElementById('patrolPosition'); if(pos)pos.textContent=patrolState.last?`${patrolState.last.lat.toFixed(5)}, ${patrolState.last.lon.toFixed(5)}`:'—';
  const list=document.getElementById('patrolFeed'); if(list){const xs=patrolState.observations.slice(0,8);list.innerHTML=xs.length?xs.map(x=>`<div class="item"><b>${esc(x.type)}</b><div class="meta">${new Date(x.at).toLocaleString('fr-FR')} · ${x.lat?.toFixed?.(5)||'—'}, ${x.lon?.toFixed?.(5)||'—'}</div><div>${esc(x.detail||'Observation terrain')}</div></div>`).join(''):'<div class="item">Aucune observation transmise.</div>'}
}
function startPatrolLink(){
  patrolState.active=true; patrolState.id='PAT-'+Date.now().toString().slice(-6); patrolState.startedAt=new Date().toISOString();
  audit('PATROUILLE_ACTIVE',patrolState.id); savePatrol(); go('fieldnav'); speakText('Patrouille activée. Je surveille la position, la navigation et les anomalies locales.');
}
function stopPatrolLink(){patrolState.active=false;audit('PATROUILLE_STOP',patrolState.id);savePatrol();speakText('Patrouille arrêtée localement. Les données conservées restent disponibles pour synchronisation.');}
function addPatrolObservation(type,detail,extra={}){
  const o={id:Date.now(),type,detail,lat:fieldNav.lat,lon:fieldNav.lon,accuracy:fieldNav.accuracy,at:new Date().toISOString(),source:'TELEPHONE',...extra};
  patrolState.observations.unshift(o);patrolState.observations=patrolState.observations.slice(0,100);patrolState.last=o;
  queueFieldData('OBSERVATION_PATROUILLE',o);savePatrol();
}
function patrolAnomaly(kind,detail,priority='MOYEN'){
  addPatrolObservation('ANOMALIE · '+priority,detail,{kind,priority});
  localAlert(kind,detail,priority);
}
function patrolTick(){
  if(!patrolState.active||!fieldNav.lat)return;
  patrolState.last={lat:fieldNav.lat,lon:fieldNav.lon,accuracy:fieldNav.accuracy,heading:fieldNav.heading,at:new Date().toISOString()};
  patrolState.track.push([fieldNav.lat,fieldNav.lon,Date.now()]);if(patrolState.track.length>2000)patrolState.track.shift();
  if(fieldNav.accuracy>80)patrolAnomaly('GPS','Précision GPS très faible : vérification de position recommandée.','HAUTE');
  if(fieldNav.destination&&fieldNav.distance>0&&fieldNav.distance<30) addPatrolObservation('DESTINATION','Point cible atteint ou très proche.');
  savePatrol();
}
function exportPatrolPackage(){
  const pkg={version:'V169',patrol:patrolState,offline:offlineState,fieldLink:{online:fieldLink?.online,satellite:fieldLink?.satellite},generated_at:new Date().toISOString()};
  const text=JSON.stringify(pkg,null,2);if(window.G360)G360.saveReport('gabon360-patrouille-'+Date.now()+'.json',text);else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.download='gabon360-patrouille.json';a.click()} audit('EXPORT_PATROUILLE',patrolState.id);toast('Paquet de patrouille exporté');
}
function announceCenterLink(){const t=fieldLink?.satellite?'Liaison satellite détectée. Le téléphone peut transmettre selon le terminal et le service satellite.':fieldLink?.online?'Connexion disponible. Les données de patrouille peuvent être synchronisées.':'Aucune liaison. Le patrouilleur continue hors connexion et les données restent en attente sur le téléphone.';speakText(t)}


// V169 — FUSION CARTE + VISION + PATROUILLE
const FUSION_KEY='g360_fusion_v169';
let fusionState=JSON.parse(localStorage.getItem(FUSION_KEY)||'null')||{last:null,history:[],markers:[]};
function saveFusion(){localStorage.setItem(FUSION_KEY,JSON.stringify(fusionState));renderFusion();}
function renderFusion(){
 const st=document.getElementById('fusionStatus'); if(st) st.textContent=fusionState.last?('Dernière fusion · '+new Date(fusionState.last.at).toLocaleString('fr-FR')):'Aucune fusion';
 const box=document.getElementById('fusionContext'); if(!box)return;
 if(!fusionState.last){box.innerHTML='<div class="item">En attente d’une observation terrain ou d’une analyse VISION.</div>';return}
 const x=fusionState.last, t=x.territory||{};
 box.innerHTML=`<div class="item"><b>🧠 ${esc(x.title||'Observation fusionnée')}</b><div class="meta">${x.at||''} · ${x.lat?.toFixed?.(5)||'—'}, ${x.lon?.toFixed?.(5)||'—'} · source ${esc(x.source||'TERRAIN')}</div><div>${esc(x.detail||'')}</div><div class="meta">Territoire : ${esc(t.summary||'contexte territorial à confirmer par le SIG')}</div><div class="meta">Confiance : ${x.confidence!=null?Math.round(x.confidence*100)+'%':'non disponible'} · Validation humaine : ${x.humanValidated?'OUI':'REQUISE'}</div></div>`;
}
function territoryLayerNames(){return ['geonode:gadm41_GAB_1','geonode:gadm41_GAB_2','geonode:gis_osm_roads_free_1','geonode:gis_osm_waterways_free_1','geonode:gis_osm_water_a_free_1','geonode:gis_osm_protected_areas_a_free_1','geonode:gis_osm_places_free_1'].join(',');}
async function queryTerritoryAtPoint(lat,lon){
 const result={lat,lon,source:'GABON360_WMS_GETFEATUREINFO',features:[],summary:'Position dans l’emprise nationale; objets SIG à confirmer'};
 if(!map)return result;
 try{
  const size=map.getSize(), bounds=map.getBounds(), bbox=[bounds.getWest(),bounds.getSouth(),bounds.getEast(),bounds.getNorth()].join(',');
  const pt=map.latLngToContainerPoint([lat,lon]);
  const url=WMS+'?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetFeatureInfo&LAYERS='+encodeURIComponent(territoryLayerNames())+'&QUERY_LAYERS='+encodeURIComponent(territoryLayerNames())+'&STYLES=&BBOX='+encodeURIComponent(bbox)+'&FEATURE_COUNT=12&HEIGHT='+size.y+'&WIDTH='+size.x+'&FORMAT=image/png&INFO_FORMAT=application/json&SRS=EPSG:4326&X='+Math.round(pt.x)+'&Y='+Math.round(pt.y);
  const r=await fetch(url,{headers:{Accept:'application/json'}}); if(!r.ok)throw new Error('SIG '+r.status); const j=await r.json();
  result.features=(j.features||[]).slice(0,12).map(f=>({layer:f.id||'',properties:f.properties||{}}));
  const names=result.features.map(f=>{const p=f.properties||{};return p.name||p.NAME||p.nom||p.NOM||p.name_en||''}).filter(Boolean);
  result.summary=names.length?names.slice(0,6).join(' · '):'Aucun objet nommé retourné par le SIG à ce point';
 }catch(e){result.error='SIG non disponible: '+e.message;result.summary='Contexte territorial non résolu en temps réel; aucune information inventée';}
 return result;
}
async function fuseObservation(obs, source='TERRAIN'){
 if(!obs||obs.lat==null||obs.lon==null){toast('Observation sans coordonnées GPS');return null}
 const territory=await queryTerritoryAtPoint(obs.lat,obs.lon);
 const confidence=Number(obs.confidence||obs.ai?.confidence||0);
 const fused={id:'FUS-'+Date.now(),at:new Date().toISOString(),title:obs.type||obs.kind||'Observation terrain',detail:obs.detail||obs.note||'Observation terrain',lat:obs.lat,lon:obs.lon,source,confidence,territory,humanValidated:false,validation:'REQUISE'};
 fusionState.last=fused;fusionState.history.unshift(fused);fusionState.history=fusionState.history.slice(0,100);
 if(map){const m=L.marker([obs.lat,obs.lon]).addTo(map).bindPopup(`<b>GABON 360 AI · Fusion</b><br>${esc(fused.title)}<br><small>${esc(territory.summary)}</small><br><small>Validation humaine requise</small>`);fusionState.markers.push(m._leaflet_id);}
 queueFieldData('FUSION_TERRITORIALE',fused);
 audit('FUSION_TERRITOIRE',fused.title+' · '+territory.summary);
 if(confidence>=0.70){state.alerts.unshift({id:Date.now()+2,title:'Observation IA à vérifier',priority:confidence>=0.85?'HAUTE':'MOYENNE',time:stamp(),source:'VISION + CARTE GABON 360',status:'A_VALIDER',lat:obs.lat,lon:obs.lon,confidence});state.alerts=state.alerts.slice(0,100);save();}
 saveFusion();
 document.getElementById('fusionStatus')?.scrollIntoView({behavior:'smooth',block:'center'});
 return fused;
}
function validateFusion(humanValidated=true){if(!fusionState.last)return toast('Aucune observation à valider');fusionState.last.humanValidated=!!humanValidated;fusionState.last.validation=humanValidated?'CONFIRMÉE PAR PATROUILLEUR':'ÉCARTÉE APRÈS VÉRIFICATION';audit('VALIDATION_FUSION',fusionState.last.validation);saveFusion();toast(humanValidated?'Observation confirmée par le patrouilleur.':'Observation écartée après vérification.');}
async function fuseLastVision(){if(!visionState.last)return toast('Aucune analyse VISION disponible');await fuseObservation(visionState.last,'VISION_IA_LOCALE');}
async function fuseLastPatrol(){const o=patrolState.observations?.[0];if(!o)return toast('Aucune observation de patrouille disponible');await fuseObservation(o,'PATROUILLE');}

setInterval(()=>{try{patrolTick();renderPatrolCenter()}catch(e){}},15000);
window.addEventListener('load',()=>{renderPatrolCenter();renderFusion();renderLogistics()});


// V180 — Intelligence spatiale explicable et raisonnement opérationnel
const AI_LOGIC_KEY='g360_ai_logic_v180';
let aiLogicState=JSON.parse(localStorage.getItem(AI_LOGIC_KEY)||'null')||{last:null,history:[]};
function saveAIReasoning(){localStorage.setItem(AI_LOGIC_KEY,JSON.stringify(aiLogicState));renderAIReasoning()}
function renderAIReasoning(){const x=aiLogicState.last;const st=document.getElementById('aiLogicState'),sc=document.getElementById('aiLogicScore'),pr=document.getElementById('aiLogicPriority'),ac=document.getElementById('aiLogicAction'),box=document.getElementById('aiLogicContext');if(!st)return;if(!x){st.textContent='VEILLE';sc.textContent='—';pr.textContent='—';ac.textContent='—';if(box)box.innerHTML='<div class="item">L’IA attend une observation ou une alerte. Elle distingue faits, signaux IA, contexte SIG et validation humaine.</div>';return}st.textContent=x.state||'ANALYSE';sc.textContent=x.confidence!=null?Math.round(x.confidence*100)+'%':'—';pr.textContent=x.priority||'—';ac.textContent=x.proposed_action||'—';if(box)box.innerHTML=(x.signals||[]).map(s=>'<div class="item"><b>'+esc(s.source||'SOURCE')+'</b><div>'+esc(s.finding||'')+'</div><div class="meta">Poids analytique : '+Math.round((s.weight||0)*100)+'%</div></div>').join('')+'<div class="note">Validation humaine requise · moteur explicable · aucune décision coercitive automatique.</div>'}
function localOperationalReasoning(){const alerts=state.alerts||[], events=state.events||[], missions=state.missions||[], pats=patrolState?.observations||[];const open=alerts.filter(x=>!['RESOLUE','FERMEE','CLOTUREE'].includes(String(x.status||'').toUpperCase()));const high=open.filter(x=>['HAUTE','CRITIQUE','HIGH','CRITICAL'].includes(String(x.priority||x.severity||'').toUpperCase()));let score=0,signals=[];if(high.length){score+=.45;signals.push({source:'ALERTES',finding:high.length+' alerte(s) de priorité élevée',weight:.45})}if(open.length>=3){score+=.15;signals.push({source:'ALERTES',finding:open.length+' alertes ouvertes',weight:.15})}if(events.length){score+=.15;signals.push({source:'EVENEMENTS',finding:events.length+' événement(s) disponible(s)',weight:.15})}if(pats.length){score+=.10;signals.push({source:'PATROUILLES',finding:pats.length+' observation(s) terrain',weight:.10})}if(missions.length){score+=.05;signals.push({source:'MISSIONS',finding:missions.length+' mission(s) connue(s)',weight:.05})}score=Math.min(score,.95);const priority=high.length?'HAUTE':(open.length||events.length?'MOYENNE':'BASSE');return {state:'ANALYSE_LOCALE',confidence:score,priority,proposed_action:priority==='HAUTE'?'Vérifier les sources et demander une validation humaine avant toute décision.':priority==='MOYENNE'?'Corréler les sources et envisager une vérification terrain.':'Maintenir la veille et attendre de nouveaux signaux.',signals,human_validation_required:true,generated_at:new Date().toISOString(),engine:'GABON360-SPATIAL-AI/180 LOCAL'}}
async function runOperationalReasoning(){let x=null;const base=(infraState?.backendUrl||'').replace(/\/$/,'');if(base&&fieldLink?.online){try{const h={};if(syncState?.token)h.Authorization='Bearer '+syncState.token;const r=await fetch(base+'/api/v1/ai/analyze?limit=100',{headers:h,cache:'no-store'});if(r.ok)x=await r.json()}catch(e){}}if(!x)x=localOperationalReasoning();aiLogicState.last=x;aiLogicState.history.unshift(x);aiLogicState.history=aiLogicState.history.slice(0,50);saveAIReasoning();audit('AI_OPERATIONAL_REASONING',(x.priority||'')+' · '+Math.round((x.confidence||0)*100)+'%');speakText('Analyse terminée. Priorité '+(x.priority||'non déterminée')+'. Validation humaine requise.');return x}
function clearAIReasoning(){aiLogicState={last:null,history:[]};saveAIReasoning();toast('Moteur IA réinitialisé')}

// V172 — Infrastructure connectée : SIG, météo, réseau, satellite et passerelle backend
const INFRA_KEY='g360_infrastructure_v172';
let infraState=JSON.parse(localStorage.getItem(INFRA_KEY)||'null')||{checkedAt:null,items:[],backendUrl:''};
function saveInfra(){localStorage.setItem(INFRA_KEY,JSON.stringify(infraState));renderInfrastructure()}
function renderInfrastructure(){
  const list=document.getElementById('infraList'); if(!list)return;
  const items=infraState.items||[];
  list.innerHTML=items.length?items.map(x=>`<div class="item"><b>${esc(x.name||'Service')}</b> <span class="badge">${x.online?'🟢 DISPONIBLE':'🔴 INDISPONIBLE'}</span><div class="meta">${esc(x.detail||'')} ${x.http?'· HTTP '+x.http:''}</div></div>`).join(''):'<div class="item">Aucun diagnostic effectué.</div>';
  const stampEl=document.getElementById('infraChecked');if(stampEl)stampEl.textContent=infraState.checkedAt||'Jamais';
  const sat=document.getElementById('infraSatellite');if(sat)sat.textContent=fieldLink?.satellite?'🛰️ SATELLITE DÉTECTÉ':fieldLink?.online?'🌐 RÉSEAU IP':'📴 HORS LIGNE';
  const b=document.getElementById('backendUrl');if(b&&document.activeElement!==b)b.value=infraState.backendUrl||'';
}
function probeInfrastructure(){
  refreshFieldLink();
  if(window.G360&&G360.probeInfrastructure){G360.probeInfrastructure();toast('Diagnostic des serveurs lancé…');}
  else {infraState.items=[{name:'UGEO WMS',online:false,detail:'Pont Android indisponible'},{name:'UGEO WFS',online:false,detail:'Pont Android indisponible'},{name:'GABON 360 API',online:false,detail:'Pont Android indisponible'}];infraState.checkedAt=stamp();saveInfra()}
}
window.onInfrastructureProbe=function(raw){try{const arr=JSON.parse(raw);infraState.items=arr.map(x=>({...x,detail:x.online?'Connexion HTTPS établie':'Serveur non joignable depuis cet appareil'}));infraState.items.push({name:'Réseau appareil',online:!!fieldLink.online,detail:fieldLink.network||'NONE'});infraState.items.push({name:'Liaison satellite',online:!!fieldLink.satellite,detail:fieldLink.satellite?'Transport satellite Android détecté — nécessite un service/terminal actif.':'Aucun transport satellite détecté par Android'});infraState.items.push({name:'Météo',online:navigator.onLine,detail:'API météo appelée seulement lorsque la connexion IP est disponible'});infraState.checkedAt=stamp();audit('DIAGNOSTIC_INFRASTRUCTURE',arr.map(x=>x.name+':'+(x.online?'OK':'KO')).join(' · '));saveInfra();toast('Diagnostic infrastructure terminé')}catch(e){toast('Diagnostic infrastructure invalide')}};
function saveBackendUrl(){const v=(document.getElementById('backendUrl')?.value||'').trim().replace(/\/$/,'');infraState.backendUrl=v;saveInfra();toast(v?'Passerelle GABON 360 enregistrée':'Passerelle backend supprimée');}
async function testBackend(){const url=(infraState.backendUrl||'').trim();if(!url)return toast('Renseigne d’abord l’URL de la passerelle GABON 360');try{const t=Date.now();const r=await fetch(url,{method:'GET',cache:'no-store'});const ms=Date.now()-t;infraState.items=(infraState.items||[]).filter(x=>x.name!=='Passerelle GABON 360');infraState.items.push({name:'Passerelle GABON 360',online:r.ok,detail:r.ok?`Réponse HTTPS en ${ms} ms`:`Réponse HTTP ${r.status}`,http:r.status});infraState.checkedAt=stamp();audit('TEST_BACKEND',url+' · '+r.status);saveInfra();toast(r.ok?'Passerelle joignable':'Passerelle non validée (HTTP '+r.status+')')}catch(e){infraState.items=(infraState.items||[]).filter(x=>x.name!=='Passerelle GABON 360');infraState.items.push({name:'Passerelle GABON 360',online:false,detail:'Échec réseau/CORS ou serveur indisponible'});infraState.checkedAt=stamp();audit('TEST_BACKEND_ECHEC',url);saveInfra();toast('Passerelle non joignable')}}
async function refreshWeather(){
  const lat=fieldNav?.lat??-0.72,lon=fieldNav?.lon??11.55;
  const now=document.getElementById('weatherNow'),forecast=document.getElementById('weatherForecast');if(now)now.textContent='Interrogation du service météo…';
  try{const r=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&hourly=precipitation_probability&forecast_days=1&timezone=auto`);if(!r.ok)throw new Error('HTTP '+r.status);const j=await r.json();const c=j.current||{};if(now)now.textContent=`${c.temperature_2m??'—'} °C · humidité ${c.relative_humidity_2m??'—'}% · vent ${c.wind_speed_10m??'—'} km/h · code météo ${c.weather_code??'—'}`;if(forecast)forecast.textContent=`Position météo : ${lat.toFixed(4)}, ${lon.toFixed(4)}`;infraState.items=(infraState.items||[]).filter(x=>x.name!=='Météo');infraState.items.push({name:'Météo',online:true,detail:'Open-Meteo répond correctement'});infraState.checkedAt=stamp();saveInfra()}catch(e){if(now)now.textContent='Service météo indisponible — aucune donnée inventée.';infraState.items=(infraState.items||[]).filter(x=>x.name!=='Météo');infraState.items.push({name:'Météo',online:false,detail:'Service indisponible'});saveInfra()}
}

// V174 — Centre connecté : synchronisation native téléphone ↔ serveur GABON 360
const DEVICE_ID_KEY='g360_device_id';
const DEVICE_ID=localStorage.getItem(DEVICE_ID_KEY)||(()=>{const x=(crypto&&crypto.randomUUID)?crypto.randomUUID():('g360-'+Date.now()+'-'+Math.random().toString(36).slice(2));localStorage.setItem(DEVICE_ID_KEY,x);return x;})();
const SYNC_KEY='g360_sync_v180';
let syncState=JSON.parse(localStorage.getItem(SYNC_KEY)||'null')||{lastSync:null,status:'JAMAIS',pending:0,token:''};
function saveSync(){localStorage.setItem(SYNC_KEY,JSON.stringify(syncState));renderSync();}
function renderSync(){
 const st=document.getElementById('syncState'); if(st)st.textContent=syncState.status||'JAMAIS';
 const last=document.getElementById('syncLast'); if(last)last.textContent=syncState.lastSync||'Jamais';
 const pend=document.getElementById('syncPending'); if(pend)pend.textContent=syncState.pending??0;
 const url=document.getElementById('backendUrl'); if(url&&document.activeElement!==url)url.value=infraState.backendUrl||'';
}
function buildSyncPackage(){
 return {schema:'gabon360.sync.v1',app_version:'180.0-spatial-intelligence',device_id:DEVICE_ID,device:{device_id:DEVICE_ID,platform:'android-webview',online:!!fieldLink.online,satellite:!!fieldLink.satellite,transport:fieldLink.network||'NONE'},generated_at:new Date().toISOString(),events:state.events,alerts:state.alerts,missions:state.missions,sources:state.sources,audit:state.audit,patrol:typeof patrolState!=='undefined'?patrolState:null,vision:typeof visionState!=='undefined'?visionState:null,logistics:typeof logisticsState!=='undefined'?logisticsState:null,territory:typeof fusionState!=='undefined'?fusionState:null};
}
function syncWithCenter(){
 const url=(infraState.backendUrl||'').trim();
 if(!url)return toast('Configure d’abord la passerelle serveur GABON 360.');
 refreshFieldLink();
 const payload=JSON.stringify(buildSyncPackage());
 syncState.status='ENVOI…';syncState.pending=state.events.length+state.alerts.length+state.missions.length+(patrolState?.observations?.length||0);saveSync();
 if(window.G360&&G360.syncToBackend){G360.syncToBackend(url,payload,syncState.token||'');}
 else toast('Passerelle native indisponible.');
}
window.onBackendSync=function(raw){try{const r=JSON.parse(raw);const ack=Array.isArray(r.accepted_ids)?r.accepted_ids.length:0;syncState.status=r.ok?'SYNCHRONISÉ':'ÉCHEC';syncState.lastSync=stamp();syncState.lastAck=ack;syncState.pending=r.ok?Math.max(0,(syncState.pending||0)-ack):syncState.pending;saveSync();audit(r.ok?'CENTRE_SYNCHRONISÉ':'CENTRE_SYNCHRONISATION_ECHEC',(r.status||'')+' · accusés='+ack+' · '+(r.detail||''));toast(r.ok?'Centre GABON 360 synchronisé · '+ack+' enregistrements accusés':'Synchronisation échouée — données conservées localement');}catch(e){syncState.status='ERREUR';saveSync();toast('Réponse serveur invalide');}};
function saveBackendToken(){syncState.token=(document.getElementById('backendToken')?.value||'').trim();saveSync();toast(syncState.token?'Jeton serveur enregistré localement':'Jeton serveur supprimé');}
function sendHeartbeat(){
 const url=(infraState.backendUrl||'').trim(); if(!url||!window.G360||!G360.syncToBackend)return;
 const hb={schema:'gabon360.heartbeat.v1',device_id:DEVICE_ID,app_version:'180.0-spatial-intelligence',generated_at:new Date().toISOString(),device_online:!!fieldLink.online,satellite:!!fieldLink.satellite,transport:fieldLink.network||'NONE',gps:typeof fieldNav!=='undefined'?{lat:fieldNav.lat,lon:fieldNav.lon}:null};
 G360.syncToBackend(url,JSON.stringify(hb),syncState.token||'');
}
window.addEventListener('load',()=>{renderSync();setInterval(()=>{refreshFieldLink();sendHeartbeat();},60000);});

window.addEventListener('load',()=>{renderInfrastructure();setTimeout(()=>{probeInfrastructure();refreshWeather()},1200)});


// V182 FIELD NAVIGATION BUTTONS + CONSENTED VOICE CONVERSATION
function setDestination(){
  const lat=parseFloat(document.getElementById('destLat')?.value), lon=parseFloat(document.getElementById('destLon')?.value);
  if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180){toast('Coordonnées de destination invalides');return}
  fieldNav.destination={lat,lon}; renderFieldNav(); audit('DESTINATION',lat.toFixed(6)+','+lon.toFixed(6)); speakText('Destination définie.');
}
function clearDestination(){fieldNav.destination=null;fieldNav.distance=0;fieldNav.bearing=null;renderFieldNav();audit('DESTINATION_EFFACEE','');}
function startFieldNav(){
  fieldNav.active=true; refreshFieldLink(); renderFieldNav(); audit('NAVIGATION_TERRAIN','Démarrée');
  if(window.G360&&G360.getLocation)G360.getLocation(); else locateForField();
  speakText('Navigation terrain activée.');
}
function stopFieldNav(){fieldNav.active=false;renderFieldNav();audit('NAVIGATION_TERRAIN','Arrêtée');speakText('Navigation terrain arrêtée.');}
function locateForField(){
  if(window.G360&&G360.getLocation){G360.getLocation();return;}
  if(navigator.geolocation)navigator.geolocation.getCurrentPosition(p=>window.onNativeLocation?.(p.coords.latitude,p.coords.longitude,p.coords.accuracy),()=>toast('GPS indisponible'),{enableHighAccuracy:true,timeout:10000});
}
function toggleCompass(){
  fieldNav.compassEnabled=!fieldNav.compassEnabled; renderFieldNav();
  toast(fieldNav.compassEnabled?'Boussole activée':'Boussole désactivée');
  if(fieldNav.compassEnabled&&window.DeviceOrientationEvent){
    const handler=e=>{if(typeof e.alpha==='number'){fieldNav.heading=e.alpha;renderFieldNav();}};
    window.addEventListener('deviceorientation',handler,{once:false});
  }
}
function saveTrackPoint(){
  if(!fieldNav.lat){locateForField();toast('Recherche de position GPS…');return}
  fieldNav.track=fieldNav.track||[]; fieldNav.track.push([fieldNav.lat,fieldNav.lon,Date.now()]);
  if(fieldNav.track.length>5000)fieldNav.track.shift(); saveField(); renderFieldNav();
  queueFieldData('TRACE_POINT',{lat:fieldNav.lat,lon:fieldNav.lon,accuracy:fieldNav.accuracy,at:new Date().toISOString()});
  audit('TRACE_POINT',fieldNav.lat.toFixed(5)+','+fieldNav.lon.toFixed(5));
}
function exportTrack(){
  const track=fieldNav.track||[]; if(!track.length){toast('Aucun point de trace');return}
  const body=JSON.stringify({schema:'gabon360.track.v1',generated_at:new Date().toISOString(),points:track},null,2);
  const blob=new Blob([body],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='gabon360-trace-'+Date.now()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);audit('EXPORT_TRACE',track.length+' point(s)');
}
function activateOfflineMode(){offlineState.active=true;fieldNav.active=false;save();renderOffline();refreshFieldLink();audit('MODE_FORET','Activé');speakText('Mode forêt activé. Les données restent sur le téléphone jusqu’à synchronisation.');}
function prepareOfflinePack(){
  offlineState.packPrepared=true;offlineState.packAt=new Date().toISOString();save();renderOffline();audit('SECTEUR_HORS_CONNEXION','Préparé');toast('Secteur hors connexion préparé localement.');
}
function syncOfflineQueue(){syncFieldQueue();if(typeof syncWithCenter==='function')syncWithCenter();else toast('Synchronisation lancée.');}

// Conversation vocale explicite : aucune écoute cachée, aucun audio enregistré.
let conversationMode=false;
function startConversationMode(){
  if(conversationMode){stopConversationMode();return}
  const ok=confirm('Activer le mode conversation de GABON 360 AI ? Le microphone restera actif uniquement pendant ce mode, avec indication visible. Aucun audio ne sera enregistré par l’application ; seule la transcription nécessaire à la réponse sera traitée. Assurez-vous que les personnes présentes ont accepté.');
  if(!ok)return;
  conversationMode=true; const el=document.getElementById('voiceState');if(el)el.textContent='🎙️ CONVERSATION ACTIVE — consentement requis';
  audit('CONVERSATION_VOCALE','Mode activé avec consentement'); speakText('Mode conversation activé. Je vous écoute.');
  if(window.G360&&G360.startVoice)G360.startVoice();
}
function stopConversationMode(){conversationMode=false;if(window.G360&&G360.stopVoice)G360.stopVoice();const el=document.getElementById('voiceState');if(el)el.textContent='● Micro en veille';audit('CONVERSATION_VOCALE','Mode arrêté');speakText('Mode conversation arrêté.');}
function handleConversationTranscript(text){
  if(!text)return; const clean=String(text).trim(); if(!clean)return;
  audit('VOIX_TRANSCRITE',clean.slice(0,240));
  if(conversationMode){ command(clean); setTimeout(()=>{if(conversationMode&&window.G360&&G360.startVoice)G360.startVoice();},700); }
}
