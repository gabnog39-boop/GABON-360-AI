# GABON 360 AI — FINAL CONSOLIDATED BUILD CANDIDATE

Version: 183.0-final-consolidated
Application ID: ga.gabon360.ai

## Consolidated in one Android application
- GABON 360 territorial map interface
- territorial layers and SIG integration
- GPS, field navigation and compass
- patrol workflow and observations
- offline queue/synchronization
- logistics and missions
- camera and on-device ML Kit vision
- operational reasoning and national AI situation engine
- spatial/temporal intelligence
- alerts, validation and audit trail
- connected center/backend integration
- voice input and text-to-speech conversation mode
- report export/share
- infrastructure diagnostics
- persistent avatar asset

## Verification performed in this environment
- JavaScript syntax check: PASS
- Python server syntax check: PASS
- Android button handler audit: PASS (61 distinct inline handlers resolved)
- Archive integrity: PASS

## Important deployment notes
- This package is the consolidated Android source project plus the backend source.
- It is not itself an APK.
- A real APK must be compiled with the Android SDK/Gradle toolchain and then installed on the phone.
- The backend is a separate service component; the APK does not magically host a national server.
- Voice conversation is user-activated. The app does not silently listen to people.
- Generic ML Kit object detection/labeling is not a specialized Gabon forest/fire/human-identification model.
- External Leaflet/UGEO/weather services require network access unless equivalent data/services are bundled or deployed locally.

## Application icon — V183
The official GABON 360 image supplied by the project owner is now embedded as the Android launcher icon (`res/drawable-nodpi/ic_launcher.png`). The same image is declared for both `android:icon` and `android:roundIcon` so the application keeps the chosen GABON 360 visual identity.
