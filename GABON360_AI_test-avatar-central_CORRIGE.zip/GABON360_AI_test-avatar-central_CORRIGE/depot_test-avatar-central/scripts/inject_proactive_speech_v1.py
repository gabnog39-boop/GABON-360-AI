#!/usr/bin/env python3
"""Ajoute la couche de parole proactive de l'avatar central (GABON360-PROACTIVE-SPEECH-V1).

- Ne modifie aucun injecteur existant et ne supprime rien : le bloc est AJOUTÉ avant </body>.
- Doit s'exécuter APRÈS tous les autres injecteurs (il enveloppe G360AvatarSpeak et speechSynthesis.speak
  tels qu'ils sont à ce moment-là).
- Idempotent : ne s'applique qu'une fois (marqueur).
"""
from __future__ import annotations
import sys
from pathlib import Path

MARKER = "GABON360-PROACTIVE-SPEECH-V1"
ASSET = Path(__file__).parent / "assets" / "proactive_speech_v1.js"


def find_html(root: Path):
    c = sorted(root.rglob("index.html"), key=lambda p: ("assets" not in p.parts, len(p.parts)))
    return c[0] if c else None


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("android_project")
    html = find_html(root)
    if not html:
        print("ERREUR: index.html introuvable dans", root)
        return 1
    text = html.read_text(encoding="utf-8")
    if MARKER in text:
        print("deja present:", html)
        return 0
    js = ASSET.read_text(encoding="utf-8")
    if "</script>" in js:
        print("ERREUR: le JS contient </script>")
        return 1
    block = f"\n<!-- {MARKER} -->\n<script>\n{js}\n</script>\n"
    idx = text.rfind("</body>")
    text = text[:idx] + block + text[idx:] if idx >= 0 else text + block
    html.write_text(text, encoding="utf-8")
    print("injected:", html)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
