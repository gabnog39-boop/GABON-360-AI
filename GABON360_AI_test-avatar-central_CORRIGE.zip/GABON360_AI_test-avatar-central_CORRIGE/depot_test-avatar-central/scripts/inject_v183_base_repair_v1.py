#!/usr/bin/env python3
"""Réparation minimale de la base V183 (à exécuter AVANT les autres injecteurs).

Défauts constatés dans le ZIP V183 (démontrés par Playwright, voir docs/AUDIT_ET_TESTS.md) :
  1. index.html embarque une copie PARTIELLE du script principal (90 fonctions) et ne charge pas app.js
     (121 fonctions) : 31 fonctions appelées par des boutons n'existent pas.
  2. syncEventMarkers() est appelée par renderAll() mais n'est définie nulle part -> exception à chaque rendu.
  3. fieldNav (état de la navigation terrain) est utilisé ~60 fois mais n'est déclaré nulle part.
  3b. esc, fmtNum, offlineState, renderFieldNav, renderOffline, saveField, queueOffline, localAlert sont
      appelés mais jamais définis : implémentations minimales ajoutées (aucune donnée fictive).
  3c. Un <script src="…leaflet…"> contient 4 Ko de code (bloc V163 patrouilles) : le navigateur ignore le
      corps d'un script ayant un attribut src, donc ce code ne s'exécute jamais, et
      inject_final_runtime_duplicate_repair supprime ensuite la copie ACTIVE de app.js. Le corps inerte est retiré.
  3d. app.js enregistre l'état sous la clé g360_v171, la copie inline sous g360_v172 : migration unique v172 -> v171
      pour ne pas perdre les données déjà présentes sur un téléphone.
  3e. app.js (version plus récente) a perdu l'onglet « Infrastructure » alors que sa section HTML et renderInfra
      existent : l'onglet est rétabli. fieldLinkStatus / fieldLinkDetail / fieldQueue sont écrits par le code mais
      absents du HTML : trois éléments d'affichage sont ajoutés dans la section fieldnav.
  3f. Bouton « OK » de la conversation : onclick="command()" -> dans un attribut inline, `command` est résolu d'abord
      sur le bouton lui-même ; Chrome/WebView récents exposent HTMLButtonElement.command (Invoker Commands API,
      chaîne vide) : « command is not a function ». Le gestionnaire appelle désormais window.command().
  3g. command(text) prononçait « Commande reçue : undefined » quand le bouton OK l'appelle sans argument : le texte
      saisi (variable c, déjà lue dans le champ) est utilisé à la place.
  4. L'appel d'initialisation buildTabs();renderSteps([]);renderAll();initMap(); s'exécute AVANT les
     déclarations let patrolState/fusionState/infraState/fieldLink -> « Cannot access before initialization »
     qui interrompt tout le script.
Modifications : ajout uniquement (script principal remplacé par app.js complet + 3 ajustements ancrés).
Idempotent ; échoue explicitement si une ancre est absente.
"""
from __future__ import annotations
import re, sys
from pathlib import Path

MARKER = "GABON360-V183-BASE-REPAIR-V1"
INIT = "buildTabs();renderSteps([]);renderAll();initMap();"

FIELDNAV = ("const fieldNav={active:false,lat:null,lon:null,accuracy:null,heading:null,bearing:null,distance:null,"
            "destination:null,compassEnabled:false,track:[]};\n")
SYNC = ("function syncEventMarkers(){try{if(typeof map==='undefined'||!map||typeof eventsLayer==='undefined'||!eventsLayer||typeof L==='undefined')return;"
        "if(eventsLayer.clearLayers)eventsLayer.clearLayers();"
        "(state.events||[]).concat(state.alerts||[]).forEach(function(e){if(typeof e.lat==='number'&&typeof e.lon==='number')"
        "L.marker([e.lat,e.lon]).addTo(eventsLayer).bindPopup(String(e.title||''))})}catch(x){}}\n")

MISSING = r"""
try{if(!localStorage.getItem('g360_v171')&&localStorage.getItem('g360_v172'))localStorage.setItem('g360_v171',localStorage.getItem('g360_v172'))}catch(e){}
if(typeof esc==='undefined'){var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}}
if(typeof fmtNum==='undefined'){var fmtNum=function(v,d){var n=Number(v);return v==null||!isFinite(n)?'—':n.toFixed(d==null?2:d)}}
const offlineState=(function(){var o={active:false,packPrepared:false,packAt:null};try{var s=JSON.parse(localStorage.getItem('g360_offline_v1')||'null');if(s&&typeof s==='object')for(var k in o)if(k in s)o[k]=s[k]}catch(e){}return o})();
function saveField(){try{localStorage.setItem('g360_field_v1',JSON.stringify({track:fieldNav.track.slice(-500),destination:fieldNav.destination}));localStorage.setItem('g360_offline_v1',JSON.stringify(offlineState))}catch(e){}}
function renderFieldNav(){var el=document.getElementById('navInstruction');if(el)el.textContent=fieldNav.lat==null?'GPS en attente : aucune position reçue.':'Position réelle '+fmtNum(fieldNav.lat,5)+', '+fmtNum(fieldNav.lon,5)+' (±'+fmtNum(fieldNav.accuracy,0)+' m)'+(fieldNav.distance!=null?' · destination à '+fmtNum(fieldNav.distance,0)+' m':'')}
function renderOffline(){var s={offlineMapStatus:offlineState.packPrepared?'Secteur préparé le '+new Date(offlineState.packAt).toLocaleString('fr-FR'):'Aucun secteur préparé',offlinePack:offlineState.packPrepared?'Prêt':'Non préparé',offlineGPS:fieldNav.lat==null?'GPS en attente':fmtNum(fieldNav.lat,5)+', '+fmtNum(fieldNav.lon,5)};for(var k in s){var e=document.getElementById(k);if(e)e.textContent=s[k]}saveField()}
function queueOffline(type,payload){try{if(typeof queueFieldData==='function')return queueFieldData(type,payload)}catch(e){}}
function localAlert(kind,detail,priority){try{state.alerts.unshift({id:Date.now(),title:String(kind)+' : '+String(detail),priority:priority||'MOYEN',time:stamp(),source:'patrouille terrain',status:'A_VALIDER',lat:fieldNav.lat,lon:fieldNav.lon});save()}catch(e){}}
"""


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("android_project")
    cands = sorted(root.rglob("index.html"), key=lambda p: ("assets" not in p.parts, len(p.parts)))
    if not cands:
        print("ERREUR: index.html introuvable"); return 1
    html = cands[0]
    text = html.read_text(encoding="utf-8")
    if MARKER in text:
        print("deja present:", html); return 0
    app = html.parent / "app.js"
    if not app.exists():
        print("ERREUR: app.js introuvable a cote de index.html (", app, ")"); return 1
    js = app.read_text(encoding="utf-8")
    for anchor in (INIT, "function renderAll"):
        if anchor not in js:
            print("ERREUR: ancre absente dans app.js:", anchor); return 1
    if "</script>" in js:
        print("ERREUR: app.js contient </script>"); return 1
    m = re.search(r"(<script(?![^>]*\bsrc\b)[^>]*>)((?:(?!</script>).)*function renderAll(?:(?!</script>).)*)(</script>)", text, re.S)
    if not m:
        print("ERREUR: script principal introuvable dans index.html"); return 1
    # 1) script complet ; 4) initialisation déplacée en fin de script ; 3) fieldNav ; 2) syncEventMarkers
    # 5) renderPatrolCenter : lat/lon null (observation sans GPS) -> exception toFixed
    bad = "patrolState.last?`${patrolState.last.lat.toFixed(5)}"
    if bad in js:
        js = js.replace(bad, "patrolState.last&&patrolState.last.lat!=null?`${patrolState.last.lat.toFixed(5)}", 1)
    # 7) onglet Infrastructure rétabli
    tab_old = "['sources','🛰️ Sources'],['alerts'"
    if tab_old in js and "['infra'," not in js:
        js = js.replace(tab_old, "['sources','🛰️ Sources'],['infra','🔌 Infrastructure'],['alerts'", 1)
    # 8) éléments d'état de liaison manquants (section fieldnav)
    if 'id="fieldLinkStatus"' not in text:
        text = re.sub(r'(<section[^>]*id="fieldnav"[^>]*>)', r'\1\n<div class="card"><b id="fieldLinkStatus">—</b><div id="fieldLinkDetail" class="note"></div><div class="note">File d’attente : <span id="fieldQueue">0</span></div></div>', text, count=1)
    # 9) bouton OK : appel explicite de la fonction globale
    btn_old = 'onclick="command()">OK</button>'
    if btn_old in text:
        text = text.replace(btn_old, 'onclick="window.command()">OK</button>', 1)
    # 10) message de commande inconnue : texte réellement saisi
    cmd_old = "speakText('Commande reçue : '+text+'. Les actions disponibles"
    if cmd_old in js:
        js = js.replace(cmd_old, "speakText('Commande reçue : '+(text||c)+'. Les actions disponibles", 1)
    # 6) corps inerte du <script src=leaflet> (jamais exécuté) retiré : évite le faux doublon V163
    text = re.sub(r'(<script src="https://unpkg\.com/leaflet[^>]*>)(.*?)(</script>)', lambda mm: mm.group(1) + mm.group(3), text, count=1, flags=re.S)
    m = re.search(r"(<script(?![^>]*\bsrc\b)[^>]*>)((?:(?!</script>).)*function renderAll(?:(?!</script>).)*)(</script>)", text, re.S)
    js = js.replace(INIT, "", 1).rstrip() + "\n" + INIT + "\n"
    new = f"/* {MARKER} */\n" + FIELDNAV + SYNC + MISSING + js
    text = text[:m.start(2)] + new + text[m.end(2):]
    html.write_text(text, encoding="utf-8")
    print("repare:", html)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
