#!/usr/bin/env python3
"""Ajoute l'élément #g360-focus manquant du Centre national (à exécuter APRÈS inject_national_center_ui.py).

Défaut constaté : le gestionnaire des boutons « Domaines IA » écrit dans $('g360-focus').textContent, mais le modèle
HTML de inject_national_center_ui.py ne crée jamais cet élément -> TypeError à chaque clic sur un domaine.
Cause : le badge #g360-focus existe dans le modèle mais inject_real_gabon_map.py remplace le contenu de la zone carte
(badge, grille et boutons de zoom compris). Correctif : ajout d'un <div id="g360-focus"> juste après le titre « Domaines IA »
(hors de la zone carte). Aucune autre modification.
Idempotent ; échoue explicitement si l'ancre est absente.
"""
from __future__ import annotations
import sys
from pathlib import Path

ANCHOR = "<h3>Domaines IA</h3>"
MARK = "g360-focus-fix-v1"
HTML = '<div id="g360-focus" class="note" data-fix="g360-focus-fix-v1" style="font-size:12px;opacity:.85;margin:4px 0"></div>'


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("android_project")
    cands = sorted(root.rglob("index.html"), key=lambda p: ("assets" not in p.parts, len(p.parts)))
    if not cands:
        print("ERREUR: index.html introuvable"); return 1
    html = cands[0]
    text = html.read_text(encoding="utf-8")
    if MARK in text:
        print("deja present:", html); return 0
    if text.count(ANCHOR) != 1:
        print("ERREUR: ancre attendue exactement 1 fois, trouvee", text.count(ANCHOR), "fois"); return 1
    # Le modèle du Centre national est une chaîne JavaScript : ses guillemets sont échappés (\\") ; on s'aligne dessus.
    pos = text.find(ANCHOR)
    escaped = '\\"' in text[max(0, pos - 80):pos]
    snippet = HTML.replace('"', '\\"') if escaped else HTML
    html.write_text(text.replace(ANCHOR, ANCHOR + snippet, 1), encoding="utf-8")
    print("injected:", html)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
