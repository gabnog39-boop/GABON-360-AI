/* GABON360-PROACTIVE-SPEECH-V1
 * Couche de parole proactive de l'avatar central.
 * - Ne crée AUCUN second système vocal : toute parole passe par window.G360AvatarSpeak (avatar existant,
 *   pont natif Android G360Android.speak ou, à défaut, le repli déjà prévu par l'avatar).
 * - Les paroles automatiques des autres modules sont interceptées (G360AvatarSpeak, speechSynthesis.speak),
 *   dédupliquées, priorisées et mises en file ; les paroles déclenchées par un geste de l'utilisateur
 *   (boutons « L'avatar m'explique », « IA », etc.) passent sans délai.
 * - Aucune annonce à intervalle fixe ; aucune donnée ancienne, simulée ou démonstrative n'est annoncée comme réelle.
 */
(function () {
  'use strict';
  if (window.__G360_PROACTIVE_V1) return;
  window.__G360_PROACTIVE_V1 = true;

  var CFG = window.__G360_PROACTIVE_CFG || {};   // surcharge réservée aux tests automatisés
  var T0 = Date.now();
  var WARMUP_MS = CFG.warmupMs != null ? CFG.warmupMs : 6000;               // données restaurées au démarrage : jamais annoncées comme nouvelles
  var MAX_AGE_MS = 15 * 60 * 1000;    // un événement horodaté plus vieux n'est pas « nouveau »
  var DIGEST_DELAY_MS = CFG.digestDelayMs != null ? CFG.digestDelayMs : 20000;        // silence requis avant de lire un résumé secondaire
  var MANUAL_WINDOW_MS = 8000;        // fenêtre après un geste de l'utilisateur
  var LS_SET = 'g360.proactive.settings.v1';
  var LS_SEEN = 'g360.proactive.seen.v1';
  var STATE_KEYS = ['g360_v171', 'g360_v172'];   // app.js (V183) / ancienne copie inline

  /* ---------- utilitaires ---------- */
  function lsGet(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { window.localStorage.setItem(k, v); } catch (e) {} }
  function now() { return Date.now(); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hhmm(t) { var d = new Date(t); return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function norm(s) {
    var t = String(s == null ? '' : s).toLowerCase();
    try { t = t.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {}
    return t.replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  /* cœur d'un texte : sans préfixes d'annonce ni suffixes « Source / Heure / validation » */
  function core(text) {
    var t = String(text == null ? '' : text).replace(/^\s*(alerte critique( verifiee| non verifiee)?|alerte critique|notification gabon 360 ai|information importante|gabon 360 ai)\s*[.:,]\s*/i, '');
    t = t.split(/\.\s*(source|heure|une validation|validation humaine|action recommandee|fiabilite)\b/i)[0];
    return norm(t).slice(0, 140);
  }

  /* ---------- réglages ---------- */
  var DEF = { auto: true, paused: false, muted: false, volume: 1, critical: true, high: true, territorial: true, digest: true };
  var S = (function () {
    var s = {}, k;
    for (k in DEF) s[k] = DEF[k];
    try { var o = JSON.parse(lsGet(LS_SET) || 'null') || {}; for (k in DEF) if (typeof o[k] === typeof DEF[k]) s[k] = o[k]; } catch (e) {}
    if (!(s.volume >= 0 && s.volume <= 1)) s.volume = 1;
    return s;
  })();
  function saveSettings() { lsSet(LS_SET, JSON.stringify(S)); }

  /* ---------- registre des 22 modules (état RÉEL = événements reçus) ---------- */
  var MODS = [
    ['home', 'Accueil', ['avatar', 'home'], ''],
    ['map', 'Cartographie', ['map', 'sig'], 'Réseau requis pour fonds OSM/Esri/UGEO ; Leaflet chargé depuis un CDN'],
    ['sat', 'Satellites', ['sat', 'satellite'], 'Catalogue Copernicus (métadonnées) ; pas d’image en direct'],
    ['drones', 'Drones', ['drones', 'drone'], 'Passerelle drone autorisée et accès à configurer'],
    ['nav', 'Navigation', ['nav', 'navigation'], 'GNSS du téléphone + autorisation de localisation'],
    ['geo', 'Géolocalisation', ['geo', 'geolocation', 'nav'], 'GNSS du téléphone + autorisation de localisation'],
    ['cyber', 'Cyber', ['security', 'cyber'], 'Journal local uniquement ; pas de SOC/SIEM raccordé'],
    ['memory', 'Mémoire territoriale', ['memory'], 'Registre local de l’appareil'],
    ['alerts', 'Alertes', ['alerts', 'alert'], ''],
    ['reports', 'Rapports', ['reports', 'report'], ''],
    ['stats', 'Statistiques', ['stats'], 'Calculées sur les données locales disponibles'],
    ['weather', 'Météo', ['weather'], 'Service Open-Meteo (réseau requis)'],
    ['forests', 'Parcs et biodiversité', ['forests', 'parks'], 'Polygones officiels à importer ; observations locales'],
    ['water', 'Eaux et océan', ['maritime', 'water'], 'Météo marine Open-Meteo ; AIS/navires non configurés'],
    ['borders', 'Frontières', ['borders', 'frontieres'], 'Contour geoBoundaries à charger (réseau) ; aucune détection de franchissement'],
    ['airspace', 'Espace aérien', ['airspace'], 'Aucune source ADS-B/NOTAM configurée'],
    ['center', 'Centre national de situation', ['center', 'orchestrator', 'sources'], ''],
    ['admin', 'Administration', ['admin', 'governance'], 'Contrôle OWNER local ; pas d’authentification serveur'],
    ['users', 'Utilisateurs', ['users', 'access'], 'Pas de comptes serveur raccordés'],
    ['payments', 'Paiements', ['payments'], 'Fournisseur de paiement non configuré ; aucune vérification serveur'],
    ['missions', 'Missions et terrain', ['missions', 'mission', 'patrol'], ''],
    ['garmin', 'Garmin et échange GPX', ['garmin', 'gpx'], 'Import/export de fichiers ; pas de synchronisation Garmin Connect']
  ];
  var seenByKey = {}; // clé de module -> {count,last}
  function noteModule(m) {
    var k = norm(m).replace(/ /g, '-');
    if (!k || k === 'legacy' || k === 'unknown') return;
    var r = seenByKey[k] || (seenByKey[k] = { count: 0, last: 0 });
    r.count++; r.last = now();
  }
  function moduleStatus() {
    return MODS.map(function (m) {
      var cnt = 0, last = 0;
      m[2].forEach(function (a) { var r = seenByKey[a]; if (r) { cnt += r.count; if (r.last > last) last = r.last; } });
      return { id: m[0], label: m[1], events: cnt, last: last || null, state: cnt ? 'données reçues' : 'aucune donnée reçue', needs: m[3] };
    });
  }

  /* ---------- journal et mémoire d'annonces ---------- */
  var journal = [];
  function log(ev, status) {
    journal.unshift({ t: now(), module: ev.module, summary: ev.summary, status: status, priority: ev.priority, verification: ev.verification, source: ev.source });
    if (journal.length > 60) journal.pop();
    renderPanel();
  }
  var seen = {};
  try { seen = JSON.parse(lsGet(LS_SEEN) || '{}') || {}; } catch (e) { seen = {}; }
  function pruneSeen() {
    var keys = Object.keys(seen), cut = now() - 24 * 3600 * 1000;
    keys.forEach(function (k) { if (!seen[k] || seen[k].t < cut) delete seen[k]; });
    keys = Object.keys(seen);
    if (keys.length > 300) keys.sort(function (a, b) { return seen[a].t - seen[b].t; }).slice(0, keys.length - 300).forEach(function (k) { delete seen[k]; });
  }
  pruneSeen();
  function saveSeen() { lsSet(LS_SEEN, JSON.stringify(seen)); }

  /* ---------- modèle d'événement structuré ---------- */
  var DEFAULT_OBS = /^événement reçu$/i;
  function prioOf(sev) {
    var s = String(sev == null ? '' : sev).toUpperCase();
    if (/CRIT|URGENT|ALERT/.test(s)) return 'critical';
    if (/HIGH|HAUT|WARN|IMPORT/.test(s)) return 'high';
    if (/MEDIUM|MOYEN|NORMAL/.test(s)) return 'normal';
    return 'low';
  }
  function verifOf(status, requiresHuman) {
    var s = String(status == null ? '' : status).toUpperCase();
    if (/VALID|VERIFIED|CONFIRM|CLOS/.test(s) && !/A_VALID|A VALID|NON/.test(s)) return 'verified';
    if (requiresHuman === false) return 'verified';
    return 'unverified';
  }
  function makeEvent(o) {
    o = o || {};
    var ev = {
      module: String(o.module || 'unknown'),
      type: String(o.type || 'event'),
      summary: String(o.summary || '').replace(/\s+/g, ' ').trim(),
      timestamp: o.timestamp || null,           // ISO ou ms ; null = heure d'arrivée
      source: String(o.source || '').trim(),
      reliability: typeof o.reliability === 'number' ? o.reliability : null,
      priority: o.priority || 'low',            // critical | high | normal | low
      verification: o.verification || 'unverified', // verified | unverified
      action: o.action || null,
      simulated: !!o.simulated,
      klass: o.klass || null,                   // territorial | null
      origin: o.origin || 'structured',
      arrived: now()
    };
    return ev;
  }
  function tsMs(ev) {
    if (ev.timestamp == null) return null;
    var t = typeof ev.timestamp === 'number' ? ev.timestamp : Date.parse(ev.timestamp);
    return isNaN(t) ? null : t;
  }
  function rankOf(ev) {
    if (ev.priority === 'critical') return ev.verification === 'verified' ? 0 : 1;
    if (ev.priority === 'high') return 2;
    if (ev.klass === 'territorial') return 3;
    return 4; // secondaire -> résumé groupé
  }
  function categoryOk(ev) {
    var r = rankOf(ev);
    if (r <= 1) return S.critical;
    if (r === 2) return S.high;
    if (r === 3) return S.territorial;
    return S.digest;
  }

  /* ---------- filtre « réalité » + déduplication ---------- */
  var queue = [];
  var BLOCK_TYPES = /^(module-ready|ai-navigation|ai-command|ai-command-unresolved|ai-speak|page-opened|terrain-position|terrain-track|health)$/i;
  var SIM_RE = /simul|d[ée]mo|d[ée]monstration|fictif|exemple|\btest\b/i;
  function intake(ev) {
    noteModule(ev.module);
    if (!ev.summary || DEFAULT_OBS.test(ev.summary)) return log(ev, 'ignoré : sans contenu');
    if (BLOCK_TYPES.test(ev.type)) return;
    if (ev.simulated || SIM_RE.test(ev.source) || SIM_RE.test(ev.type)) return log(ev, 'ignoré : simulé / démonstration');
    var t = tsMs(ev), n = now();
    if (t !== null && (t < T0 - 60000 || n - t > MAX_AGE_MS)) return log(ev, 'ignoré : donnée ancienne');
    if (t === null && n - T0 < WARMUP_MS) return log(ev, 'ignoré : restauré au démarrage');
    var key = core(ev.summary); ev.key = key;
    if (!key) return log(ev, 'ignoré : sans contenu');
    var rank = rankOf(ev), prev = seen[key];
    if (prev && n - prev.t < (prev.rank <= 1 ? 15 * 60000 : 2 * 3600000) && rank >= prev.rank) return log(ev, 'ignoré : déjà annoncé');
    for (var i = 0; i < queue.length; i++) {
      if (queue[i].key === key) {
        if (rank < rankOf(queue[i])) { queue[i] = ev; break; }
        return log(ev, 'ignoré : déjà en attente');
      }
    }
    if (i === queue.length) queue.push(ev);
    if (queue.length > 60) queue.sort(function (a, b) { return rankOf(a) - rankOf(b) || a.arrived - b.arrived; }).pop();
    toastEvent(ev);
    if (!S.auto) { removeFromQueue(ev); return log(ev, 'affiché seulement : annonces automatiques désactivées'); }
    log(ev, 'en attente');
    pump();
  }
  function removeFromQueue(ev) { var i = queue.indexOf(ev); if (i >= 0) queue.splice(i, 1); }

  /* ---------- file prioritaire + sortie unique via l'avatar ---------- */
  var origAvatarSpeak = null, inner = 0, busyUntil = 0, busyRank = 9, timer = null;
  function callAvatar(text) {
    if (typeof origAvatarSpeak !== 'function') return false;
    inner++;
    try { origAvatarSpeak(text); return true; } catch (e) { return false; } finally { inner--; }
  }
  function estimate(text) { return Math.min(25000, 800 + String(text).length * 68); }
  function compose(ev) {
    var s = ev.summary.replace(/[.\s]+$/, '');
    var src = ev.source ? ' Source : ' + ev.source + '.' : '';
    var conf = ev.reliability !== null ? ' Fiabilité estimée : ' + Math.round(ev.reliability * 100) + ' pour cent.' : '';
    var act = ev.action ? ' Action recommandée : ' + String(ev.action).replace(/[.\s]+$/, '') + '.' : '';
    var r = rankOf(ev);
    if (r === 0) return 'Alerte critique vérifiée. ' + s + '.' + src + conf + act;
    if (r === 1) return 'Alerte critique, non encore vérifiée. ' + s + '.' + src + conf + ' Validation humaine requise.' + act;
    if (r === 2) return 'Information importante. ' + s + '.' + src + conf + (ev.verification === 'verified' ? '' : ' À vérifier.') + act;
    return s + '.' + src + (ev.verification === 'verified' ? '' : ' À vérifier.');
  }
  function markAnnounced(ev, status) {
    seen[ev.key] = { t: now(), rank: rankOf(ev) }; saveSeen();
    log(ev, status);
  }
  function pick() {
    var best = null;
    queue.forEach(function (e) { var r = rankOf(e); if (r <= 3 && (!best || r < rankOf(best) || (r === rankOf(best) && e.arrived < best.arrived))) best = e; });
    return best;
  }
  function pump() {
    if (timer) { clearTimeout(timer); timer = null; }
    if (!S.auto || S.paused) return;
    var n = now(), ev = pick();
    if (ev) {
      var r = rankOf(ev);
      if (!categoryOk(ev)) { removeFromQueue(ev); log(ev, 'affiché seulement : catégorie désactivée'); return pump(); }
      var blocked = n < busyUntil && !(r <= 1 && r < busyRank);   // une alerte critique plus prioritaire peut couper une annonce moins prioritaire
      if (blocked) { timer = setTimeout(pump, busyUntil - n + 60); return; }
      removeFromQueue(ev);
      speakEvent(compose(ev), ev, r);
      return pump();
    }
    var low = queue.filter(function (e) { return rankOf(e) === 4; });
    if (!low.length) return;
    if (!S.digest) { low.forEach(function (e) { removeFromQueue(e); log(e, 'affiché seulement : résumé désactivé'); }); return; }
    var newest = low.reduce(function (a, e) { return Math.max(a, e.arrived); }, 0);
    var due = Math.max(busyUntil, newest + DIGEST_DELAY_MS);
    if (n < due) { timer = setTimeout(pump, due - n + 60); return; }
    var items = low.slice(0, 3).map(function (e) { return e.summary.replace(/[.\s]+$/, ''); });
    var more = low.length - items.length;
    var txt = (low.length === 1 ? 'Une information secondaire : ' : low.length + ' informations secondaires : ') + items.join(' ; ') + (more > 0 ? ' ; et ' + more + ' autre' + (more > 1 ? 's' : '') : '') + '.';
    low.forEach(function (e) { removeFromQueue(e); });
    speakDigest(txt, low);
  }
  function emit(text, rank) {
    if (S.muted || S.volume === 0) return 'muet';
    if (!callAvatar(text)) return 'voix indisponible';
    busyUntil = now() + estimate(text); busyRank = rank;
    return 'ok';
  }
  function speakEvent(text, ev, rank) {
    var res = emit(text, rank);
    markAnnounced(ev, res === 'ok' ? 'annoncé' : res === 'muet' ? 'affiché seulement : voix coupée' : 'affiché seulement : voix indisponible');
  }
  function speakDigest(text, evs) {
    var res = emit(text, 4);
    evs.forEach(function (e) { markAnnounced(e, res === 'ok' ? 'annoncé (résumé groupé)' : res === 'muet' ? 'affiché seulement : voix coupée' : 'affiché seulement : voix indisponible'); });
  }

  /* ---------- interception de la parole automatique des autres modules ---------- */
  var lastGesture = 0;
  ['click', 'touchend', 'pointerup', 'keydown'].forEach(function (t) { document.addEventListener(t, function () { lastGesture = now(); }, true); });
  var AUTO_PREFIX = /^\s*(alerte critique|notification gabon 360 ai|gabon 360 ai\s*\.)/i;
  function isManual(text) {
    if (AUTO_PREFIX.test(String(text || ''))) return false;
    return now() - lastGesture < MANUAL_WINDOW_MS;
  }
  function legacyEvent(text, via) {
    var t = String(text || ''), p = 'low';
    if (/^\s*alerte critique/i.test(t)) p = 'critical';
    else if (/^\s*(notification gabon 360 ai|gabon 360 ai\s*\.)/i.test(t)) p = 'high';
    var body = t.replace(/^\s*(alerte critique|notification gabon 360 ai|gabon 360 ai)\s*[.:]\s*/i, '');
    var m = /Source\s*:\s*([^.]+)/i.exec(t);
    return makeEvent({ module: 'legacy', type: 'legacy-speech:' + via, summary: body.split(/\.\s*(Source|Heure|Une validation)/i)[0], source: m ? m[1].trim() : '', priority: p, verification: /v[ée]rifi[ée]e?\b/i.test(t) && !/non (encore )?v[ée]rifi/i.test(t) ? 'verified' : 'unverified', origin: 'legacy' });
  }
  function manualOut(text, speakFn) {
    if (S.muted || S.volume === 0) { toastText('🔇 Voix coupée — ' + String(text).slice(0, 160)); return; }
    speakFn();
  }
  function installAvatarGate() {
    origAvatarSpeak = window.G360AvatarSpeak;
    var wrapper = function (text) {
      if (inner) return origAvatarSpeak && origAvatarSpeak.apply(this, arguments);
      if (isManual(text)) return manualOut(text, function () { callAvatarManual(text); });
      intake(legacyEvent(text, 'avatar'));
    };
    wrapper.__g360Proactive = true;
    try {
      Object.defineProperty(window, 'G360AvatarSpeak', { configurable: true, get: function () { return wrapper; }, set: function (f) { if (typeof f === 'function' && !f.__g360Proactive) origAvatarSpeak = f; } });
    } catch (e) { window.G360AvatarSpeak = wrapper; }
  }
  function callAvatarManual(text) {
    if (typeof origAvatarSpeak !== 'function') return;
    inner++; try { origAvatarSpeak(text); } finally { inner--; }
  }
  function installSynthGate() {
    try {
      var ss = window.speechSynthesis; if (!ss || ss.speak.__g360Proactive) return;
      var os = ss.speak;
      var g = function (u) {
        var text = u && u.text;
        if (inner) { try { u.volume = S.volume; } catch (e) {} return os.call(ss, u); }
        if (isManual(text)) return manualOut(text, function () { try { u.volume = S.volume; } catch (e) {} os.call(ss, u); });
        intake(legacyEvent(text, 'speechSynthesis'));
      };
      g.__g360Proactive = true;
      ss.speak = g;
    } catch (e) {}
  }
  (function hookVoiceResult() {
    var prev = window.G360NativeSpeechResult;
    try {
      Object.defineProperty(window, 'G360NativeSpeechResult', { configurable: true,
        get: function () { return function (t) { lastGesture = now(); return typeof prev === 'function' ? prev.apply(this, arguments) : undefined; }; },
        set: function (f) { prev = f; } });
    } catch (e) {}
  })();


  /* ---------- garde anti-récursion du relais central ----------
   * Défaut constaté dans le code existant : l'IA spécialisée (receive) republie chaque « ai-notification »
   * sur le relais, et ce même type est réécouté par l'IA spécialisée -> boucle sans fin qui fige la page.
   * La garde coupe uniquement la ré-entrée du même type de notification. */
  var relayGuardInstalled = false;
  function installRelayGuard() {
    var R = window.GABON360_AI_RELAY;
    if (!R || typeof R.publish !== 'function' || R.publish.__g360Guard) { return; }
    var orig = R.publish, active = {};
    var g = function (module, type) {
      var k = String(type);
      if (/^(ai-notification|cyber-ai-alert|cross-domain-anomaly)$/.test(k)) {
        if (active[k]) return null;
        active[k] = 1;
        try { return orig.apply(this, arguments); } finally { active[k] = 0; }
      }
      return orig.apply(this, arguments);
    };
    g.__g360Guard = true;
    R.publish = g; relayGuardInstalled = true;
  }

  /* ---------- sources structurées : relais central ---------- */
  var ALLOWED = /^(ai-notification|cyber-ai-alert|cross-domain-anomaly|alert-created|alert-updated|report-created|mission-created|mission-updated|drone-status|camera-status|maritime-status|source-status|weather-result|ai-event)$/i;
  function fromRelay(detail) {
    var d = detail || {}, type = d.type || '', data = d.data || {}, p = data.payload || data;
    if (p && p.__g360Proactive) return;
    var modName = data.module || p.module || d.module || '';
    if (modName && !BLOCK_TYPES.test(type) && !/^proactive-announcement$/i.test(type)) noteModule(modName);
    var obs = p.observation || p.summary || p.message || p.text || p.voice || '';
    var sev = p.severity || p.priority || '';
    var prio = prioOf(sev);
    if (!ALLOWED.test(type) && prio !== 'critical' && prio !== 'high') return;
    if (!obs) return;
    if (/^(drone|camera|maritime|source|weather)-/i.test(type) && prio === 'low' && !p.recommended_action) return; // simple état : journal du module, pas d'annonce
    intake(makeEvent({
      module: data.module || p.module || d.module || 'unknown', type: type, summary: obs,
      timestamp: p.timestamp || p.time || d.time || null, source: p.source || data.module || '',
      reliability: typeof p.confidence === 'number' ? p.confidence : null, priority: prio,
      verification: verifOf(p.status, p.requires_human_validation), action: p.recommended_action || p.action || null,
      simulated: !!(p.simulated || p.demo)
    }));
  }
  window.addEventListener('gabon360:ai-relay', function (e) { try { fromRelay(e && e.detail); } catch (x) {} });

  /* transmission au relais central (même événement, marqué pour ne pas être ré-ingéré) */
  function toRelay(ev) {
    try {
      if (!window.GABON360_AI_RELAY) return;
      var t = /^(alert-created|alert-updated|mission-created|mission-updated)$/.test(ev.type) ? ev.type : 'proactive-announcement';
      window.GABON360_AI_RELAY.publish(ev.module, t, { __g360Proactive: true, module: ev.module, observation: ev.summary, source: ev.source, severity: ev.priority, status: ev.verification });
    } catch (e) {}
  }
  function intakeAndRelay(ev) { if (!ev.simulated) toRelay(ev); intake(ev); }

  /* ---------- sources structurées : alertes / missions / événements réellement créés ---------- */
  var base = null;
  function readState() { for (var i = 0; i < STATE_KEYS.length; i++) { try { var o = JSON.parse(lsGet(STATE_KEYS[i]) || 'null'); if (o && typeof o === 'object') return o; } catch (e) {} } return null; }
  function ids(arr) { var o = {}; (arr || []).forEach(function (x) { if (x && x.id != null) o[x.id] = x; }); return o; }
  function snapshot(st) { return { alerts: ids(st && st.alerts), missions: ids(st && st.missions), events: ids(st && st.events) }; }
  function diffState() {
    var st = readState(); if (!st) return;
    var cur = snapshot(st);
    if (!base) { base = cur; return; }
    var simIds = {};
    Object.keys(cur.events).forEach(function (k) { var e = cur.events[k]; if (/simul/i.test(String(e.source || '') + ' ' + String(e.zone || ''))) { simIds[e.id] = 1; simIds[Number(e.id) + 1] = 1; } });
    Object.keys(cur.alerts).forEach(function (k) {
      var a = cur.alerts[k], b = base.alerts[k];
      var simulated = !!simIds[a.id];
      var prio = /CRIT/i.test(a.priority) ? 'critical' : /HAUT|HIGH/i.test(a.priority) ? 'high' : 'normal';
      if (!b) {
        intakeAndRelay(makeEvent({ module: 'alerts', type: 'alert-created', summary: a.title || 'Nouvelle alerte', source: a.source || 'alertes', priority: prio, verification: verifOf(a.status), reliability: typeof a.confidence === 'number' ? a.confidence : null, simulated: simulated, action: 'Faire valider l’alerte par un opérateur', klass: 'territorial' }));
      } else if (b.status !== a.status && verifOf(a.status) === 'verified' && verifOf(b.status) !== 'verified') {
        intakeAndRelay(makeEvent({ module: 'alerts', type: 'alert-updated', summary: (a.title || 'Alerte') + ' : validée', source: a.source || 'alertes', priority: prio, verification: 'verified', simulated: simulated, klass: 'territorial' }));
      }
    });
    Object.keys(cur.missions).forEach(function (k) {
      if (!base.missions[k]) { var m = cur.missions[k]; intakeAndRelay(makeEvent({ module: 'missions', type: 'mission-created', summary: 'Nouvelle mission : ' + (m.title || ''), source: 'missions', priority: 'normal', verification: 'verified', klass: 'territorial' })); }
    });
    Object.keys(cur.events).forEach(function (k) {
      if (!base.events[k]) { var e = cur.events[k]; intakeAndRelay(makeEvent({ module: 'events', type: 'event-created', summary: 'Nouvel événement territorial : ' + (e.title || '') + (e.zone ? ' (' + e.zone + ')' : ''), source: e.source || 'événements', priority: prioOf(/HAUT/i.test(e.priority) ? 'HIGH' : ''), verification: verifOf(e.status), simulated: /simul/i.test(String(e.source || '') + ' ' + String(e.zone || '')), klass: 'territorial' })); }
    });
    base = cur;
  }
  (function watchStorage() {
    base = snapshot(readState());
    try {
      var sp = Storage.prototype, oset = sp.setItem;
      sp.setItem = function (k, v) { var r = oset.apply(this, arguments); if (STATE_KEYS.indexOf(k) >= 0) setTimeout(function () { try { diffState(); } catch (e) {} }, 0); return r; };
    } catch (e) {}
  })();

  /* ---------- API publique pour les IA spécialisées ---------- */
  function publish(o) {
    var ev = makeEvent({
      module: o.module, type: o.type || 'ai-notification', summary: o.summary || o.observation || '', timestamp: o.timestamp || null,
      source: o.source || '', reliability: typeof o.reliability === 'number' ? o.reliability : (typeof o.confidence === 'number' ? o.confidence : null),
      priority: o.priority || prioOf(o.severity), verification: o.verification || verifOf(o.status, o.requires_human_validation),
      action: o.action || o.recommended_action || null, simulated: !!o.simulated, klass: o.klass || null
    });
    intake(ev);
    toRelay(ev);
    return ev;
  }

  /* ---------- interface : bouton + panneau de réglages + bandeau ---------- */
  var css = document.createElement('style');
  css.textContent = '#g360-pro-btn{position:fixed;right:4px;top:46%;z-index:2147483001;width:38px;height:38px;border-radius:50%;background:#0b1a2a;color:#fff;border:1px solid #31506d;font-size:19px;line-height:1;padding:0}' +
    '#g360-pro-btn.off{opacity:.55}#g360-pro-panel{display:none;position:fixed;inset:0;z-index:2147483640;background:#020913f7;color:#edf7ff;font:14px system-ui,sans-serif;overflow:auto}' +
    '#g360-pro-panel .in{max-width:640px;margin:0 auto;padding:12px 12px 40px;box-sizing:border-box}#g360-pro-panel .hd{display:flex;align-items:center;gap:8px;position:sticky;top:0;background:#071522f5;border-bottom:1px solid #31506d;padding:9px 0}' +
    '#g360-pro-panel .hd b{flex:1;font-size:16px}#g360-pro-panel button{background:#0c2032;color:#fff;border:1px solid #31506d;border-radius:8px;padding:9px 11px;font-size:14px}' +
    '#g360-pro-panel .c{background:#071522;border:1px solid #1e3b51;border-radius:11px;padding:10px;margin-top:9px}#g360-pro-panel label{display:flex;align-items:center;gap:8px;margin:7px 0}' +
    '#g360-pro-panel .j{font-size:12px;border-top:1px solid #16314a;padding:6px 0}#g360-pro-panel .j i{color:#9fd8ff;font-style:normal}#g360-pro-panel .ok{color:#8df0b1}#g360-pro-panel .wait{color:#ffd48a}' +
    '#g360-pro-toast{position:fixed;left:8px;right:60px;top:8px;z-index:2147483002;background:#071522ee;color:#eaf6ff;border:1px solid #31506d;border-left:4px solid #39d98a;border-radius:10px;padding:8px 10px;font:12px system-ui,sans-serif;display:none}' +
    '#g360-pro-toast.crit{border-left-color:#ff5d5d}#g360-pro-toast.high{border-left-color:#f0a34a}';
  document.head.appendChild(css);
  var btn = document.createElement('button'); btn.id = 'g360-pro-btn'; btn.type = 'button'; btn.setAttribute('aria-label', 'Annonces de l’avatar'); btn.textContent = '🔔';
  var panel = document.createElement('div'); panel.id = 'g360-pro-panel'; panel.setAttribute('aria-hidden', 'true');
  var toastEl = document.createElement('div'); toastEl.id = 'g360-pro-toast';
  var toastTimer = null;
  function toastText(t, cls) { toastEl.className = cls || ''; toastEl.textContent = t; toastEl.style.display = 'block'; clearTimeout(toastTimer); toastTimer = setTimeout(function () { toastEl.style.display = 'none'; }, 9000); }
  function toastEvent(ev) { var r = rankOf(ev); toastText((r <= 1 ? '🚨 ' : r === 2 ? '⚠️ ' : 'ℹ️ ') + ev.summary + (ev.source ? ' — ' + ev.source : '') + (ev.verification === 'verified' ? '' : ' (à vérifier)'), r <= 1 ? 'crit' : r === 2 ? 'high' : ''); }
  function updateBtn() { btn.className = (!S.auto || S.paused || S.muted) ? 'off' : ''; btn.textContent = S.muted ? '🔇' : S.paused ? '⏸️' : '🔔'; }
  function openPanel() { panel.style.display = 'block'; panel.setAttribute('aria-hidden', 'false'); renderPanel(); }
  function closePanel() { panel.style.display = 'none'; panel.setAttribute('aria-hidden', 'true'); }
  function renderPanel() {
    updateBtn();
    if (panel.style.display !== 'block') return;
    var st = moduleStatus();
    var h = '<div class="in"><div class="hd"><b>🔔 Annonces de l’avatar central</b><button id="g360-pro-close">✕</button></div>' +
      '<div class="c"><b>Autres pages</b><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px"><button id="g360-pro-p1">🧱 Frontières</button><button id="g360-pro-p2">✈️ Espace aérien</button><button id="g360-pro-p3">💳 Paiements</button></div></div>' +
      '<div class="c"><label><input type="checkbox" id="g360-pro-auto"' + (S.auto ? ' checked' : '') + '> Annonces automatiques</label>' +
      '<label><input type="checkbox" id="g360-pro-mute"' + (S.muted ? ' checked' : '') + '> Voix coupée (texte affiché seulement)</label>' +
      '<div style="display:flex;gap:8px;margin:8px 0"><button id="g360-pro-pause">' + (S.paused ? '▶ Reprendre' : '⏸ Suspendre') + '</button><button id="g360-pro-stop">■ Arrêter la parole</button></div>' +
      '<label>Volume <input type="range" id="g360-pro-vol" min="0" max="100" value="' + Math.round(S.volume * 100) + '" style="flex:1"> <span id="g360-pro-volv">' + Math.round(S.volume * 100) + ' %</span></label>' +
      '<small>Sur Android, le pont vocal natif suit le volume média du téléphone ; ce curseur règle le repli navigateur et peut couper l’annonce (0 %).</small></div>' +
      '<div class="c"><b>Annonces prioritaires</b>' +
      '<label><input type="checkbox" id="g360-pro-c1"' + (S.critical ? ' checked' : '') + '> Alertes critiques</label>' +
      '<label><input type="checkbox" id="g360-pro-c2"' + (S.high ? ' checked' : '') + '> Informations importantes</label>' +
      '<label><input type="checkbox" id="g360-pro-c3"' + (S.territorial ? ' checked' : '') + '> Missions et événements territoriaux</label>' +
      '<label><input type="checkbox" id="g360-pro-c4"' + (S.digest ? ' checked' : '') + '> Résumé groupé des informations secondaires</label></div>' +
      '<div class="c"><b>En attente : ' + queue.length + '</b> · mémoire anti-répétition : ' + Object.keys(seen).length + ' annonces</div>' +
      '<div class="c"><b>Journal</b>' + (journal.length ? journal.slice(0, 25).map(function (j) { return '<div class="j"><i>' + hhmm(j.t) + ' · ' + esc(j.module) + '</i> — ' + esc(j.status) + '<br>' + esc(j.summary) + '</div>'; }).join('') : '<div class="j">Aucun événement réel reçu depuis le démarrage.</div>') + '</div>' +
      '<div class="c"><b>État réel des modules</b><br><small>« Données reçues » = au moins un événement réel reçu par le relais depuis le démarrage.</small>' +
      st.map(function (m) { return '<div class="j"><span class="' + (m.events ? 'ok' : 'wait') + '">' + esc(m.label) + ' — ' + m.state + (m.last ? ' (' + hhmm(m.last) + ')' : '') + '</span>' + (m.needs ? '<br><small>' + esc(m.needs) + '</small>' : '') + '</div>'; }).join('') + '</div></div>';
    panel.innerHTML = h;
    var $ = function (id) { return document.getElementById(id); };
    $('g360-pro-close').onclick = closePanel;
    [['g360-pro-p1', 'GABON360_OPEN_BORDERS'], ['g360-pro-p2', 'GABON360_OPEN_AIRSPACE'], ['g360-pro-p3', 'GABON360_OPEN_PAYMENTS']].forEach(function (a) { var el = $(a[0]); if (el) el.onclick = function () { closePanel(); if (typeof window[a[1]] === 'function') window[a[1]](); }; });
    $('g360-pro-auto').onchange = function () { S.auto = this.checked; saveSettings(); if (!S.auto) { queue.slice().forEach(function (e) { removeFromQueue(e); log(e, 'affiché seulement : annonces automatiques désactivées'); }); } else pump(); renderPanel(); };
    $('g360-pro-mute').onchange = function () { S.muted = this.checked; saveSettings(); if (S.muted) api.stopSpeech(); renderPanel(); };
    $('g360-pro-pause').onclick = function () { S.paused ? api.resume() : api.pause(); };
    $('g360-pro-stop').onclick = function () { api.stopSpeech(); };
    $('g360-pro-vol').oninput = function () { S.volume = Number(this.value) / 100; $('g360-pro-volv').textContent = this.value + ' %'; saveSettings(); updateBtn(); };
    ['critical:c1', 'high:c2', 'territorial:c3', 'digest:c4'].forEach(function (p) { var a = p.split(':'); $('g360-pro-' + a[1]).onchange = function () { S[a[0]] = this.checked; saveSettings(); pump(); }; });
  }
  btn.onclick = function () { panel.style.display === 'block' ? closePanel() : openPanel(); };

  var api = {
    version: '1.0',
    publish: publish,
    settings: function () { return JSON.parse(JSON.stringify(S)); },
    set: function (o) { for (var k in o) if (k in DEF && typeof o[k] === typeof DEF[k]) S[k] = o[k]; saveSettings(); renderPanel(); pump(); },
    pause: function () { S.paused = true; saveSettings(); if (timer) { clearTimeout(timer); timer = null; } renderPanel(); },
    resume: function () { S.paused = false; saveSettings(); renderPanel(); pump(); },
    setVolume: function (v) { S.volume = Math.max(0, Math.min(1, Number(v))); saveSettings(); renderPanel(); },
    stopSpeech: function () { try { if (window.G360AvatarStop) window.G360AvatarStop(); } catch (e) {} busyUntil = 0; },
    status: function () { return { relayGuard: relayGuardInstalled, queue: queue.length, journal: journal.slice(0, 60), modules: moduleStatus(), settings: api.settings(), busyUntil: busyUntil }; },
    _spokenKeys: function () { return Object.keys(seen); },
    _test: { core: core, rankOf: rankOf, compose: compose,
      ageSeen: function (ms) { Object.keys(seen).forEach(function (k) { seen[k].t -= ms; }); busyUntil = 0; } }
  };
  window.GABON360_PROACTIVE = api;

  /* bannière « IA prêtes » : remplacer l’affirmation statique par l’état réel */
  function fixBanner() {
    var st = document.getElementById('g360-ai-architecture-state');
    if (st) {
      var m = moduleStatus(), got = m.filter(function (x) { return x.events; }).length;
      st.textContent = '26 IA enregistrées · relais central actif · modules avec données réelles reçues : ' + got + '/22 (les autres attendent des données ou une configuration)';
    }
    var nodes = document.querySelectorAll('#g360-ai-architecture-grid .g360-ai-node span');
    for (var i = 0; i < nodes.length; i++) if (/IA prête · relais central/.test(nodes[i].textContent)) nodes[i].textContent = 'enregistrée · aucune donnée reçue';
  }

  function boot() {
    installRelayGuard(); installAvatarGate(); installSynthGate();
    document.body.appendChild(btn); document.body.appendChild(panel); document.body.appendChild(toastEl);
    updateBtn(); fixBanner();
    setTimeout(fixBanner, 800);
    window.addEventListener('gabon360:ai-relay', function () { setTimeout(fixBanner, 0); });
  }
  if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);
})();
