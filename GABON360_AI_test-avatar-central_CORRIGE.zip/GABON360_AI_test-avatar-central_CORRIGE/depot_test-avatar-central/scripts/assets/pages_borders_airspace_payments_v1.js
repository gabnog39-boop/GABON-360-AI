/* GABON360-PAGES-BORDERS-AIRSPACE-PAYMENTS-V1
 * Pages Frontières, Espace aérien et Paiements — aucune donnée fictive, état de configuration explicite.
 * - Frontières : contour national réel (geoBoundaries) chargé à la demande, test de position GNSS, saisie manuelle.
 * - Espace aérien : aucune source configurée ; saisie manuelle de signalements ; liste des raccordements nécessaires.
 * - Paiements : AUCUN encaissement ; état de l'intégration et prérequis de sécurité.
 * Les événements saisis passent par GABON360_PROACTIVE.publish (relais central -> avatar).
 */
(function () {
  'use strict';
  if (window.__G360_PAGES_BAP_V1) return;
  window.__G360_PAGES_BAP_V1 = true;

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lsGet(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { window.localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function when(t) { try { return new Date(t).toLocaleString('fr-FR'); } catch (e) { return String(t); } }
  function norm(s) { var t = String(s == null ? '' : s).toLowerCase(); try { t = t.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {} return t; }
  function relay(module, type, data) { try { if (window.GABON360_AI_RELAY) window.GABON360_AI_RELAY.publish(module, type, data || {}); } catch (e) {} }
  function proactive(o) { try { if (window.GABON360_PROACTIVE) return window.GABON360_PROACTIVE.publish(o); } catch (e) {} return null; }

  var css = document.createElement('style');
  css.textContent =
    '.g360-bap{display:none;position:fixed;inset:0;z-index:2147483600;background:#020913f7;color:#edf7ff;font:14px system-ui,sans-serif;overflow:auto}' +
    '.g360-bap .in{max-width:680px;margin:0 auto;padding:12px 12px 44px;box-sizing:border-box}' +
    '.g360-bap .hd{display:flex;gap:8px;align-items:center;position:sticky;top:0;z-index:3;background:#071522f5;border-bottom:1px solid #31506d;padding:9px 0}' +
    '.g360-bap .hd b{flex:1;font-size:17px}.g360-bap button,.g360-bap input,.g360-bap select,.g360-bap textarea{background:#0c2032;color:#fff;border:1px solid #31506d;border-radius:8px;padding:9px;font:14px system-ui,sans-serif;box-sizing:border-box}' +
    '.g360-bap textarea,.g360-bap input[type=text],.g360-bap select{width:100%;margin:5px 0}.g360-bap button[disabled]{opacity:.45}' +
    '.g360-bap .c{background:#071522;border:1px solid #1e3b51;border-radius:11px;padding:11px;margin-top:10px}.g360-bap h3{margin:0 0 6px;font-size:15px}' +
    '.g360-bap .st{display:inline-block;border-radius:7px;padding:3px 8px;font-weight:800;font-size:12px}.g360-bap .wait{background:#4a3a10;color:#ffd48a}.g360-bap .part{background:#10364a;color:#9fd8ff}.g360-bap .ok{background:#0f3d2a;color:#8df0b1}' +
    '.g360-bap small{opacity:.78}.g360-bap ul{margin:6px 0 0 18px;padding:0}.g360-bap .row{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.g360-bap .rec{border-top:1px solid #16314a;padding:6px 0;font-size:12px}' +
 '';
  document.head.appendChild(css);

  function mkPage(id, title, body) {
    var d = document.createElement('div'); d.id = id; d.className = 'g360-bap'; d.setAttribute('aria-hidden', 'true');
    d.innerHTML = '<div class="in"><div class="hd"><button class="bk">← Centre</button><b>' + title + '</b><button class="cl" aria-label="Fermer">✕</button></div>' + body + '</div>';
    document.body.appendChild(d);
    d.querySelector('.bk').onclick = d.querySelector('.cl').onclick = function () { closePage(id); };
    return d;
  }
  var PAGES = {};
  function closeAllBap() { Object.keys(PAGES).forEach(function (k) { var e = $(PAGES[k]); if (e) { e.style.display = 'none'; e.setAttribute('aria-hidden', 'true'); } }); }
  function closePage(id) { var e = $(id); if (e) { e.style.display = 'none'; e.setAttribute('aria-hidden', 'true'); } }
  function openPage(key) {
    var id = PAGES[key]; if (!id) return false;
    try { if (typeof window.GABON360_CLOSE_ALL_PANELS === 'function') window.GABON360_CLOSE_ALL_PANELS(); } catch (e) {}
    closeAllBap();
    var e = $(id); e.style.display = 'block'; e.setAttribute('aria-hidden', 'false'); e.scrollTop = 0;
    window.GABON360_CURRENT_PAGE = key;
    if (renderers[key]) renderers[key]();
    return true;
  }
  var renderers = {};

  /* ================= FRONTIÈRES ================= */
  var GEO_KEY = 'g360.borders.geojson.v1', GEO_META = 'g360.borders.meta.v1', OBS_B = 'g360.borders.obs.v1';
  var geo = null;
  function loadStoredGeo() { try { var g = lsGet(GEO_KEY); if (g) geo = JSON.parse(g); } catch (e) { geo = null; } }
  function polysOf(g) {
    var out = [];
    (function walk(x) {
      if (!x) return;
      if (x.type === 'FeatureCollection') (x.features || []).forEach(walk);
      else if (x.type === 'Feature') walk(x.geometry);
      else if (x.type === 'Polygon') out.push(x.coordinates);
      else if (x.type === 'MultiPolygon') (x.coordinates || []).forEach(function (p) { out.push(p); });
    })(g);
    return out;
  }
  function pip(pt, ring) { var x = pt[0], y = pt[1], ins = false; for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) { var xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1]; if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) ins = !ins; } return ins; }
  function inside(pt, g) { var ps = polysOf(g); for (var i = 0; i < ps.length; i++) { var p = ps[i]; if (p[0] && pip(pt, p[0])) { var hole = false; for (var h = 1; h < p.length; h++) if (pip(pt, p[h])) { hole = true; break; } if (!hole) return true; } } return false; }
  function bboxOf(g) { var b = [180, 90, -180, -90]; polysOf(g).forEach(function (p) { p.forEach(function (r) { r.forEach(function (c) { if (c[0] < b[0]) b[0] = c[0]; if (c[1] < b[1]) b[1] = c[1]; if (c[0] > b[2]) b[2] = c[0]; if (c[1] > b[3]) b[3] = c[1]; }); }); }); return b; }
  function vertexCount(g) { var n = 0; polysOf(g).forEach(function (p) { p.forEach(function (r) { n += r.length; }); }); return n; }
  function readObs(k) { try { return JSON.parse(lsGet(k) || '[]') || []; } catch (e) { return []; } }

  function bordersBody() {
    return '<div class="c"><h3>État du module</h3><span class="st part" id="g360-b-state">PARTIEL</span>' +
      '<p id="g360-b-state-txt"></p><small>Aucune détection de franchissement, aucune caméra ni capteur frontalier n’est raccordé. Le contour est une donnée de référence, sans valeur juridique.</small></div>' +
      '<div class="c"><h3>Contour national (geoBoundaries)</h3><div id="g360-b-meta">Aucun contour chargé.</div>' +
      '<div class="row"><button id="g360-b-load">Charger / actualiser le contour</button><button id="g360-b-clear">Retirer la copie locale</button></div><div id="g360-b-msg" style="margin-top:6px"></div></div>' +
      '<div class="c"><h3>Ma position par rapport au contour</h3><div class="row"><button id="g360-b-pos">Tester ma position GNSS</button></div><div id="g360-b-pos-out" style="margin-top:6px">—</div>' +
      '<small>Résultat indicatif : contour simplifié, limites terrestres uniquement ; la précision du GNSS du téléphone s’applique.</small></div>' +
      '<div class="c"><h3>Signaler une observation frontalière (saisie manuelle)</h3>' +
      '<select id="g360-b-type"><option>Passage ou trace inhabituelle</option><option>Activité suspecte</option><option>Infrastructure / borne</option><option>Autre</option></select>' +
      '<input type="text" id="g360-b-place" placeholder="Lieu ou repère (ex. secteur, village)"><textarea id="g360-b-note" rows="3" placeholder="Description factuelle"></textarea>' +
      '<select id="g360-b-prio"><option value="normal">Information</option><option value="high">Important</option><option value="critical">Critique</option></select>' +
      '<div class="row"><button id="g360-b-save">Enregistrer et transmettre à l’avatar</button></div><small>Saisie humaine, non vérifiée : l’avatar l’annonce comme « à vérifier ».</small><div id="g360-b-list"></div></div>' +
      '<div class="c"><h3>Raccordements encore nécessaires</h3><ul><li>Capteurs / caméras / patrouilles frontalières autorisés (aucun configuré)</li><li>Limites maritimes officielles (ZEE) fournies par l’autorité compétente</li><li>Accord des autorités pour tout usage opérationnel</li></ul></div>';
  }
  renderers.borders = function () {
    loadStoredGeo();
    var m = null; try { m = JSON.parse(lsGet(GEO_META) || 'null'); } catch (e) {}
    $('g360-b-state-txt').textContent = geo ? 'Contour national chargé le ' + when(m && m.at) + ' (source : geoBoundaries).' : 'Aucun contour chargé : chargez-le (réseau requis).';
    $('g360-b-meta').innerHTML = geo && m ? 'Source : ' + esc(m.source) + '<br>Licence : ' + esc(m.license || 'non indiquée') + '<br>Emprise : ' + m.bbox.map(function (x) { return x.toFixed(2); }).join(' · ') + '<br>Polygones : ' + m.polygons + ' · sommets : ' + m.vertices + '<br><small>Chargé le ' + esc(when(m.at)) + '</small>' : 'Aucun contour chargé.';
    drawObs('g360-b-list', OBS_B);
  };
  function drawObs(boxId, key) {
    var l = readObs(key); $(boxId).innerHTML = l.length ? l.slice(0, 15).map(function (o) { return '<div class="rec"><b>' + esc(o.type) + '</b> · ' + esc(when(o.at)) + ' · ' + esc(o.place || '—') + '<br>' + esc(o.note || '') + '<br><small>saisie manuelle · non vérifiée</small></div>'; }).join('') : '<small>Aucune observation enregistrée.</small>';
  }
  function saveObs(key, module, boxId, f) {
    var note = f.note.trim(), place = f.place.trim();
    if (!note && !place) return false;
    var rec = { at: Date.now(), type: f.type, place: place, note: note, priority: f.prio };
    var l = readObs(key); l.unshift(rec); lsSet(key, JSON.stringify(l.slice(0, 100)));
    proactive({ module: module, type: module + '-observation', summary: f.type + (place ? ' — ' + place : '') + (note ? ' : ' + note : ''), source: 'Saisie manuelle', priority: f.prio, verification: 'unverified', klass: 'territorial', action: 'Faire vérifier l’observation par un opérateur' });
    relay(module, 'report-created', { module: module, observation: rec.type, source: 'Saisie manuelle' });
    drawObs(boxId, key);
    return true;
  }
  function wireBorders() {
    $('g360-b-load').onclick = function () {
      var msg = $('g360-b-msg'); msg.textContent = 'Chargement du contour…';
      fetch('https://www.geoboundaries.org/api/current/gbOpen/GAB/ADM0/', { cache: 'no-store' }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }).then(function (j) {
        var meta = Array.isArray(j) ? j[0] : j; var u = meta.simplifiedGeometryGeoJSON || meta.gjDownloadURL; if (!u) throw new Error('adresse du contour absente');
        return fetch(u).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }).then(function (g) { return { meta: meta, g: g }; });
      }).then(function (x) {
        var ps = polysOf(x.g); if (!ps.length) throw new Error('contour vide');
        geo = x.g; var info = { at: Date.now(), source: 'geoBoundaries gbOpen GAB ADM0' + (x.meta.boundaryYearRepresented ? ' (' + x.meta.boundaryYearRepresented + ')' : ''), license: x.meta.boundaryLicense || '', bbox: bboxOf(x.g), polygons: ps.length, vertices: vertexCount(x.g) };
        var okStore = lsSet(GEO_KEY, JSON.stringify(x.g)); lsSet(GEO_META, JSON.stringify(info));
        msg.textContent = 'Contour chargé' + (okStore ? ' et conservé sur l’appareil.' : ' (copie locale impossible : stockage plein).');
        relay('borders', 'source-status', { module: 'borders', status: 'contour-chargé', source: 'geoBoundaries' }); renderers.borders();
      }).catch(function (e) { msg.textContent = 'Service indisponible (' + (e && e.message ? e.message : 'réseau') + ') : aucun contour affiché, rien n’est simulé.'; });
    };
    $('g360-b-clear').onclick = function () { try { localStorage.removeItem(GEO_KEY); localStorage.removeItem(GEO_META); } catch (e) {} geo = null; renderers.borders(); $('g360-b-msg').textContent = 'Copie locale retirée.'; };
    $('g360-b-pos').onclick = function () {
      var out = $('g360-b-pos-out'); if (!geo) { out.textContent = 'Chargez d’abord le contour national.'; return; }
      if (!navigator.geolocation) { out.textContent = 'Géolocalisation absente de ce WebView.'; return; }
      out.textContent = 'Recherche du signal GNSS…';
      navigator.geolocation.getCurrentPosition(function (p) {
        var pt = [p.coords.longitude, p.coords.latitude]; var ins = inside(pt, geo);
        out.innerHTML = 'Position réelle : ' + p.coords.latitude.toFixed(5) + '°, ' + p.coords.longitude.toFixed(5) + '° (±' + Math.round(p.coords.accuracy) + ' m)<br><b>' + (ins ? 'À l’intérieur du contour terrestre national' : 'À l’extérieur du contour terrestre national (ou en mer)') + '</b>';
      }, function (e) { out.textContent = 'GNSS indisponible : ' + (e && e.message ? e.message : 'autorisation ou signal manquant') + '.'; }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
    };
    $('g360-b-save').onclick = function () { var ok = saveObs(OBS_B, 'borders', 'g360-b-list', { type: $('g360-b-type').value, place: $('g360-b-place').value, note: $('g360-b-note').value, prio: $('g360-b-prio').value }); if (ok) { $('g360-b-note').value = ''; $('g360-b-place').value = ''; } else $('g360-b-msg').textContent = 'Renseignez au moins un lieu ou une description.'; };
  }

  /* ================= ESPACE AÉRIEN ================= */
  var OBS_A = 'g360.airspace.obs.v1';
  function airspaceBody() {
    return '<div class="c"><h3>État du module</h3><span class="st wait">EN ATTENTE DE CONFIGURATION</span>' +
      '<p>Aucune source de trafic aérien (ADS-B, radar, NOTAM, zones réglementées) n’est raccordée. Aucune position d’aéronef n’est affichée ni annoncée.</p></div>' +
      '<div class="c"><h3>Raccordements nécessaires</h3><ul><li>Source de trafic autorisée : agrégateur ADS-B public ou commercial, ou données de l’autorité aéronautique (conditions d’usage et accès à vérifier)</li><li>FIR, zones réglementées et NOTAM fournis par l’autorité compétente</li><li>Passerelle côté serveur : les clés d’accès ne sont jamais stockées dans l’application</li><li>Autorisation officielle avant tout usage opérationnel</li></ul></div>' +
      '<div class="c"><h3>Signaler un aéronef ou drone observé (saisie manuelle)</h3>' +
      '<select id="g360-a-type"><option>Aéronef observé</option><option>Drone observé</option><option>Bruit ou survol inhabituel</option><option>Autre</option></select>' +
      '<input type="text" id="g360-a-place" placeholder="Lieu ou repère"><textarea id="g360-a-note" rows="3" placeholder="Description factuelle (direction, altitude estimée, heure)"></textarea>' +
      '<select id="g360-a-prio"><option value="normal">Information</option><option value="high">Important</option><option value="critical">Critique</option></select>' +
      '<div class="row"><button id="g360-a-save">Enregistrer et transmettre à l’avatar</button></div><small>Saisie humaine, non vérifiée : jamais présentée comme une détection.</small><div id="g360-a-msg"></div><div id="g360-a-list"></div></div>';
  }
  renderers.airspace = function () { drawObs('g360-a-list', OBS_A); };
  function wireAirspace() {
    $('g360-a-save').onclick = function () { var ok = saveObs(OBS_A, 'airspace', 'g360-a-list', { type: $('g360-a-type').value, place: $('g360-a-place').value, note: $('g360-a-note').value, prio: $('g360-a-prio').value }); if (ok) { $('g360-a-note').value = ''; $('g360-a-place').value = ''; $('g360-a-msg').textContent = ''; } else $('g360-a-msg').textContent = 'Renseignez au moins un lieu ou une description.'; };
  }

  /* ================= PAIEMENTS ================= */
  function paymentsBody() {
    return '<div class="c"><h3>État du module</h3><span class="st wait">NON CONFIGURÉ — AUCUN ENCAISSEMENT</span>' +
      '<p id="g360-p-state"></p><small>Aucun paiement ne peut être lancé depuis ce build. Aucune offre, aucun prix et aucun abonnement n’est inventé.</small></div>' +
      '<div class="c"><h3>Intégration dans ce build</h3><div id="g360-p-checks"></div></div>' +
      '<div class="c"><h3>Prérequis avant toute activation</h3><ul><li>Choix d’un fournisseur (Google Play Billing ou autre) et création des produits chez lui</li><li>Vérification des achats côté serveur (jamais dans l’application)</li><li>Tests de sécurité : usurpation, rejeu de jeton, remboursement, accès owner seul</li><li>Accord explicite du propriétaire</li></ul></div>' +
      '<div class="c"><h3>Actions</h3><div class="row"><button disabled>Souscrire (indisponible)</button><button id="g360-p-check">Vérifier l’état de l’accès</button></div><div id="g360-p-out" style="margin-top:6px"></div></div>';
  }
  renderers.payments = function () {
    var bridge = (typeof window.G360Billing !== 'undefined') || (typeof window.G360Payment !== 'undefined') || (typeof window.G360PaymentBilling !== 'undefined');
    $('g360-p-state').textContent = bridge ? 'Un pont de paiement est présent, mais aucune vérification serveur n’est configurée : encaissement désactivé.' : 'Aucun pont de paiement détecté dans ce build.';
    $('g360-p-checks').innerHTML = '<div class="rec">Pont Google Play Billing : ' + (bridge ? 'présent' : '<b>absent</b>') + '</div><div class="rec">Serveur de vérification : <b>non configuré</b></div><div class="rec">Produits / offres : <b>aucun</b></div>';
  };
  function wirePayments() { $('g360-p-check').onclick = function () { $('g360-p-out').textContent = 'Aucun serveur de vérification n’est configuré : impossible de confirmer un accès payant.'; }; }

  /* ================= enregistrement dans l'architecture existante ================= */
  function boot() {
    PAGES.borders = mkPage('g360-page-borders', '🧱 Frontières', bordersBody()).id;
    PAGES.airspace = mkPage('g360-page-airspace', '✈️ Espace aérien', airspaceBody()).id;
    PAGES.payments = mkPage('g360-page-payments', '💳 Paiements', paymentsBody()).id;
    wireBorders(); wireAirspace(); wirePayments();
    window.GABON360_OPEN_BORDERS = function () { return openPage('borders'); };
    window.GABON360_OPEN_AIRSPACE = function () { return openPage('airspace'); };
    window.GABON360_OPEN_PAYMENTS = function () { return openPage('payments'); };
    var prevNav = window.GABON360_NAVIGATE;
    window.GABON360_NAVIGATE = function (id) { if (PAGES[id]) { openPage(id); try { relay('avatar', 'ai-navigation', { target: id }); } catch (e) {} return true; } return typeof prevNav === 'function' ? prevNav.apply(this, arguments) : false; };
    var prevCmd = window.GABON360_HANDLE_COMMAND;
    window.GABON360_HANDLE_COMMAND = function (raw) {
      var q = norm(raw), key = /frontiere/.test(q) ? 'borders' : /espace aerien|airspace|aeronef/.test(q) ? 'airspace' : /paiement|abonnement|facturation/.test(q) ? 'payments' : null;
      if (key) { openPage(key); return { ok: true, page: key }; }
      return typeof prevCmd === 'function' ? prevCmd.apply(this, arguments) : { ok: false };
    };
    /* accès : panneau 🔔, commandes vocales (« ouvre la page frontières ») et GABON360_NAVIGATE ; aucune barre ajoutée à l'en-tête existant */
  }
  if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);
})();
