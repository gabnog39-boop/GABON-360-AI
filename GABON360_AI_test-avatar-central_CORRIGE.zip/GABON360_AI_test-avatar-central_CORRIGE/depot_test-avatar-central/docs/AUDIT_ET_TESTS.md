# GABON 360 AI — Audit, correctifs et tests (copie de test V183, branche test-avatar-central)

Date des tests : 19/10/2026. Environnement : Chromium headless 141 (Playwright 1.56), réseau coupé, pont natif Android simulé.
**Limite majeure : l'APK n'a PAS été compilée** (pas de SDK Android, de Gradle ni de réseau dans l'environnement de test). Rien n'a été testé sur un téléphone réel. Le centre n'est donc PAS déclaré opérationnel.

## 1. Constats sur la base V183 (avant mes modifications)
| # | Constat | Effet démontré |
|---|---|---|
| 1 | `index.html` embarque une copie partielle du script (90 fonctions) et ne charge pas `app.js` (121 fonctions) | 31 fonctions appelées par des boutons n'existent pas (runNationalAI, syncWithCenter…) |
| 2 | `syncEventMarkers()` appelée par `renderAll()`, définie nulle part | exception à chaque rendu (41 fois sur 80 clics) |
| 3 | Un `<script src="…leaflet…">` contient 4 Ko de code (bloc patrouilles) : ignoré par le navigateur | `patrolState`, `fusionState`, `infraState` : « before initialization » ; l'injecteur de dédoublonnage supprimait ensuite la copie active |
| 4 | `fieldNav`, `esc`, `fmtNum`, `offlineState`, `renderFieldNav`, `renderOffline`, `saveField`, `queueOffline`, `localAlert` utilisés mais jamais définis | exceptions, navigation terrain et mode hors ligne cassés |
| 5 | Appel d'initialisation exécuté avant les déclarations `let` | script interrompu |
| 6 | `app.js` stocke l'état sous `g360_v171`, la copie inline sous `g360_v172` | risque de perte des données locales lors du changement de script |
| 7 | Relais : un `ai-notification` publié sur `GABON360_AI_RELAY` déclenche une récursion sans fin (241 appels, profondeur 44 mesurés, coupés par la sonde) | gel de la page |
| 8 | Bannière « 26 IA prêtes » et `module-ready` : statiques, indépendants de toute donnée reçue | fausse impression d'activité |
| 9 | `index.html` et `app.js` ne sont pas de la même version (onglet Infrastructure absent d'`app.js`, éléments `fieldLinkStatus/Detail/Queue` absents du HTML) | voir correctifs |
| 10 | Le workflow ne lance pas `inject_payment_billing.py` ; aucune page Frontières / Espace aérien / Paiements | modules absents |

## 2. Fichiers ajoutés ou modifiés (dépôt de test)
Ajoutés : `scripts/inject_v183_base_repair_v1.py`, `scripts/inject_center_focus_fix_v1.py`, `scripts/inject_proactive_speech_v1.py`, `scripts/inject_border_airspace_payments_pages_v1.py`, `scripts/assets/proactive_speech_v1.js`, `scripts/assets/pages_borders_airspace_payments_v1.js`, `appliquer_paquet_correctifs.py` (racine, sécurisé), `tests/*`, `docs/AUDIT_ET_TESTS.md`.
Modifié : `.github/workflows/build-apk.yml` (déclencheurs limités à test-avatar-central ; contrôle de branche avant toute écriture ; permissions en lecture seule ; étapes : déploiement/vérification du paquet, réparation de la base, correctif #g360-focus, pages, parole proactive). Aucun injecteur existant n'est modifié. Rien n'est supprimé.
Sortie de build (non versionnée) : `android_project/app/src/main/assets/index.html` (modifié par les injecteurs), `MainActivity.java` (modifié par les injecteurs existants), `G360NativeBridge.java` (généré par les injecteurs existants).

## 3. Ce qui a été fait
- **Réparation de la base** (`inject_v183_base_repair_v1.py`) : script principal complet (app.js), `syncEventMarkers` (marqueurs réels des événements/alertes ayant des coordonnées), `fieldNav`, huit symboles manquants (implémentations minimales, sans donnée fictive : `localAlert` crée une vraie alerte à vérifier à partir d'une observation de patrouille), ordre d'initialisation, correction de `toFixed` sur coordonnées nulles, corps inerte du script Leaflet retiré, migration unique `g360_v172 → g360_v171`, onglet **Infrastructure rétabli**, trois éléments d'état de liaison ajoutés.
- **Parole proactive** (`proactive_speech_v1.js`) : une seule sortie vocale (`G360AvatarSpeak` → pont natif Android) ; interception des paroles automatiques des autres modules ; file par priorité (critique vérifiée > critique non vérifiée > importante > missions/territoire > résumé groupé) ; déduplication persistante (24 h, fenêtre 15 min critiques / 2 h autres) ; refus des données anciennes, simulées ou restaurées au démarrage ; garde anti-récursion du relais ; réglages (annonces auto, voix coupée, pause/reprise, volume, catégories) ; journal et état réel des 22 modules ; bannière « IA prêtes » remplacée par l'état réel.
- **Pages** Frontières, Espace aérien, Paiements : aucune donnée fictive (voir §6).

## 4. Tests réussis (observés sur le build final, intégré par le workflow rejoué : 50 étapes OK)
- Parole proactive 25/25 : annonce automatique via le relais ; critique vérifiée annoncée avant les secondaires ; secondaires regroupés ; même événement ×6 → 1 annonce ; ré-annonce après expiration ; mémoire persistante ; bouton « Parler » inchangé ; bouton « IA » inchangé ; voix coupée (texte affiché, aucune parole) ; pause/reprise ; volume 0 → silence ; données anciennes/simulées ignorées ; « Simuler événement » jamais annoncé comme réel ; nouvelle mission annoncée ; 2 min sans événement → silence ; service externe absent → aucune fausse annonce.
- Événements 11/11 : mission réelle (bouton de l'application) → `mission-created` au relais → annonce ; alerte réelle → annonce « à vérifier » ; validation → annonce « validée » ; sauvegarde répétée → aucune ré-annonce ; deux événements distincts → 2 événements relais, 1 ms, chacun annoncé une fois ; garde active.
- Non-régression : les 80 boutons de la V183 d'origine existent toujours dans le build final (aucun absent) ; 203 boutons cliqués. Erreurs JS sur le même parcours de 203 clics : **61 (14 types) → 1** (refus du presse-papiers par le navigateur de test, hors défaut de l'application).
- Onglet Infrastructure : présent, 6 boutons cliqués sans erreur (« Tester les serveurs », « Tester météo », « Synchroniser centre », « Enregistrer », « Enregistrer jeton », « Tester »). Leur résultat réel (réseau/serveur) n'est pas testé.
- Éléments de liaison : `fieldLinkStatus/Detail/Queue` renseignés par `refreshFieldLink()`.
- Audit des 22 modules : page ouvrable, boutons cliqués sans exception JS, événement transmis à l'avatar (voir §5).
- Défauts corrigés (tests/test_defects.py, 7/7) : 12 boutons de domaine du Centre national, bouton « OK », message « undefined ».
- Mobile : capture 390×800 : bouton 🔔 au bord droit, sans recouvrir l'en-tête ; comparaison pixel avant/après : seules la zone du bouton et l'horloge diffèrent.

## 5. Les 22 modules
Légende : **OP** = testé et opérationnel en local ; **PART** = partiel ; **ATT** = en attente de source/configuration. « Émet » = le code du module publie lui-même un événement vers le relais (constat statique) ; la colonne « Relais→avatar » = un événement du module, publié via l'API, est reçu et prononcé (testé pour les 22).
| Module | État | Boutons (cliqués, 0 erreur JS) | Émet nativement | Source / dépendance |
|---|---|---|---|---|
| Accueil | OP | 5/5 | non | local |
| Cartographie | PART | 10/12 | oui (coordonnées) | fonds OSM/Esri/UGEO + Leaflet via CDN : **la carte n'a pas été testée en réel** (stub) |
| Satellites | PART | 11/13 | oui (résultats) | Copernicus (métadonnées, pas d'image en direct) ; hors réseau : message honnête testé |
| Drones | ATT | 11/13 | non | aucune passerelle |
| Navigation | PART | 12/14 | non (module terrain V2) | GNSS ; test avec géolocalisation simulée du navigateur seulement |
| Géolocalisation | PART | 5/5 | non | idem |
| Cyber | PART | 9/10 | oui (cyber-ai-alert) | journal local, pas de SOC |
| Mémoire territoriale | OP (local) | 13/15 | oui | registre local |
| Alertes | OP | 12/14 | via surveillance de l'état (nouveau) | état local ; annonce testée |
| Rapports | PART | 10/12 | code oui, **émission non vérifiée** | local |
| Statistiques | PART | 11/13 | non | données locales |
| Météo | PART | 10/12 | oui | Open-Meteo : hors réseau « aucune donnée inventée » testé ; service réel non testé |
| Parcs et biodiversité | PART | 9/11 | non | liste, pas de polygones officiels |
| Eaux et océan | PART | 10/12 | non | météo marine ; pas d'AIS |
| Frontières (nouveau) | PART | 3/6 | oui | contour geoBoundaries à la demande (réseau, **non testé en réel**) ; saisie manuelle → relais → voix testée |
| Espace aérien (nouveau) | ATT | 1/3 | saisie manuelle seulement | aucune source ADS-B/NOTAM |
| Centre national | PART | 11/13 | non | boutons de domaine corrigés et testés (12/12) ; zoom/grille du modèle remplacés par la carte réelle (non testée en réel) |
| Administration | PART | 5/5 | non | contrôle côté client uniquement |
| Utilisateurs | ATT/PART | 12/14 | non | pas de comptes serveur |
| Paiements (nouveau) | ATT | 2/4 | non | aucun encaissement possible |
| Missions et terrain | OP (local) | 5/5 | via surveillance de l'état | testé : mission → relais → voix ; synchronisation serveur non configurée |
| Garmin / GPX | PART | 14/17 | oui (terrain-*) | 17 boutons cliquables ; import/export GPX non testés fonctionnellement |

## 6. Pages nouvelles (état réel)
- **Frontières** : PARTIEL. Contour terrestre geoBoundaries chargé à la demande (copie locale conservée), test « ma position est-elle dans le contour ? » (indicatif, sans valeur juridique), saisie manuelle d'observations (marquées « non vérifiée »). Aucune détection de franchissement, aucune limite maritime. Test de position effectué avec un polygone de test et une position GNSS simulée.
- **Espace aérien** : EN ATTENTE. Aucune position d'aéronef affichée ou annoncée. Saisie manuelle de signalements (non vérifiés).
- **Paiements** : NON CONFIGURÉ. Bouton « Souscrire » désactivé ; état du pont de paiement détecté honnêtement ; prérequis listés. `inject_payment_billing.py` n'est **pas** ajouté au workflow : l'historique git n'est pas fourni, je n'ai pas pu établir pourquoi il en était exclu ; il ajoute une dépendance Google Play Billing, impossible à compiler ici.
Accès : bouton 🔔 → « Autres pages », commande vocale (« ouvre la page frontières »), `GABON360_NAVIGATE('borders'|'airspace'|'payments')`. **Non intégrées au balayage horizontal** (nécessiterait de modifier `inject_horizontal_page_navigation_v1.py`).

## 7. Échecs, défauts restants et limites
1. **Compilation Android non réalisée.** `G360NativeBridge`/`G360AvatarSpeak` : présents et branchés, testés avec un pont simulé ; **pas testés sur Android réel**.
2. **Centre national** : les 12 boutons de domaine lançaient une erreur car `#g360-focus` est supprimé par `inject_real_gabon_map.py` (qui remplace le contenu de la zone carte). **Corrigé** par `inject_center_focus_fix_v1.py` et testé (D1–D3). Les boutons de zoom et la grille du modèle (`#g360-zoom-*`, `#g360-mapgrid`) restent remplacés par la carte réelle : **non corrigé, non testé comme fonction** (la carte réelle n'a pas été testée avec le réseau).
3. Bouton « OK » de la conversation : cause trouvée — dans un attribut `onclick`, `command` est résolu d'abord sur le bouton ; Chrome/WebView récents exposent `HTMLButtonElement.command` (chaîne). **Corrigé** (`window.command()`), plus message « Commande reçue : undefined » corrigé ; testé (D5–D7) dans Chromium 141 ; comportement sur le WebView du téléphone non testé.
4. Presse-papiers (« Partager ») : refusé par le navigateur de test ; comportement Android non testé.
5. La V183 fournie est incohérente (HTML plus ancien que `app.js`). Ma réparation est une reconstitution minimale ; **vérifier avec le vrai historique du dépôt** s'il existe un index.html V183 cohérent.
6. Le badge « CONNECTÉ » reflète l'interface réseau (`navigator.onLine`), pas l'accès réel à internet.
7. **Volume** : le curseur règle le repli navigateur et coupe à 0 % ; le pont natif suit le volume média du téléphone (pas de `setVolume` natif : modifier le Java sans pouvoir le compiler était trop risqué).
8. **Parole en arrière-plan** : application fermée ou en veille, rien n'est prononcé (WebView suspendu ; aucune notification, aucun service de premier plan). Il faudrait des notifications push serveur (ex. FCM) et un service Android — non réalisé.
9. L'interception de la parole distingue « manuelle » (geste de l'utilisateur dans les 8 s) et « automatique » ; une alerte arrivant juste après un clic est lue sans file. Les appels directs à `G360Android.speak` ne sont pas interceptés.
10. Leaflet est chargé depuis un CDN : **sans réseau, aucune carte** ; à embarquer localement pour le terrain.
11. Cartes, satellite, météo, Infrastructure (tests serveurs), GPX : service externe non testé (pas de réseau).

## 8. Services externes encore nécessaires
Réseau + Leaflet local ; Copernicus (déjà utilisé, métadonnées) ; Open-Meteo ; geoBoundaries ; passerelle drones/caméras ; source ADS-B/NOTAM autorisée ; AIS maritime ; fournisseur de paiement + vérification serveur ; serveur GABON 360 (`votre-serveur-gabon360` est un espace réservé) ; comptes utilisateurs côté serveur ; notifications push ; clés d'API côté serveur uniquement (jamais dans l'application).


## 9. Mise à jour — corrections d'intégration et de sécurité
- Le workflow ne se déclenche plus que sur `test-avatar-central` (push) ; le lancement manuel est refusé hors de cette branche par un job conditionnel ET un contrôle explicite exécuté avant le checkout, l'écriture, l'injection et la compilation ; permissions `contents: read`.
- `appliquer_paquet_correctifs.py` (racine) : refuse main/principal/branche inconnue y compris dans GitHub Actions (recoupe GITHUB_REF_NAME, GITHUB_REF, GITHUB_REF_TYPE, événement et branche git) ; valide les chemins et les empreintes du paquet embarqué ; n'écrase jamais un fichier différent ; n'écrit que sous scripts/, tests/, docs/. Tests : `tests/test_appliquer_paquet.py`.
- Les workflows de surveillance (`autonomous-monitoring.yml`, `gabon-autonomous-monitor.yml`) n'ont pas été modifiés : planifiés toutes les 6 h (exécutés par GitHub uniquement depuis la branche par défaut), lecture seule, aucun push ni commit.
