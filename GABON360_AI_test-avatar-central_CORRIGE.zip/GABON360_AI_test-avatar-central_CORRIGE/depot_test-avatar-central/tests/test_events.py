"""Tests demandés : missions/alertes réelles -> relais -> avatar ; deux événements sans récursion ; non-répétition."""
import json, re, sys, os
from playwright.sync_api import sync_playwright
import harness
PATH = sys.argv[1]; OUT = sys.argv[2]
results = []
def check(n, ok, d=''):
    results.append({'test': n, 'ok': bool(ok), 'detail': str(d)[:400]}); print(('PASS ' if ok else 'FAIL ') + n + (' — ' + str(d)[:250] if d else ''))
def native(pg): return pg.evaluate("window.__native.filter(x=>x.t).map(x=>x.t)")
def relay_types(pg): return pg.evaluate("window.GABON360_AI_RELAY.history.map(h=>h.type+':'+((h.data&&h.data.module)||''))")
def idle(pg):
    pg.wait_for_function("Date.now()>window.GABON360_PROACTIVE.status().busyUntil+150", timeout=30000)
def fresh(p):
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 800})
    ctx.route(re.compile(r'^https?://'), lambda r: r.abort())
    ctx.add_init_script(harness.INIT); ctx.add_init_script('window.__G360_PROACTIVE_CFG={warmupMs:300,digestDelayMs:1500};')
    ctx.add_init_script(path=os.path.join(os.path.dirname(harness.__file__), 'leaflet_stub.js'))
    pg = ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file://' + PATH); pg.wait_for_timeout(1200); return b, pg, errs
with sync_playwright() as p:
    b, pg, errs = fresh(p)
    # 1 : mission réelle (bouton « Nouvelle mission » de l'application) -> relais + annonce
    pg.evaluate("window.GABON360_AI_RELAY.history.length=0; window.__native.length=0")
    pg.evaluate("""()=>{const e=[...document.querySelectorAll('button')].find(x=>/Nouvelle mission/.test(x.innerText));e.click()}""")
    pg.wait_for_timeout(600)
    rt = relay_types(pg)
    check('T1 mission réelle enregistrée -> événement « mission-created » transmis au relais', any(t.startswith('mission-created:missions') for t in rt), rt[:6])
    sp = native(pg)
    check('T1b la même mission est annoncée par l’avatar (1 fois)', len(sp) == 1 and 'Nouvelle mission' in sp[0], sp)
    st = pg.evaluate("window.GABON360_PROACTIVE.status().modules.find(m=>m.id==='missions')")
    check('T1c module Missions : état « données reçues »', st['events'] >= 1, st)
    # 3 : même événement jamais ré-annoncé (ré-écriture de l'état sans nouvel élément + rechargement)
    pg.evaluate("window.__native.length=0")
    pg.evaluate("""()=>{const e=[...document.querySelectorAll('button')].find(x=>/Rapports|Centre/.test(x.innerText));if(e)e.click(); localStorage.setItem('g360_v171',localStorage.getItem('g360_v171'))}""")
    pg.wait_for_timeout(800)
    check('T3 sauvegarde répétée de l’état sans nouvel élément : aucune ré-annonce', len(native(pg)) == 0, native(pg))
    # 2 : alerte réelle (chemin patrouille de l'application) puis validation -> annonce « vérifiée »
    idle(pg); pg.evaluate("window.__native.length=0")
    pg.evaluate("localAlert('Observation terrain','Fumée signalée près du village Nzeng','HAUTE')")
    pg.wait_for_timeout(800)
    sp = native(pg)
    check('T2 nouvelle alerte réelle annoncée automatiquement, marquée à vérifier', len(sp) == 1 and 'Fumée' in sp[0] and 'À vérifier' in sp[0], sp)
    # validation humaine : on passe l'alerte en VALIDÉE via la fonction de l'application si elle existe, sinon via l'état
    idle(pg); pg.evaluate("window.__native.length=0")
    done = pg.evaluate("""()=>{const s=JSON.parse(localStorage.getItem('g360_v171'));const a=s.alerts.find(x=>/Fumée/.test(x.title));if(!a)return 'absente';a.status='VALIDÉE';localStorage.setItem('g360_v171',JSON.stringify(s));return 'validée'}""")
    pg.wait_for_timeout(800)
    sp = native(pg)
    check('T2b alerte validée -> annonce « vérifiée » (escalade autorisée)', done == 'validée' and len(sp) == 1 and 'validée' in sp[0].lower(), [done, sp])
    pg.wait_for_timeout(300)
    # 4 : deux événements distincts via le relais, sans récursion
    pg.evaluate("window.GABON360_AI_RELAY.history.length=0; window.__native.length=0")
    n = pg.evaluate("""()=>{let c=0;const f=()=>c++;window.addEventListener('gabon360:ai-relay',f);const t=Date.now();
      window.GABON360_AI_RELAY.publish('forests','ai-notification',{observation:'Braconnage suspecté secteur Nord',severity:'HIGH',source:'Patrouille-2',timestamp:new Date().toISOString()});
      window.GABON360_AI_RELAY.publish('water','ai-notification',{observation:'Niveau d’eau anormal station Est',severity:'HIGH',source:'Station-5',timestamp:new Date().toISOString()});
      window.removeEventListener('gabon360:ai-relay',f);return {events:c,ms:Date.now()-t}}""")
    check('T4 deux événements distincts : transmis sans récursion (≤ 4 événements relais, < 1 s)', n['events'] <= 4 and n['ms'] < 1000, n)
    pg.wait_for_timeout(500); idle(pg); pg.wait_for_timeout(300); idle(pg); pg.wait_for_timeout(300)
    sp = native(pg)
    check('T4b les deux événements sont annoncés une seule fois chacun', len([x for x in sp if 'Braconnage' in x]) == 1 and len([x for x in sp if 'Niveau' in x]) == 1, sp)
    check('T4c garde anti-boucle active', pg.evaluate("window.GABON360_PROACTIVE.status().relayGuard") is True)
    # volume / pause / reprise
    idle(pg); pg.evaluate("window.GABON360_PROACTIVE.pause(); window.__native.length=0")
    pg.evaluate("window.GABON360_PROACTIVE.publish({module:'alerts',type:'ai-notification',summary:'Alerte pendant la pause',source:'Capteur-Z',severity:'CRITICAL',status:'VALIDATED',timestamp:new Date().toISOString()})")
    pg.wait_for_timeout(1500); a = len(native(pg))
    pg.evaluate("window.GABON360_PROACTIVE.resume()"); pg.wait_for_timeout(600); bn = native(pg)
    check('T6 pause puis reprise', a == 0 and len(bn) == 1 and 'pause' in bn[0], [a, bn])
    vol = pg.evaluate("window.GABON360_PROACTIVE.setVolume(0.4); window.GABON360_PROACTIVE.settings().volume")
    check('T6b volume réglable et mémorisé', abs(vol - 0.4) < 1e-9, vol)
    b.close()
json.dump(results, open(OUT, 'w'), ensure_ascii=False, indent=1)
print('TOTAL', len(results), 'échecs', len([r for r in results if not r['ok']]))
