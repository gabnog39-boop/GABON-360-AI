import json,sys,re
from playwright.sync_api import sync_playwright
INIT = """
window.__spoken=[]; window.__native=[];
window.G360Android={speak:function(t){window.__native.push({t:String(t),at:Date.now()})},stopSpeaking:function(){window.__native.push({stop:1})},startListening:function(){},stopListening:function(){}};
try{var _sp=window.speechSynthesis; if(_sp){var o=_sp.speak.bind(_sp); _sp.speak=function(u){window.__spoken.push({t:u.text,vol:u.volume,at:Date.now()}); };}}catch(e){}
"""
def open_page(p, path, offline=True):
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':390,'height':800}, geolocation={'latitude':0.39,'longitude':9.45}, permissions=['geolocation'])
    if offline:
        ctx.route(re.compile(r'^https?://'), lambda r: r.abort())
    ctx.add_init_script(INIT)
    ctx.add_init_script(path=__import__('os').path.join(__import__('os').path.dirname(__file__),'leaflet_stub.js'))
    pg=ctx.new_page()
    logs={'console':[], 'pageerror':[]}
    pg.on('console', lambda m: logs['console'].append((m.type,m.text)) if m.type in ('error','warning') else None)
    pg.on('pageerror', lambda e: logs['pageerror'].append(str(e)))
    pg.goto('file://'+path)
    pg.wait_for_timeout(1500)
    return b,ctx,pg,logs
