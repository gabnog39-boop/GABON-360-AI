// STUB DE TEST UNIQUEMENT (non livré) : remplace Leaflet quand le CDN est inaccessible.
(function(){
  function chain(){ var f=function(){return p}; var p=new Proxy(f,{get:function(t,k){ if(k==='then')return undefined; if(k===Symbol.toPrimitive)return function(){return ''}; if(k==='getBounds')return function(){return {isValid:function(){return false},getCenter:function(){return {lat:-0.65,lng:11.65}}}}; if(k==='getCenter')return function(){return {lat:-0.65,lng:11.65}}; if(k==='getZoom')return function(){return 6}; if(k==='getContainer')return function(){return document.createElement('div')}; if(k==='eachLayer')return function(){return p}; if(k==='hasLayer')return function(){return false}; return p}, apply:function(){return p}, construct:function(){return p}}); return p }
  var L=chain();
  window.L=L;
})();
