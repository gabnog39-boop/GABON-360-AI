import sys,json
from playwright.sync_api import sync_playwright
import harness
with sync_playwright() as p:
    b,ctx,pg,logs=harness.open_page(p,sys.argv[1]); pg.wait_for_timeout(900)
    errs=[]; pg.on('pageerror',lambda e:errs.append((str(e),(getattr(e,'stack','') or '')[:260].replace('\n',' '))))
    o={}
    o['onglet_infra']=pg.evaluate("(()=>{const t=document.querySelector('.tab[data-id=infra]');if(!t)return 'absent';t.click();const s=document.getElementById('infra');return {actif:s.classList.contains('active'),boutons:[...s.querySelectorAll('button')].map(b=>b.innerText.trim().slice(0,30)),texte:s.innerText.slice(0,90).replace(/\\n/g,' ')}})()")
    k=len(errs)
    o['infra_clics']=pg.evaluate("""(()=>{const s=document.getElementById('infra');const r=[];s.querySelectorAll('button').forEach(b=>{try{b.click();r.push('ok')}catch(e){r.push('KO '+e.message)}});return r})()""")
    pg.wait_for_timeout(300); o['infra_erreurs']=[e[0] for e in errs[k:]]
    o['infra_etat_infraState']=pg.evaluate("typeof infraState")
    o['liaison']=pg.evaluate("(()=>{refreshFieldLink();return {status:document.getElementById('fieldLinkStatus').innerText,detail:document.getElementById('fieldLinkDetail').innerText.slice(0,70),queue:document.getElementById('fieldQueue').innerText}})()")
    # erreurs textContent : retrouver l'origine
    errs.clear()
    n=pg.evaluate("document.querySelectorAll('button').length")
    for i in range(n):
        lab=pg.evaluate("(i)=>(document.querySelectorAll('button')[i].innerText||'').trim().slice(0,28)",i); k=len(errs)
        try: pg.evaluate("""(i)=>{const e=document.querySelectorAll('button')[i];const t=(e.innerText||'').toLowerCase();if(!/supprimer|effacer|reset|quitter|réinitialiser/.test(t))e.click()}""",i)
        except Exception: pg.goto('file://'+sys.argv[1]); pg.wait_for_timeout(500)
        pg.wait_for_timeout(40)
        if len(errs)>k: o.setdefault('erreurs_par_bouton',[]).append(lab+' => '+errs[-1][0][:60]+' @ '+errs[-1][1][-110:])
    print(json.dumps(o,ensure_ascii=False,indent=1)[:3800]); b.close()
