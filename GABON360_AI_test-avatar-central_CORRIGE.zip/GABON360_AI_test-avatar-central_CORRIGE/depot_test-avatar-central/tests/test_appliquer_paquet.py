#!/usr/bin/env python3
"""Tests de sécurité de appliquer_paquet_correctifs.py (aucun accès réseau, dépôts git temporaires).
Usage : python3 tests/test_appliquer_paquet.py <chemin/appliquer_paquet_correctifs.py> [resultats.json]
"""
import base64, hashlib, io, json, os, re, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path

SCRIPT = Path(sys.argv[1]).resolve()
OUT = sys.argv[2] if len(sys.argv) > 2 else None
NOM = "appliquer_paquet_correctifs.py"
SRC = SCRIPT.read_text(encoding="utf-8")
results = []

def check(nom, ok, detail=""):
    results.append({"test": nom, "ok": bool(ok), "detail": str(detail)[:300]})
    print(("PASS " if ok else "FAIL ") + nom + ((" — " + str(detail)[:200]) if detail and not ok else ""))

def env_propre(**extra):
    e = {k: v for k, v in os.environ.items() if not k.startswith("GITHUB_")}
    e.update({"GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"})
    e.update(extra)
    return e

def git(cwd, *a):
    subprocess.run(["git", *a], cwd=cwd, check=True, capture_output=True, env=env_propre())

def depot(branche, script_text=None, nom_script=NOM):
    d = Path(tempfile.mkdtemp(prefix="g360t_"))
    git(d, "init", "-q"); git(d, "checkout", "-q", "-b", "init-tmp")
    (d / ".github" / "workflows").mkdir(parents=True)
    (d / ".github" / "workflows" / "build-apk.yml").write_text("name: x\n")
    (d / "index.html").write_text("<html>ne pas toucher</html>")
    (d / "README.md").write_text("readme")
    (d / nom_script).write_text(script_text if script_text is not None else SRC, encoding="utf-8")
    git(d, "add", "-A"); git(d, "commit", "-q", "-m", "init")
    if branche:
        git(d, "checkout", "-q", "-B", branche)
    return d

def snapshot(d):
    s = {}
    for p in sorted(Path(d).rglob("*")):
        if ".git" in p.relative_to(d).parts: continue
        if p.is_file() and not p.is_symlink(): s[p.relative_to(d).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
        else: s[p.relative_to(d).as_posix()] = "dir/lien"
    return s

def lancer(d, args=(), env=None, nom_script=NOM, cwd=None):
    p = subprocess.run([sys.executable, nom_script, *args], cwd=str(cwd or d), capture_output=True, text=True, env=env or env_propre(), timeout=120)
    return p.returncode, p.stdout, p.stderr

def ci_env(nom="test-avatar-central", **kw):
    e = {"GITHUB_ACTIONS": "true", "GITHUB_EVENT_NAME": "push", "GITHUB_REF_TYPE": "branch", "GITHUB_REF_NAME": nom, "GITHUB_REF": "refs/heads/" + nom}
    e.update(kw)
    return env_propre(**e)

def refus(nom, d, rc_attendu, code, args=(), env=None, motif=None, **kw):
    avant = snapshot(d)
    rc, out, err = lancer(d, args, env, **kw)
    apres = snapshot(d)
    ok = rc == rc_attendu and avant == apres and (motif is None or motif in (err + out))
    check(nom, ok, "code=%s attendu=%s ; modifié=%s ; stderr=%s" % (rc, rc_attendu, avant != apres, err.strip()[:120]))
    return ok

# ---------- A. Branches (local) ----------
for b, motif in (("main", "branche protégée"), ("principal", "branche protégée"), ("master", "branche protégée"), ("feature-x", "différente"), ("test-avatar-central-2", "différente"), ("Test-Avatar-Central", "différente")):
    d = depot(b); refus("A. local, branche '%s' : refus, aucun fichier écrit" % b, d, 2, 2, motif=motif)
d = depot(None); git(d, "checkout", "-q", "--detach"); refus("A. local, HEAD détaché (branche inconnue) : refus", d, 2, 2, motif="branche inconnue")
d = depot("test-avatar-central"); shutil.rmtree(d / ".git"); refus("A. hors dépôt git : refus", d, 3, 3)

# ---------- B. GitHub Actions ----------
d = depot("main"); refus("B. CI, GITHUB_REF_NAME=main : refus", d, 2, 2, env=ci_env("main"), motif="protégée")
d = depot("principal"); refus("B. CI, GITHUB_REF_NAME=principal : refus", d, 2, 2, env=ci_env("principal"), motif="protégée")
d = depot("main"); refus("B. CI usurpée (REF_NAME=test-avatar-central mais git sur main) : refus", d, 2, 2, env=ci_env("test-avatar-central"), motif="protégée")
d = depot("test-avatar-central"); refus("B. CI usurpée (REF_NAME=main mais git sur test-avatar-central) : refus", d, 2, 2, env=ci_env("main"))
d = depot("test-avatar-central"); refus("B. CI, REF_NAME vide : refus", d, 2, 2, env=ci_env("", GITHUB_REF=""), motif="vide")
d = depot("test-avatar-central"); refus("B. CI, type de ref = tag : refus", d, 2, 2, env=ci_env(GITHUB_REF_TYPE="tag"), motif="GITHUB_REF_TYPE")
d = depot("test-avatar-central"); refus("B. CI, GITHUB_REF incohérent : refus", d, 2, 2, env=ci_env(GITHUB_REF="refs/heads/main"), motif="incohérent")
d = depot("test-avatar-central"); refus("B. CI, pull_request : refus", d, 2, 2, env=ci_env(GITHUB_EVENT_NAME="pull_request"), motif="pull request")
d = depot("test-avatar-central"); refus("B. CI, GITHUB_BASE_REF=main : refus", d, 2, 2, env=ci_env(GITHUB_BASE_REF="main"), motif="protégée")
d = depot("test-avatar-central"); refus("B. CI, drapeau d'écrasement interdit : refus", d, 3, 3, args=("--ecraser-fichiers-du-paquet",), env=ci_env(), motif="interdit dans GitHub Actions")
d = depot("detached-ci"); git(d, "checkout", "-q", "--detach")
rc, out, err = lancer(d, env=ci_env())
check("B. CI autorisée (test-avatar-central, HEAD détaché par le checkout) : exécution OK", rc == 0, err[:150])

# ---------- C. Cas autorisé ----------
d = depot("test-avatar-central"); av = snapshot(d)
rc, out, err = lancer(d, ("--a-blanc",))
check("C. à blanc sur test-avatar-central : plan affiché, rien écrit", rc == 0 and snapshot(d) == av and "créer" in out, err[:150])
rc, out, err = lancer(d)
ap = snapshot(d); nouveaux = sorted(set(ap) - set(av))
modifies = [k for k in av if av[k] != ap.get(k)]
check("C. local test-avatar-central : fichiers créés, aucun fichier existant modifié", rc == 0 and nouveaux and not modifies, "modifiés=%s ; err=%s" % (modifies, err[:120]))
check("C. seuls scripts/, tests/, docs/ sont touchés (.github, index.html, README intacts)", all(n.startswith(("scripts", "tests", "docs")) for n in nouveaux), nouveaux[:5])
rc2, out2, err2 = lancer(d)
check("C. relance : idempotent (0 créé, tout inchangé)", rc2 == 0 and "0 créé(s)" in out2, out2[-160:])
check("C. aucun fichier .tmp-g360 ni .bak résiduel", not [k for k in snapshot(d) if ".tmp-g360" in k or ".bak-" in k])

# ---------- D. Conflits / écrasement ----------
d = depot("test-avatar-central"); lancer(d)
cible = d / "scripts" / "inject_proactive_speech_v1.py"; cible.write_text("# version locale différente\n")
av = snapshot(d); rc, out, err = lancer(d)
check("D. fichier existant différent : CONFLIT, rien écrasé", rc == 4 and snapshot(d) == av and "CONFLIT" in err and "inject_proactive_speech_v1.py" in err, err[:150])
d2 = depot("test-avatar-central"); (d2 / "scripts").mkdir(); (d2 / "scripts" / "inject_proactive_speech_v1.py").write_text("x")
rc, out, err = lancer(d2)
check("D. conflit détecté AVANT toute écriture (aucun fichier créé)", rc == 4 and not (d2 / "tests").exists() and not (d2 / "docs").exists(), err[:100])
rc, out, err = lancer(d, ("--ecraser-fichiers-du-paquet",))
baks = [k for k in snapshot(d) if ".bak-" in k]
check("D. écrasement explicite (local) : sauvegarde .bak créée avant remplacement", rc == 0 and len(baks) == 1 and (d / baks[0]).read_text() == "# version locale différente\n", baks)
d = depot("main"); rc, out, err = lancer(d, ("--ecraser-fichiers-du-paquet",))
check("D. --ecraser sur main : refus de branche malgré le drapeau", rc == 2)
d3 = depot("test-avatar-central"); (d3 / "scripts").mkdir(); (d3 / "scripts" / "inject_proactive_speech_v1.py").mkdir()
refus("D. destination = dossier : refus", d3, 3, 3, motif="n'est pas un fichier")

# ---------- E. Emplacement / nom ----------
d = depot("test-avatar-central", nom_script="appliquer_paquet_correctifs (1).py")
refus("E. script nommé « … (1).py » : refus avec message clair", d, 3, 3, nom_script="appliquer_paquet_correctifs (1).py", motif="s'appeler exactement")
d = depot("test-avatar-central"); sous = d / "sous"; sous.mkdir()
refus("E. lancé depuis un autre dossier : refus", d, 3, 3, cwd=sous, motif="racine du dépôt") if False else None
rc, out, err = lancer(d, cwd=sous, nom_script=str(d / NOM)); check("E. lancé depuis un autre dossier : refus, rien écrit", rc == 3 and "racine du dépôt" in err and not (d / "scripts").exists(), err[:120])

# ---------- F. Paquets malveillants (script reconstruit avec une charge piégée) ----------
def variante(entrees, manifest=None, modif_sha=False):
    """entrees : liste de (ZipInfo|str, bytes). Reconstruit le script avec cette charge et son manifeste."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for info, data in entrees:
            z.writestr(info, data)
    brut = buf.getvalue()
    man = manifest if manifest is not None else {(i.filename if isinstance(i, zipfile.ZipInfo) else i): hashlib.sha256(d_).hexdigest() for i, d_ in entrees}
    b64 = base64.b64encode(brut).decode()
    txt = re.sub(r"MANIFEST = json\.loads\(r'''.*?'''\)", lambda m: "MANIFEST = json.loads(r'''%s''')" % json.dumps(man), SRC, count=1, flags=re.S)
    sha = hashlib.sha256(brut).hexdigest()
    if modif_sha: sha = "0" * 64
    txt = re.sub(r'PAYLOAD_SHA256 = "[0-9a-f]*"', lambda m: 'PAYLOAD_SHA256 = "%s"' % sha, txt, count=1)
    txt = re.sub(r'PAYLOAD = """.*?"""', lambda m: 'PAYLOAD = """\n%s\n"""' % b64, txt, count=1, flags=re.S)
    return txt

def piege(nom, entrees, motif, code=3, **kw):
    d = depot("test-avatar-central", script_text=variante(entrees, **kw))
    exterieur = Path(tempfile.gettempdir()) / "g360_evil.txt"
    if exterieur.exists(): exterieur.unlink()
    avant = snapshot(d); rc, out, err = lancer(d)
    ok = rc == code and snapshot(d) == avant and not exterieur.exists() and (motif in err)
    check("F. " + nom, ok, "code=%s ; modifié=%s ; stderr=%s" % (rc, snapshot(d) != avant, err.strip()[:140]))

ok_entree = ("scripts/ok.py", b"print('ok')\n")
piege("chemin '../g360_evil.txt'", [("../g360_evil.txt", b"x")], "composant interdit")
piege("chemin 'scripts/../../g360_evil.txt'", [("scripts/../../g360_evil.txt", b"x")], "composant interdit")
piege("chemin absolu '/tmp/g360_evil.txt'", [("/tmp/g360_evil.txt", b"x")], "dangereux")
piege("chemin Windows 'scripts\\..\\g360_evil.txt'", [("scripts\\..\\g360_evil.txt", b"x")], "dangereux")
piege("chemin avec lecteur 'C:/evil'", [("C:/evil.txt", b"x")], "dangereux")
piege("chemin '~/evil'", [("~/evil.txt", b"x")], "dangereux")
piege("chemin hors dossiers autorisés '.github/workflows/evil.yml'", [(".github/workflows/evil.yml", b"x")], "hors des dossiers autorisés")
piege("chemin 'index.html' (l'application)", [("index.html", b"x")], "hors des dossiers autorisés")
piege("chemin 'android_project/app/src/main/AndroidManifest.xml'", [("android_project/app/src/main/AndroidManifest.xml", b"x")], "hors des dossiers autorisés")
piege("chemin non normalisé 'scripts//a.py'", [("scripts//a.py", b"x")], "composant interdit")
piege("chemin 'scripts/./a.py'", [("scripts/./a.py", b"x")], "composant interdit")
li = zipfile.ZipInfo("scripts/lien"); li.external_attr = (0o120777 << 16)
piege("lien symbolique dans l'archive", [(li, b"/etc/passwd")], "entrée spéciale")
piege("entrée de dossier (nom finissant par /)", [("scripts/assets/", b"")], "interdit")
piege("fichier absent du manifeste", [ok_entree, ("scripts/extra.py", b"x")], "non prévu au manifeste", manifest={"scripts/ok.py": hashlib.sha256(ok_entree[1]).hexdigest()})
piege("manifeste annonçant un fichier absent", [ok_entree], "absents du paquet", manifest={"scripts/ok.py": hashlib.sha256(ok_entree[1]).hexdigest(), "scripts/fantome.py": "0" * 64})
piege("empreinte du fichier incorrecte", [ok_entree], "empreinte SHA-256 incorrecte", manifest={"scripts/ok.py": "0" * 64})
piege("empreinte globale du paquet incorrecte", [ok_entree], "intégrité", modif_sha=True)
import warnings
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    piege("entrée en double", [ok_entree, ok_entree], "double")
# base64 corrompu
d = depot("test-avatar-central", script_text=re.sub(r'PAYLOAD = """\n', 'PAYLOAD = """\n!!', SRC, count=1))
refus("F. base64 invalide : refus", d, 3, 3, motif="illisible")
# script modifié (un octet du paquet changé) -> SHA global
m = re.search(r'PAYLOAD = """\n(.{40})', SRC, re.S)
alt = SRC.replace(m.group(1), m.group(1)[:20] + ("A" if m.group(1)[20] != "A" else "B") + m.group(1)[21:], 1)
d = depot("test-avatar-central", script_text=alt); avant = snapshot(d); rc, out, err = lancer(d)
check("F. paquet altéré d'un caractère : refus (intégrité ou archive invalide), rien écrit", rc == 3 and snapshot(d) == avant, err[:120])

# ---------- G. Liens symboliques côté dépôt ----------
d = depot("test-avatar-central"); ext = Path(tempfile.mkdtemp(prefix="g360_ext_")); os.symlink(str(ext), str(d / "scripts"))
rc, out, err = lancer(d)
check("G. dossier scripts/ = lien symbolique vers l'extérieur : refus, rien écrit à l'extérieur", rc == 3 and not any(ext.iterdir()) and ("lien symbolique" in err or "sortirait du dépôt" in err), err[:120])
d = depot("test-avatar-central"); (d / "scripts").mkdir(); ext2 = Path(tempfile.mkdtemp(prefix="g360_ext_"))
(ext2 / "cible.py").write_text("secret"); os.symlink(str(ext2 / "cible.py"), str(d / "scripts" / "inject_proactive_speech_v1.py"))
rc, out, err = lancer(d)
check("G. fichier de destination = lien symbolique : refus, cible externe intacte", rc == 3 and (ext2 / "cible.py").read_text() == "secret", err[:120])

fails = [r for r in results if not r["ok"]]
print("\nTOTAL", len(results), "échecs", len(fails))
if OUT: json.dump(results, open(OUT, "w"), ensure_ascii=False, indent=1)
sys.exit(1 if fails else 0)
