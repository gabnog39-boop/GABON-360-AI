# Tests Playwright (Chromium headless)

Prérequis : `pip install playwright pillow && playwright install chromium`.
Le réseau est coupé pendant les tests ; Leaflet est remplacé par un stub (`leaflet_stub.js`, test uniquement).
Le pont Android natif (`G360Android.speak`) est simulé et enregistre les phrases prononcées.

    python3 tests/test_proactive.py  <index.html final> resultats-proactif.json
    python3 tests/test_events.py     <index.html final> resultats-events.json
    python3 tests/audit_modules.py   <index.html final> audit22.json
    python3 tests/test_nonregression.py <index.html V183 d'origine> <index.html final> nonreg.json

`<index.html final>` = `android_project/app/src/main/assets/index.html` après toutes les étapes d'injection.

    python3 tests/test_defects.py <index.html final> resultats-defauts.json
    python3 tests/test_appliquer_paquet.py appliquer_paquet_correctifs.py resultats-securite.json   # dépôts git temporaires, sans réseau
