"""Tests des deux défauts corrigés : Centre national (domaines) et bouton « OK » de la conversation."""
import json, sys
from playwright.sync_api import sync_playwright
import harness
PATH, OUT = sys.argv[1], sys.argv[2]
res = []
def check(n, ok, d=''):
    res.append({'test': n, 'ok': bool(ok), 'detail': str(d)[:300]}); print(('PASS ' if ok else 'FAIL ') + n + (' — ' + str(d)[:200] if d else ''))
with sync_playwright() as p:
    b, ctx, pg, logs = harness.open_page(p, PATH); pg.wait_for_timeout(900)
    pg.evaluate("window.__e=[];window.addEventListener('error',e=>window.__e.push(e.message))")
    # Centre national : chaque bouton de domaine
    doms = pg.evaluate("[...document.querySelectorAll('#g360-center button.domain')].map(b=>b.dataset.domain)")
    check('D1 12 boutons de domaine présents', len(doms) == 12, len(doms))
    bad = []
    for i, d in enumerate(doms):
        pg.evaluate("window.__e.length=0")
        pg.evaluate("(i)=>document.querySelectorAll('#g360-center button.domain')[i].click()", i)
        pg.wait_for_timeout(60)
        foc = pg.evaluate("document.getElementById('g360-focus')&&document.getElementById('g360-focus').textContent")
        errs = pg.evaluate("window.__e")
        title = pg.evaluate("(document.getElementById('g360-modal-title')||{}).textContent")
        if errs or not foc or d not in foc or d not in (title or ''): bad.append([d, errs, foc, title])
        pg.evaluate("document.getElementById('g360-modal-close')&&document.getElementById('g360-modal-close').click()")
    check('D2 chaque domaine : aucune erreur JS, domaine actif affiché et fenêtre du domaine ouverte', not bad, bad[:2])
    # autres boutons du Centre national (hors zoom, remplacé par la carte réelle)
    pg.evaluate("window.__e.length=0")
    for bid in ['g360-refresh', 'g360-events', 'g360-reports', 'g360-ai']:
        pg.evaluate("(id)=>{const e=document.getElementById(id);if(e)e.click()}", bid); pg.wait_for_timeout(60)
        pg.evaluate("document.getElementById('g360-modal-close')&&document.getElementById('g360-modal-close').click()")
    check('D3 Rafraîchir / Événements / Rapports / Assistant : aucune erreur JS', pg.evaluate("window.__e") == [], pg.evaluate("window.__e"))
    ids = pg.evaluate("['g360-zoom-in','g360-zoom-out','g360-zoom-reset','g360-mapgrid'].map(i=>i+':'+!!document.getElementById(i))")
    res.append({'test': 'D4 INFO (limite non corrigée, non comptée) : zoom/grille du modèle remplacés par la carte réelle', 'ok': None, 'detail': str(ids)}); print('INFO D4 limite non corrigée : zoom/grille du modèle remplacés par la carte réelle', ids)
    # Bouton OK de la conversation
    pg.evaluate("window.__e.length=0; window.__spoken.length=0; window.__native.length=0")
    pg.evaluate("document.getElementById('cmd').value='météo'; [...document.querySelectorAll('button')].find(b=>b.innerText.trim()==='OK').click()")
    pg.wait_for_timeout(600)
    errs = pg.evaluate("window.__e")
    out_txt = pg.evaluate("(document.getElementById('answer')||document.getElementById('reply')||{}).innerText||''")
    sp = pg.evaluate("window.__spoken.map(x=>x.t).concat(window.__native.filter(x=>x.t).map(x=>x.t))")
    check('D5 bouton OK : plus d’erreur « command is not a function »', not any('command' in e for e in errs), errs)
    check('D6 bouton OK : la commande saisie est prononcée sans « undefined »', bool(sp) and 'météo' in sp[0] and 'undefined' not in sp[0], [out_txt[:80], sp[:1]])
    # le champ vocal par Entrée / appel direct restent fonctionnels
    pg.evaluate("window.__e.length=0; window.__spoken.length=0")
    pg.evaluate("window.command('aide')"); pg.wait_for_timeout(300)
    check('D7 appel direct window.command() toujours fonctionnel', pg.evaluate("window.__e") == [], pg.evaluate("window.__e"))
    check('D8 aucune erreur de page pendant ces tests', not logs['pageerror'], logs['pageerror'][:2])
    b.close()
json.dump(res, open(OUT, 'w'), ensure_ascii=False, indent=1)
print('TOTAL', len([r for r in res if r['ok'] is not None]), 'échecs', len([r for r in res if r['ok'] is False]))
