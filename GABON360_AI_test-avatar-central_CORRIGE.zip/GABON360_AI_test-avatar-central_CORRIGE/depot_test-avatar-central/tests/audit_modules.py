"""Audit individuel des 22 modules : page, boutons, source de données, relais, voix. Résultats observés, pas déduits du code."""
import json, re, sys, os
from playwright.sync_api import sync_playwright
import harness
PATH = sys.argv[1]; OUT = sys.argv[2]

MODS = [
 # id, libellé, ouverture JS, clé relais/proactive, source de données (constat code), dépendances
 ('home','Accueil',"window.GABON360_PAGE_NAVIGATION.go('avatar')",['avatar'],'Local (avatar, état de l’application)','Aucune'),
 ('map','Cartographie',"window.GABON360_PAGE_NAVIGATION.go('map')",['map','sig'],'Fonds OSM / Esri / UGEO (réseau)','Réseau ; Leaflet via CDN unpkg'),
 ('sat','Satellites',"window.GABON360_PAGE_NAVIGATION.go('sat')",['sat','satellite'],'Catalogue Copernicus STAC (métadonnées)','Réseau ; pas d’imagerie en direct'),
 ('drones','Drones',"window.GABON360_PAGE_NAVIGATION.go('drones')",['drones'],'Aucune source raccordée','Passerelle drone + autorisation'),
 ('nav','Navigation',"window.GABON360_PAGE_NAVIGATION.go('nav')",['nav','navigation'],'GNSS du téléphone','Permission localisation'),
 ('geo','Géolocalisation',"document.getElementById('g360-terrain-v2-open').click()",['geo','nav'],'GNSS du téléphone','Permission localisation'),
 ('cyber','Cyber',"window.GABON360_OPEN_CYBERSECURITY()",['security','cyber'],'Journal local de l’appareil','Aucun SOC/SIEM raccordé'),
 ('memory','Mémoire territoriale',"window.GABON360_PAGE_NAVIGATION.go('memory')",['memory'],'Registre local (localStorage)','Aucune'),
 ('alerts','Alertes',"window.GABON360_PAGE_NAVIGATION.go('alerts')",['alerts'],'État local de l’application','Aucune'),
 ('reports','Rapports',"window.GABON360_PAGE_NAVIGATION.go('reports')",['reports'],'État local de l’application','Aucune'),
 ('stats','Statistiques',"window.GABON360_PAGE_NAVIGATION.go('stats')",['stats'],'Calculs sur données locales','Aucune'),
 ('weather','Météo',"window.GABON360_PAGE_NAVIGATION.go('weather')",['weather'],'Open-Meteo (réseau)','Réseau'),
 ('forests','Parcs et biodiversité',"window.GABON360_PAGE_NAVIGATION.go('forests')",['forests'],'Liste des 13 parcs (texte) + observations locales','Polygones officiels à importer'),
 ('water','Eaux et océan',"window.GABON360_PAGE_NAVIGATION.go('maritime')",['maritime','water'],'Open-Meteo marine (réseau) ; couches eau UGEO','AIS/navires non raccordés'),
 ('borders','Frontières',"window.GABON360_NAVIGATE('borders')",['borders'],'geoBoundaries (réseau, à la demande)','Réseau ; pas de détection de franchissement'),
 ('airspace','Espace aérien',"window.GABON360_NAVIGATE('airspace')",['airspace'],'Aucune (saisie manuelle uniquement)','Source ADS-B/NOTAM + autorisation'),
 ('center','Centre national de situation',"document.getElementById('g360-pages-open').click()",['center','sources','orchestrator'],'Agrège les modules ci-dessus','Dépend des modules'),
 ('admin','Administration',"[...document.querySelectorAll('button')].find(b=>/OWNER/.test(b.innerText)).click()",['admin','governance'],'Contrôle OWNER local','Pas d’authentification serveur'),
 ('users','Utilisateurs',"window.GABON360_PAGE_NAVIGATION.go('security')",['users','access'],'Rôles locaux (liste déroulante)','Pas de comptes serveur'),
 ('payments','Paiements',"window.GABON360_NAVIGATE('payments')",['payments'],'Aucune','Fournisseur + serveur de vérification'),
 ('missions','Missions et terrain',"[...document.querySelectorAll('button')].find(b=>/Missions/.test(b.innerText)).click()",['missions'],'État local (missions, patrouilles)','Aucune ; sync serveur non configurée'),
 ('garmin','Garmin et échange GPX',"document.getElementById('g360-garmin-open').click()",['garmin','gpx'],'Import/export de fichiers GPX (local)','Pas de Garmin Connect'),
]
TOP = """()=>{let best=null,bz=-1;document.querySelectorAll('div,section,main').forEach(e=>{const s=getComputedStyle(e);if(s.position!=='fixed'||s.display==='none'||s.visibility==='hidden')return;const r=e.getBoundingClientRect();if(r.width*r.height<0.45*innerWidth*innerHeight)return;if((e.innerText||'').trim().length<30)return;const z=parseInt(s.zIndex)||0;if(z>=bz){bz=z;best=e}});document.querySelectorAll('[data-audit-top]').forEach(e=>e.removeAttribute('data-audit-top'));if(best){best.setAttribute('data-audit-top','1');return {id:best.id,len:(best.innerText||'').length,text:(best.innerText||'').replace(/\\s+/g,' ').slice(0,140)}}return null}"""
res = []
with sync_playwright() as p:
    for mid, label, open_js, keys, source, deps in MODS:
        b, ctx, pg, logs = harness.open_page(p, PATH); pg.wait_for_timeout(700)
        row = {'id': mid, 'module': label, 'source': source, 'dependances': deps}
        try:
            pg.evaluate("window.__native.length=0")
            pg.evaluate("()=>{" + open_js + "}") if not open_js.startswith('window.GABON360_PAGE_NAVIGATION') and not open_js.startswith('window.GABON360_OPEN') and not open_js.startswith('window.GABON360_NAVIGATE') else pg.evaluate("()=>{" + open_js + ";return true}")
            pg.wait_for_timeout(500)
            row['ouverte'] = True
        except Exception as e:
            row['ouverte'] = False; row['erreur_ouverture'] = str(e)[:140]
        top = pg.evaluate(TOP) if row['ouverte'] else None
        row['page_visible'] = bool(top); row['page_id'] = top and top['id']; row['extrait'] = top and top['text']
        n0 = len(logs['pageerror'])
        btns = pg.evaluate("""()=>{const r=document.querySelector('[data-audit-top]')||document.body;return [...r.querySelectorAll('button')].filter(e=>e.offsetParent!==null||getComputedStyle(e).position==='fixed').map(e=>(e.innerText||'').trim().slice(0,28))}""")
        row['boutons'] = len(btns)
        clicked = 0; errs_by = []
        for i in range(len(btns)):
            t = btns[i]
            if re.search(r'✕|Fermer|×|Retour|← |Supprimer|Effacer|Réinitial|Retirer|Quitter', t): continue
            k = len(logs['pageerror'])
            try:
                pg.evaluate("""(i)=>{const r=document.querySelector('[data-audit-top]')||document.body;const bs=[...r.querySelectorAll('button')].filter(e=>e.offsetParent!==null||getComputedStyle(e).position==='fixed');if(bs[i])bs[i].click()}""", i)
                clicked += 1
            except Exception as e:
                errs_by.append('navigation: ' + t); break
            pg.wait_for_timeout(120)
            if len(logs['pageerror']) > k: errs_by.append(t + ' -> ' + logs['pageerror'][-1][:70])
        row['boutons_cliques'] = clicked; row['erreurs_js_boutons'] = errs_by
        # relais -> avatar : un événement réel du module est-il enregistré et prononcé ?
        pg.evaluate("window.__native.length=0")
        mod = keys[0]
        ok = pg.evaluate("""(m)=>{window.GABON360_PROACTIVE.publish({module:m,type:'ai-notification',summary:'Contrôle de liaison du module '+m,source:'Audit-liaison',severity:'HIGH',timestamp:new Date().toISOString()});return true}""", mod)
        pg.wait_for_timeout(600)
        spoken = pg.evaluate("window.__native.filter(x=>x.t).map(x=>x.t)")
        st = pg.evaluate("(id)=>window.GABON360_PROACTIVE.status().modules.find(m=>m.id===id)", mid)
        row['relais_vers_avatar'] = bool(spoken) and any('Contrôle de liaison' in s for s in spoken)
        row['relais_enregistre'] = st['events'] >= 1
        row['erreurs_page_totales'] = len(logs['pageerror'])
        res.append(row); print(mid, row['ouverte'], row['page_visible'], row['boutons'], clicked, row['relais_vers_avatar'], len(errs_by))
        b.close()
json.dump(res, open(OUT, 'w'), ensure_ascii=False, indent=1)
