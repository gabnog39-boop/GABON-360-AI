"""Tests F1..F8 de la parole proactive (Chromium headless, horloge simulée, pont natif simulé)."""
import json, re, sys, os
from playwright.sync_api import sync_playwright
import harness

PATH = sys.argv[1]
OUT = sys.argv[2] if len(sys.argv) > 2 else '/home/claude/sim/results-proactif.json'
results = []
def check(name, ok, detail=''):
    results.append({'test': name, 'ok': bool(ok), 'detail': str(detail)[:300]})
    print(('PASS ' if ok else 'FAIL ') + name + (' — ' + str(detail)[:200] if detail else ''))

def fresh(p, offline=True):
    b = p.chromium.launch()
    ctx = b.new_context(viewport={'width': 390, 'height': 800})
    if offline: ctx.route(re.compile(r'^https?://'), lambda r: r.abort())
    ctx.add_init_script(harness.INIT)
    ctx.add_init_script('window.__G360_PROACTIVE_CFG={warmupMs:300,digestDelayMs:1500};')
    ctx.add_init_script(path=os.path.join(os.path.dirname(harness.__file__), 'leaflet_stub.js'))
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file://' + PATH)
    pg.wait_for_timeout(1200)       # dépasse la phase de démarrage réglée à 0,3 s pour les tests
    return b, pg, errs

def native(pg): return pg.evaluate("window.__native.filter(x=>x.t).map(x=>x.t)")
def reset(pg): pg.evaluate("window.__native.length=0;window.__spoken.length=0")
def iso(): return "new Date().toISOString()"
def pub(pg, **kw):
    kw.setdefault('timestamp', None)
    return pg.evaluate("(o)=>{if(!o.timestamp)o.timestamp=new Date().toISOString();return !!window.GABON360_PROACTIVE.publish(o)}", kw)

with sync_playwright() as p:
    # ---------- F1 : une IA produit un résultat, l'avatar le prononce sans clic ----------
    b, pg, errs = fresh(p)
    check('F0 module chargé', pg.evaluate("typeof window.GABON360_PROACTIVE==='object' && !!document.getElementById('g360-pro-btn')"))
    reset(pg)
    pg.evaluate("window.GABON360_AI_RELAY.publish('alerts','ai-notification',{observation:'Feu de brousse signalé dans la zone Alpha',severity:'CRITICAL',source:'Capteur-A',status:'AI_DETECTED',timestamp:new Date().toISOString()})")
    pg.wait_for_timeout(500)
    sp = native(pg)
    check('F1 résultat IA via relais prononcé automatiquement (1 seule fois)', len(sp) == 1 and 'Feu de brousse' in sp[0], sp)
    check('F1b annonce non vérifiée signalée comme telle', len(sp) == 1 and 'non encore vérifiée' in sp[0] and 'Validation humaine requise' in sp[0], sp[:1])
    check('F1c aucune parole directe hors avatar (speechSynthesis non utilisé en parallèle)', pg.evaluate("window.__spoken.length")==0)

    # ---------- F2 : priorité ----------
    reset(pg)
    pg.evaluate("window.GABON360_PROACTIVE._test.ageSeen(0)")
    pub(pg, module='weather', type='ai-notification', summary='Pluie légère prévue demain', source='Open-Meteo', severity='INFO')
    pub(pg, module='forests', type='ai-notification', summary='Observation de faune à valider', source='Patrouille-1', severity='INFO')
    pub(pg, module='alerts', type='ai-notification', summary='Incendie confirmé secteur Bravo', source='Capteur-B', severity='CRITICAL', status='VALIDATED')
    pg.wait_for_timeout(500)
    sp = native(pg)
    check('F2 alerte critique vérifiée annoncée en premier, avant les secondaires', len(sp) == 1 and 'Alerte critique vérifiée' in sp[0], sp)
    pg.wait_for_timeout(7000)
    sp = native(pg)
    check('F2b informations secondaires regroupées en un résumé unique', len(sp) == 2 and 'informations secondaires' in sp[1] and 'Pluie' in sp[1] and 'faune' in sp[1], sp)

    # ---------- F3 : déduplication ----------
    reset(pg)
    pg.evaluate("window.GABON360_PROACTIVE._test.ageSeen(0)")
    for _ in range(6):
        pub(pg, module='alerts', type='ai-notification', summary='Crue détectée sur la rivière Ogooué', source='Station-7', severity='HIGH')
        pg.wait_for_timeout(200)
    check('F3 même événement x6 -> annoncé une seule fois', len(native(pg)) == 1, native(pg))
    pg.evaluate('window.GABON360_PROACTIVE._test.ageSeen(20*60000)')
    pub(pg, module='alerts', type='ai-notification', summary='Crue détectée sur la rivière Ogooué', source='Station-7', severity='HIGH')
    pg.wait_for_timeout(500)
    check('F3b après expiration de la fenêtre, nouvelle annonce autorisée', len(native(pg)) == 1, native(pg))
    # texte identique émis par deux chemins (structuré + ancien relais) -> pas de doublon
    reset(pg)
    pg.evaluate("window.GABON360_AI_RELAY.publish('cyber','cyber-ai-alert',{observation:'Tentative de connexion anormale',severity:'HIGH',source:'Journal-local',timestamp:new Date().toISOString()})")
    pg.wait_for_timeout(800)
    check('F3c un événement relayé par plusieurs chemins n’est dit qu’une fois', len(native(pg)) <= 1, native(pg))
    # redémarrage : la mémoire anti-répétition persiste
    keys = pg.evaluate("window.GABON360_PROACTIVE._spokenKeys().length")
    check('F3d mémoire anti-répétition persistante', keys >= 3, keys)
    b.close()

    # ---------- F4 / F5 : boutons manuels ----------
    b, pg, errs = fresh(p)
    reset(pg)
    ok_btn = pg.evaluate("""()=>{const bs=[...document.querySelectorAll('button')].filter(e=>/faire parler|parler/i.test(e.innerText||'')&&e.offsetParent!==null);if(!bs.length)return 'aucun';bs[0].click();return bs[0].innerText}""")
    pg.wait_for_timeout(300)
    spk = pg.evaluate("window.__spoken.map(x=>x.t)")
    check('F4 bouton « Parler » (manuel) reste fonctionnel : parole immédiate, non retardée par la file', ok_btn != 'aucun' and (len(native(pg)) + len(spk)) >= 1, [ok_btn, native(pg)[:1], spk[:1]])
    reset(pg)
    r = pg.evaluate("""()=>{const bs=[...document.querySelectorAll('button')].filter(e=>/explique/i.test((e.innerText||'')+(e.id||'')));return bs.map(e=>e.innerText.trim().slice(0,40))}""")
    check('F4b recherche des boutons « explique »', True, r)
    ia = pg.evaluate("""()=>{const e=document.getElementById('g360-ai');if(!e)return 'absent';e.click();return 'cliqué'}""")
    pg.wait_for_timeout(500)
    check('F5 bouton « IA » des formulaires/carte : action conservée (pas d’erreur, appel non bloqué)', ia == 'cliqué' and not [x for x in errs if 'g360' in x.lower()], [ia, errs[-2:]])
    b.close()

    # ---------- F6 : voix coupée ----------
    b, pg, errs = fresh(p); reset(pg)
    pg.evaluate("window.GABON360_PROACTIVE.set({muted:true})")
    pub(pg, module='alerts', type='ai-notification', summary='Alerte inondation zone Charlie', source='Station-9', severity='CRITICAL', status='VALIDATED')
    pg.wait_for_timeout(2000)
    st = pg.evaluate("window.GABON360_PROACTIVE.status().journal[0].status")
    check('F6 voix coupée : aucune parole, annonce affichée seulement', len(native(pg)) == 0 and 'voix coupée' in st, st)
    visible = pg.evaluate("getComputedStyle(document.getElementById('g360-pro-toast')).display")
    check('F6b texte affiché à l’écran malgré la voix coupée', visible == 'block', visible)
    pg.evaluate("window.GABON360_PROACTIVE.set({muted:false})")
    check('F6c bouton manuel avec voix coupée affiche le texte sans casser', True)
    # ---------- pause / reprise ----------
    reset(pg)
    pg.evaluate("window.GABON360_PROACTIVE.pause()")
    pub(pg, module='drones', type='ai-notification', summary='Batterie faible du drone 3', source='Télémétrie-3', severity='HIGH')
    pg.wait_for_timeout(3000)
    check('F6d pause : rien n’est prononcé', len(native(pg)) == 0, native(pg))
    pg.evaluate("window.GABON360_PROACTIVE.resume()")
    pg.wait_for_timeout(500)
    check('F6e reprise : l’annonce en attente est prononcée', len(native(pg)) == 1 and 'Batterie faible' in native(pg)[0], native(pg))
    # volume (repli navigateur)
    pg.evaluate("window.GABON360_PROACTIVE.setVolume(0)")
    reset(pg)
    pub(pg, module='drones', type='ai-notification', summary='Perte de liaison drone 4', source='Télémétrie-4', severity='CRITICAL', status='VALIDATED')
    pg.wait_for_timeout(1000)
    check('F6f volume 0 % : aucune parole', len(native(pg)) == 0)
    b.close()

    # ---------- F7 : données anciennes, simulées, démarrage ----------
    b, pg, errs = fresh(p); reset(pg)
    ok_old = pg.evaluate("window.GABON360_PROACTIVE.publish({module:'alerts',type:'ai-notification',summary:'Ancienne alerte du jour',source:'Archive',severity:'CRITICAL',timestamp:new Date(Date.now()-3600*1000).toISOString()})&&true")
    pub(pg, module='alerts', type='ai-notification', summary='Alerte fictive de démonstration', source='démo', severity='CRITICAL')
    pg.wait_for_timeout(1000)
    j = pg.evaluate("window.GABON360_PROACTIVE.status().journal.map(x=>x.status)")
    check('F7 donnée ancienne et simulée jamais annoncées', len(native(pg)) == 0 and any('ancienne' in s for s in j) and any('simulé' in s for s in j), j)
    # clic « Simuler événement » : ne doit rien annoncer comme réel
    reset(pg)
    pg.evaluate("""()=>{const e=[...document.querySelectorAll('button')].find(x=>/Simuler/.test(x.innerText));if(e)e.click()}""")
    pg.wait_for_timeout(7000)
    j = pg.evaluate("window.GABON360_PROACTIVE.status().journal.slice(0,4).map(x=>x.status)")
    check('F7b « Simuler événement » : aucune annonce vocale comme événement réel', len(native(pg)) == 0 and any('simulé' in s for s in j), [native(pg), j])
    # nouvelle mission réelle -> annoncée
    reset(pg)
    pg.evaluate("""()=>{const e=[...document.querySelectorAll('button')].find(x=>/Nouvelle mission/.test(x.innerText));if(e)e.click()}""")
    pg.wait_for_timeout(500)
    sp = native(pg)
    check('F7c nouvelle mission réellement créée -> annoncée', len(sp) == 1 and 'Nouvelle mission' in sp[0], sp)
    # silence sans activité
    reset(pg); pg.wait_for_timeout(6000)
    check('F7d aucun bavardage sans événement (2 min d’inactivité)', len(native(pg)) == 0, native(pg))
    b.close()

    # ---------- F8 : API externe absente ----------
    b, pg, errs = fresh(p); reset(pg)
    pg.evaluate("""()=>{const e=document.getElementById('g360-weather-open');if(e)e.click()}""")
    pg.evaluate("""()=>{const e=[...document.querySelectorAll('button')].find(x=>/Actualiser météo/.test(x.innerText));if(e)e.click()}""")
    pg.wait_for_timeout(5000)
    check('F8 service externe absent : aucune fausse annonce', len(native(pg)) == 0, native(pg))
    check('F8b pas de panne générale (module toujours présent)', pg.evaluate("typeof window.GABON360_PROACTIVE==='object' && typeof window.G360AvatarSpeak==='function'"))
    b.close()

json.dump(results, open(OUT, 'w'), ensure_ascii=False, indent=1)
fails = [r for r in results if not r['ok']]
print('\nTOTAL', len(results), 'échecs', len(fails))
