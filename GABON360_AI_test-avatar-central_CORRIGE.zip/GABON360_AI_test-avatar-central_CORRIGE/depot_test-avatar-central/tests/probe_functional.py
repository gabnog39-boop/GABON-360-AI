import sys,json
from playwright.sync_api import sync_playwright
import harness
with sync_playwright() as p:
    b,ctx,pg,logs=harness.open_page(p,sys.argv[1]); pg.wait_for_timeout(800)
    out={}
    pg.evaluate("document.getElementById('g360-terrain-v2-open').click()"); pg.wait_for_timeout(300)
    pg.evaluate("document.getElementById('g360-t2-start').click()"); pg.wait_for_timeout(1500)
    out['nav_gps']=pg.evaluate("({pos:document.getElementById('g360-t2-pos').innerText,acc:document.getElementById('g360-t2-acc').innerText,status:document.getElementById('g360-t2-status').innerText})")
    pg.evaluate("document.getElementById('g360-t2-save-wp').click()"); pg.wait_for_timeout(300)
    out['nav_waypoint']=pg.evaluate("document.getElementById('g360-t2-wplist').innerText.slice(0,80)")
    out['relay_terrain_events']=pg.evaluate("window.GABON360_AI_RELAY.history.filter(h=>/terrain/.test(h.type)).map(h=>h.type)")
    pg.evaluate("document.getElementById('g360-terrain-v2-close').click()")
    # satellite hors réseau
    pg.evaluate("document.getElementById('g360-sat-refresh')&&document.getElementById('g360-sat-refresh').click()"); pg.wait_for_timeout(1500)
    out['sat_offline']=pg.evaluate("(document.getElementById('g360-sat-status')||{}).innerText")
    # météo hors réseau
    pg.evaluate("[...document.querySelectorAll('button')].find(x=>/Actualiser météo/.test(x.innerText)).click()"); pg.wait_for_timeout(1500)
    out['meteo_offline']=pg.evaluate("[...document.querySelectorAll('[id*=eather],[id*=meteo]')].map(e=>(e.innerText||'').slice(0,90)).filter(Boolean).slice(0,3)")
    # rapport
    out['rapport_events']=pg.evaluate("window.GABON360_AI_RELAY.history.filter(h=>/report|satellite|weather/.test(h.type)).map(h=>h.type)")
    # frontières: charger contour hors réseau => message honnête
    pg.evaluate("window.GABON360_NAVIGATE('borders')"); pg.evaluate("document.getElementById('g360-b-load').click()"); pg.wait_for_timeout(800)
    out['borders_offline']=pg.evaluate("document.getElementById('g360-b-msg').innerText")
    # frontières: contour simulé par un polygone de TEST injecté en stockage (hors réseau) pour vérifier le test de position
    pg.evaluate("""()=>{localStorage.setItem('g360.borders.geojson.v1',JSON.stringify({type:'Polygon',coordinates:[[[8,-4],[15,-4],[15,3],[8,3],[8,-4]]]}));localStorage.setItem('g360.borders.meta.v1',JSON.stringify({at:Date.now(),source:'polygone de test',bbox:[8,-4,15,3],polygons:1,vertices:5}))}""")
    pg.evaluate("window.GABON360_NAVIGATE('borders')"); pg.evaluate("document.getElementById('g360-b-pos').click()"); pg.wait_for_timeout(1500)
    out['borders_pos_in_test_polygon']=pg.evaluate("document.getElementById('g360-b-pos-out').innerText")
    # frontières: saisie manuelle -> relais + voix
    pg.evaluate("window.__native.length=0")
    pg.evaluate("document.getElementById('g360-b-note').value='Traces de passage récentes';document.getElementById('g360-b-place').value='Village test';document.getElementById('g360-b-save').click()"); pg.wait_for_timeout(700)
    out['borders_obs_voice']=pg.evaluate("window.__native.filter(x=>x.t).map(x=>x.t)")
    out['borders_obs_relay']=pg.evaluate("window.GABON360_AI_RELAY.history.filter(h=>/borders/.test(JSON.stringify(h.data))).map(h=>h.type)")
    # GPX Garmin
    out['garmin_buttons']=pg.evaluate("(()=>{document.getElementById('g360-garmin-open').click();return [...document.querySelectorAll('#g360-garmin-modal button')].map(e=>e.innerText.trim().slice(0,24))})()")
    print(json.dumps(out,ensure_ascii=False,indent=1)); print('erreurs JS:',logs['pageerror'][:3]); b.close()
