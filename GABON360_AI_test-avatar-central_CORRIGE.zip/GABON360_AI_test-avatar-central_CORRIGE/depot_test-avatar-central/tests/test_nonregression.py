import sys,json,re
from collections import Counter
from playwright.sync_api import sync_playwright
import harness
def run(path):
    out={'labels':[], 'errors':Counter(), 'clicked':0, 'reloads':0, 'speech':[]}
    with sync_playwright() as p:
        b,ctx,pg,logs=harness.open_page(p,path); pg.wait_for_timeout(900)
        labels=pg.evaluate("[...document.querySelectorAll('button')].map(e=>(e.innerText||'').trim())")
        out['labels']=labels; n=len(labels); i=0
        while i<n:
            try:
                pg.evaluate("""(i)=>{const e=document.querySelectorAll('button')[i];if(!e)return;const t=(e.innerText||'').toLowerCase();if(/supprimer|effacer|reset|quitter|réinitialiser/.test(t))return;e.click()}""",i); out['clicked']+=1
            except Exception:
                out['reloads']+=1
                pg.goto('file://'+path); pg.wait_for_timeout(700)
            i+=1
        pg.wait_for_timeout(500)
        out['errors']=Counter(logs['pageerror'])
        out['speech']=pg.evaluate("window.__spoken.length+window.__native.filter(x=>x.t).length")
        b.close()
    return out
a=run(sys.argv[1]); f=run(sys.argv[2])
miss=[l for l in a['labels'] if l and l not in f['labels']]
res={'original':{'boutons':len(a['labels']),'cliques':a['clicked'],'rechargements':a['reloads'],'erreurs_uniques':len(a['errors']),'erreurs_total':sum(a['errors'].values()),'detail':dict(a['errors'].most_common(8))},
     'final':{'boutons':len(f['labels']),'cliques':f['clicked'],'rechargements':f['reloads'],'erreurs_uniques':len(f['errors']),'erreurs_total':sum(f['errors'].values()),'detail':dict(f['errors'].most_common(8))},
     'boutons_originaux_absents_du_final':miss,'boutons_ajoutes':len([l for l in f['labels'] if l not in a['labels']])}
json.dump(res,open(sys.argv[3],'w'),ensure_ascii=False,indent=1); print(json.dumps(res,ensure_ascii=False,indent=1)[:2500])
