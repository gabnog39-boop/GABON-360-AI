# GABON 360 AI — Rapport de corrections et de sécurisation (copie locale, branche cible : test-avatar-central)

**État honnête du paquet**
- Corrigé **localement seulement**. Rien n'a été poussé sur GitHub, aucune branche fusionnée, aucune compilation lancée sur votre dépôt.
- **L'APK n'a PAS été compilée** (pas de SDK Android, ni Gradle, ni réseau dans mon environnement) : la compilation Gradle reste à faire sur GitHub Actions.
- **Aucun test sur téléphone réel n'a été fait** : un test sur Android reste nécessaire.
- Le workflow n'a **pas été exécuté sur de vrais serveurs GitHub Actions**. Sa protection de branche a été vérifiée en exécutant ses étapes dans bash avec les variables d'environnement que GitHub fournit (voir §5).
- Le build n'est donc **pas déclaré validé** : les contrôles locaux sont terminés et réussis, les contrôles Android et GitHub réels restent à faire.

## 1. Problème du script manquant — analyse
- Le `build-apk.yml` fourni séparément appelait `python3 appliquer_paquet_correctifs.py` ; le ZIP livré ne contenait ni ce script ni cette étape (le workflow du dépôt du ZIP n'avait pas l'étape). Le fichier téléchargé s'appelait `appliquer_paquet_correctifs (1).py` (renommage du téléchargement), ce qui aurait fait échouer le workflow.
- Contenu examiné : c'est un auto-extracteur (archive base64 de 15 fichiers, 18 aujourd'hui) qui écrit `scripts/inject_v183_base_repair_v1.py`, `scripts/inject_proactive_speech_v1.py`, `scripts/inject_border_airspace_payments_pages_v1.py`, les deux modules `scripts/assets/*.js`, le rapport et les tests. Il ne produit aucune injection lui-même.
- **Les injecteurs étaient déjà présents dans le dépôt du ZIP** : le script y était donc redondant. Il est conservé uniquement pour la voie « 2 fichiers depuis le téléphone ». Il a été rendu non redondant : fichier déjà identique → « inchangé » ; fichier différent → conflit, arrêt, rien d'écrasé. Dépôt complet : 0 créé, 18 inchangés (testé). Dépôt d'origine + 2 fichiers : 18 créés (testé). Les deux voies donnent un `index.html` final **identique octet pour octet**.
- Nom et emplacement définitifs : **`appliquer_paquet_correctifs.py`, à la racine du dépôt**. Il refuse de s'exécuter s'il porte un autre nom (par exemple « (1) »).
- Aucune injection dupliquée n'a été ajoutée au workflow. Les seules ajouts d'injecteurs concernent des défauts nouveaux et distincts (voir §4).

## 2. Faille de protection des branches — corrigée
Avant : `GITHUB_ACTIONS=true` désactivait la protection (le script pouvait écrire sur main/principal).
Maintenant, dans `appliquer_paquet_correctifs.py` :
- refus **permanent** de main, principal et master, en local **et** en GitHub Actions ;
- en CI : contrôle de `GITHUB_REF_TYPE` (branch), `GITHUB_REF_NAME`, `GITHUB_REF` (cohérence), refus des pull requests (`GITHUB_EVENT_NAME`, `GITHUB_BASE_REF`, `GITHUB_HEAD_REF`) ;
- recoupement avec la vraie branche git : une usurpation des variables d'environnement est refusée (testé) ;
- refus si la branche est inconnue ou différente de `test-avatar-central` (casse comprise) ;
- validation stricte des chemins du paquet (pas de `..`, `/`, `\`, `:`, `~`, composants vides, chemin non normalisé, liens symboliques, dossiers) ; seuls `scripts/`, `tests/`, `docs/` sont autorisés ;
- empreinte SHA-256 du paquet et de chaque fichier ; liste fermée (manifeste) ; tailles limitées ;
- plan avant écriture (créer / inchangé / conflit) ; **aucun écrasement** d'un fichier différent (en local seulement, option explicite avec sauvegarde `.bak`, interdite en CI) ; écriture atomique ; aucune suppression ; aucun autre fichier touché.
Codes de sortie : 0 OK, 2 refus de branche, 3 refus de chemin/intégrité/emplacement, 4 conflit.

## 3. Workflow `build-apk.yml` — corrigé (un seul fichier, identique dans le dépôt et en livraison séparée)
- Déclencheurs : `push` uniquement sur `test-avatar-central` ; `workflow_dispatch` conservé. Plus aucune mention de main/principal dans les déclencheurs.
- `permissions: contents: read` (le jeton ne peut rien écrire dans le dépôt) ; checkout sans identifiants persistants.
- Défense 1 : condition du job `github.ref == 'refs/heads/test-avatar-central'`.
- Défense 2 : première étape = contrôle explicite de la branche, **avant** le checkout, l'écriture, l'injection et la compilation (refuse main, principal, pull request, tag, branche inconnue).
- Étapes ajoutées (aucune supprimée) : vérification/déploiement du paquet sans écrasement ; vérification des scripts du paquet ; réparation V183 ; correctif `#g360-focus` ; pages ; parole proactive. Toutes les étapes de compilation Android sont conservées (Gradle, Construire APK, Vérifier et publier APK).
- Les deux workflows de surveillance (`autonomous-monitoring.yml`, `gabon-autonomous-monitor.yml`) sont **inchangés** : ils sont planifiés toutes les 6 h (GitHub ne les exécute que depuis la branche par défaut), en lecture seule, sans push ni commit. Je les signale car ils tournent sur la branche par défaut sans rapport avec ce travail.
- Conséquence : la branche `repair/android-swipe-ai-modules` ne peut plus lancer ce workflow ; le ZIP V183 doit être présent à la racine de `test-avatar-central`.

## 4. Défauts de l'application corrigés ce tour (testés)
| Défaut | Cause | Correctif | Test |
|---|---|---|---|
| Les 12 boutons de domaine du Centre national lançaient une erreur | `#g360-focus` (badge de la zone carte) est supprimé quand `inject_real_gabon_map.py` remplace le contenu de la zone carte | nouvel injecteur `inject_center_focus_fix_v1.py` : ajoute l'élément hors de la zone carte | 12/12 : aucune erreur, domaine affiché, fenêtre ouverte |
| Bouton « OK » de la conversation : « command is not a function » | dans un `onclick`, `command` est résolu d'abord sur le bouton ; Chrome/WebView récents exposent `HTMLButtonElement.command` | `onclick="window.command()"` (dans l'injecteur de réparation existant du paquet) | plus d'erreur |
| « Commande reçue : undefined » prononcé | le code utilisait la variable `text` au lieu du texte saisi | `(text\|\|c)` | la commande saisie est prononcée |
**Non corrigé** : les boutons de zoom et la grille du modèle (`#g360-zoom-*`, `#g360-mapgrid`) sont remplacés par la carte réelle (leurs identifiants n'existent plus) ; la carte réelle n'a pas pu être testée avec le réseau.

## 5. Tests réellement exécutés et résultats
| Contrôle | Résultat |
|---|---|
| Intégrité du ZIP d'origine (150 fichiers) et du ZIP corrigé | OK |
| `py_compile` de tous les `.py` référencés par le workflow | OK |
| YAML des 3 workflows | valides |
| Existence des 69 chemins référencés par le workflow (scripts, tests, serveur, ZIP V183, script racine) | aucun manquant |
| Garde de branche du workflow : étape bash exécutée avec 10 combinaisons de variables GitHub (main, principal, manuel sur main, branche inconnue, repair/…, pull_request, tag, variables absentes, push et manuel sur test-avatar-central) | 10/10 conformes |
| Script sécurisé : 53 tests (branches locales ; CI avec variables usurpées/incohérentes ; chemins malveillants ; liens symboliques ; écrasement ; nom « (1) » ; mauvais dossier ; paquet altéré ; base64 invalide) | 53/53 |
| Dépôt complet + script en CI simulée | 0 créé, 18 inchangés |
| Dépôt d'origine + 2 fichiers en CI simulée, puis rejeu du workflow | 18 créés ; 51 étapes OK ; `index.html` final identique |
| Rejeu des étapes `python3` du workflow (dont `preflight_apk_audit.py`) | 51/51 OK |
| Parole proactive (Playwright/Chromium 141) | 25/25 |
| Événements missions/alertes/relais/récursion | 11/11 |
| Défauts corrigés (Centre national, OK) | 7/7 (+1 information non comptée) |
| Non-régression : 80 boutons de la V183 d'origine tous présents, 203 boutons cliqués | 61 erreurs JS (14 types) → 1 (presse-papiers refusé par le navigateur de test) |
| Audit des 22 modules (page ouvrable, boutons cliqués, relais → avatar) | 22/22 sans exception JS |
Deux « échecs » ont été rencontrés puis analysés pendant le développement des tests de sécurité : dans les deux cas le script refusait bien et n'écrivait rien, mais avec un message différent de celui attendu par le test ; j'ai corrigé l'attente du test (deux messages de refus légitimes acceptés), sans changer le comportement du script.
**Limite de ces tests** : environnement simulé (Chromium headless, réseau coupé, Leaflet remplacé par un stub, pont Android `G360Android.speak` simulé, géolocalisation du navigateur simulée).

## 6. Les 22 modules (build corrigé)
Légende : OP = opérationnel en local testé ; PART = partiel / dépend d'un service ; ATT = en attente de source ou de configuration. « boutons » = cliqués sur total, 0 exception JS pour tous.
| Module | État | Boutons | Source / remarque |
|---|---|---|---|
| Accueil | OP | 5/5 | local |
| Cartographie | PART | 10/12 | fonds OSM/Esri/UGEO + Leaflet via CDN ; carte réelle non testée |
| Satellites | PART | 11/13 | Copernicus (métadonnées, pas d'image en direct) ; hors réseau : message honnête |
| Drones | ATT | 11/13 | aucune source |
| Navigation | PART | 12/14 | GNSS ; testé seulement avec une position simulée |
| Géolocalisation | PART | 5/5 | idem |
| Cyber | PART | 9/10 | journal local, pas de SOC |
| Mémoire territoriale | OP (local) | 13/15 | registre local |
| Alertes | OP (local) | 12/14 | annonces testées |
| Rapports | PART | 10/12 | émission vers le relais non vérifiée |
| Statistiques | PART | 11/13 | données locales |
| Météo | PART | 10/12 | Open-Meteo, service réel non testé |
| Parcs et biodiversité | PART | 9/11 | pas de polygones officiels |
| Eaux et océan | PART | 10/12 | pas d'AIS |
| Frontières | PART | 3/6 | contour geoBoundaries à charger (réseau, non testé en réel) ; saisie manuelle → avatar testée |
| Espace aérien | ATT | 1/3 | saisie manuelle uniquement, aucune source |
| Centre national | PART | 11/13 | 12 domaines corrigés ; zoom/grille du modèle remplacés par la carte réelle |
| Administration | PART | 5/5 | contrôle côté client, pas d'authentification serveur |
| Utilisateurs | ATT/PART | 12/14 | pas de comptes serveur |
| Paiements | ATT | 2/4 | aucun encaissement possible, bouton désactivé |
| Missions et terrain | OP (local) | 5/5 | mission → relais → voix testée ; synchronisation serveur non configurée |
| Garmin / GPX | PART | 14/17 | import/export GPX non testés fonctionnellement |
Le test « relais → avatar » publie un événement de chaque module via l'API de la parole proactive : il prouve que la chaîne reçoit et prononce, pas que chaque module émet de lui-même (seuls cartographie, satellites, météo, cyber, rapports (code), terrain Garmin émettent nativement ; alertes et missions via la surveillance de l'état).

## 7. Défauts et limites restants
1. APK non compilée ; aucun test sur téléphone ; workflow jamais exécuté sur GitHub ; comportement de `actions/checkout` sur branche à vérifier au premier lancement réel (le script échoue « en sécurité » si les sources de branche divergent).
2. Zoom/grille du Centre national : voir §4.
3. Presse-papiers (« Partager ») : non testé sur Android.
4. Le badge « CONNECTÉ » reflète l'interface réseau, pas l'accès réel à internet.
5. Volume : le pont natif suit le volume média du téléphone ; le curseur règle le repli navigateur.
6. Parole en arrière-plan : rien n'est prononcé app fermée/en veille (notifications push serveur et service Android non réalisés).
7. La V183 fournie est incohérente (HTML plus ancien que `app.js`) : ma réparation est une reconstitution minimale, à comparer avec votre vrai historique git.
8. Leaflet via CDN : pas de carte hors réseau.
9. Pages Frontières / Espace aérien / Paiements : hors balayage horizontal ; Espace aérien et Paiements non fonctionnels sans source/fournisseur.
10. `inject_payment_billing.py` n'est pas dans le workflow (non ajouté : dépendance Google Play Billing impossible à compiler ici).
11. Services externes non testés en réel : Copernicus, Open-Meteo, geoBoundaries, serveur GABON 360 (adresse d'exemple), GPX.

## 8. Fichiers
Ajoutés (dépôt) : `appliquer_paquet_correctifs.py` (racine) ; `scripts/inject_v183_base_repair_v1.py`, `scripts/inject_center_focus_fix_v1.py`, `scripts/inject_proactive_speech_v1.py`, `scripts/inject_border_airspace_payments_pages_v1.py` ; `scripts/assets/proactive_speech_v1.js`, `scripts/assets/pages_borders_airspace_payments_v1.js` ; `tests/*` (dont `test_appliquer_paquet.py`, `test_defects.py`) ; `docs/AUDIT_ET_TESTS.md` ; copie du ZIP V183 à la racine (nom attendu par le workflow).
Modifié : `.github/workflows/build-apk.yml` (le seul fichier d'origine modifié).
Modifiés ce tour par rapport au ZIP précédent : `build-apk.yml`, `inject_v183_base_repair_v1.py`, `tests/README.md`, `docs/AUDIT_ET_TESTS.md` ; ajoutés : script racine, `inject_center_focus_fix_v1.py`, `test_appliquer_paquet.py`, `test_defects.py`.
Inchangés : les 103 autres fichiers du dépôt d'origine (dont les deux workflows de surveillance, tous les injecteurs existants, `server/`, `api/`, `index.html` de base).
Sauvegardes conservées : `sauvegardes/` (ZIP précédent complet, ancien script non sécurisé, ancien workflow séparé). Rien n'a été supprimé.
