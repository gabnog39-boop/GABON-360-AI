# Mettre ce paquet sur la branche test-avatar-central (téléphone Android) — sans toucher à main

Règle : ne jamais valider sur `main` ni `principal`, ne fusionner aucune branche. Le workflow corrigé refuse de toute façon de tourner ailleurs que sur `test-avatar-central`.

## Contenu
- `depot_test-avatar-central/` : le dépôt de test complet et corrigé.
- `android_project_integre/` : projet Android après le rejeu des injecteurs (pour inspection ; régénéré par GitHub Actions).
- `rapports/` : rapport, résultats bruts des tests, journaux. `sauvegardes/` : anciennes versions (ne rien supprimer).

## Voie A — 2 fichiers seulement (la plus simple depuis un navigateur)
Fichiers : `appliquer_paquet_correctifs.py` (à la racine du dépôt) et `build-apk.yml` (dans `.github/workflows/`). Ils sont à côté de ce ZIP.
1. Dans le navigateur (mode « Version pour ordinateur »), ouvrez le dépôt, choisissez la branche **test-avatar-central** et relisez son nom.
2. *Add file → Upload files* : envoyez `appliquer_paquet_correctifs.py` (nom EXACT, sans « (1) »). Validez avec « Commit directly to the **test-avatar-central** branch ».
3. Ouvrez `.github/workflows/build-apk.yml` → crayon → remplacez tout par le nouveau contenu → validez sur **test-avatar-central**.
4. Vérifiez que `GABON_360_AI_FINAL_CONSOLIDATED_V183_ICON.zip` est à la racine de cette branche ; sinon envoyez-le (il se trouve dans `depot_test-avatar-central/`).
5. Actions → « Construire GABON 360 AI APK » → **Run workflow** → branche **test-avatar-central**. (Un push sur la branche le lance aussi automatiquement ; main/principal ne le lancent plus.)
   - Si le premier contrôle (« Contrôle de sécurité de la branche ») échoue : c'est voulu, vous n'êtes pas sur la bonne branche.
   - Si l'étape du paquet signale un CONFLIT : un fichier du même nom existe déjà avec un contenu différent ; il n'a pas été écrasé. Comparez-le, ou utilisez la voie B.
6. Téléchargez l'artefact **GABON-360-AI-APK**.

## Voie B — Termux (dépôt complet)
    git checkout test-avatar-central && git branch --show-current     # doit afficher test-avatar-central
    cp -r /chemin/GABON360_AI_test-avatar-central_CORRIGE/depot_test-avatar-central/. .
    python3 appliquer_paquet_correctifs.py --a-blanc                   # plan, rien n'est écrit
    git status                                                         # relire la liste avant de valider
    git add -A && git commit -m "Test: correctifs V183, sécurité, nouvelles pages"
    git push origin test-avatar-central                                # JAMAIS origin main
Le script refuse de tourner sur main/principal/branche inconnue ; un fichier différent n'est jamais écrasé sans l'option explicite (qui fait une sauvegarde .bak).

## Tester l'APK sur le téléphone (obligatoire : aucun test sur téléphone réel n'a été fait)
1. Installer l'APK ; accorder micro et localisation.
2. Accueil : avatar et boutons intacts ; 🔊 Parler parle ; le bouton « OK » de la conversation répond (ex. « alertes »).
3. Centre national : cliquer chaque domaine → plus d'erreur, le domaine s'affiche.
4. « ＋ Nouvelle mission » : l'avatar l'annonce une seule fois. 🔔 : pause, reprise, voix coupée, volume.
5. Onglet 🔌 Infrastructure présent. 🔔 → Autres pages : Frontières / Espace aérien / Paiements.
6. Réseau coupé : aucune annonce inventée (la carte ne s'affichera pas : Leaflet via CDN).
7. Notez toute différence avec le rapport et envoyez-la moi.
