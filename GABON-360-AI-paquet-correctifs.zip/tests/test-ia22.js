// Test statique/logique des 22 IA (Node, sans navigateur) : node tests/test-ia22.js
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.join(__dirname,'..');
const src=fs.readFileSync(path.join(root,'gabon360-ia22.js'),'utf8');
const iaSrc=fs.readFileSync(path.join(root,'gabon360-ia.js'),'utf8');
const ids=[...iaSrc.matchAll(/\['([a-z]+)','((?:[^'\\]|\\.)+)','(?:[^'\\]|\\.)*','[^']*'\]/g)].map(m=>[m[1],m[2]]);
let ok=0,ko=0;const t=(c,m)=>{if(c){ok++}else{ko++;console.log('ÉCHEC:',m)}};
function run(withData,roleName){
  const delivered=[];
  const sb={console,setTimeout,navigator:{geolocation:{}},addEventListener(){},
    document:{getElementById:()=>null,querySelector:()=>null,createElement:()=>({}),},
    avSay(){}};
  sb.window=sb; sb.location={protocol:'https:'};
  const agents=ids.map(([id,page])=>({id,page}));
  const av={deliver(a,txt,mode){delivered.push({a:a.id,txt});},async ask(id,q){const a=agents.find(x=>x.id===id);av.deliver(a,a.page+' — état vérifiable des données :\n• test',mode='local');}};
  sb.G360_IA={agents,avatar:av};
  sb.G360_CENTRE={loadRecords:()=>withData?[{module:'meteo',title:'Orage Libreville',values:['Libreville','orage','haute'],createdAt:'2026-10-27'},{module:'cyber',title:'Incident',values:['VPS','haute']}]:[]};
  if(withData){
    sb.D={al:[{titre:'Feu',statut:'nouvelle',priorite:'critique',latitude:0.4,longitude:9.4},{titre:'Braconnage',statut:'resolue',priorite:'haute',latitude:null}],
      ms:[{titre:'Patrouille Loango',statut:'en_cours',distance_m:12000}],ob:[{parc:'Loango'},{parc:'Loango'},{parc:'Ivindo'}],rp:[{titre:'R1',statut:'brouillon'}],us:[{role:'agent'},{role:'administrateur'}]};
    sb.me={role:roleName};
  }
  vm.createContext(sb);vm.runInContext(src,sb);
  return {sb,delivered,agents,av};
}
for(const [withData,r] of [[true,'proprietaire'],[true,'agent'],[false,null]]){
  const {sb,agents}=run(withData,r);
  const I=sb.G360_IA22;
  t(ids.length===22,'ia.js doit déclarer 22 IA, trouvé '+ids.length);
  for(const [id] of ids){
    t(typeof I.skills[id]==='function',id+' : fonction propre absente');
    t(!!I.meta[id],id+' : métadonnées (fichiers/fonctions/dépendances) absentes');
    const res=I.run(id,'test'); t(res&&res.etat!=='erreur'&&res.lines.length>0,id+' : erreur d\'exécution '+JSON.stringify(res));
    t(!!agents.find(a=>a.id===id&&typeof a.skill==='function'&&a.fonctions),id+' : non raccordée à G360_IA');
  }
  // l'absence de données ne doit jamais produire de chiffres inventés
  if(!withData){ const a=I.run('alertes'); t(a.etat==='non_relie','alertes sans connexion doit être non_relie'); }
  if(withData&&r==='agent'){ t(/Réservé|réservée/.test(I.run('users').lines[0]),'users doit être réservé à un agent'); t(/Réservé/.test(I.run('admin').lines[0]),'admin doit être réservé'); }
  if(withData&&r==='proprietaire'){ t(/2 compte/.test(I.run('users').lines[0]),'users compte'); t(/1 ouverte|1 alerte\(s\) ouverte|1 ouverte/.test(I.run('alertes').lines[0]+''),'alertes ouvertes: '+I.run('alertes').lines[0]); t(I.search('orage').length>=1,'memoire.search'); t(/Loango \(2\)/.test(I.run('parcs').lines[0]),'parcs'); }
}
// routage de l'avatar
const {sb,delivered,av}=run(true,'proprietaire');
const R=sb.G360_IA22.route;
const cases={'quelle est la météo':'meteo','état des drones':'drones','mes paiements':'paiements','envoie un gpx':'garmin','alertes critiques':'alertes','frontière nord':'frontieres','situation nationale':'centre','combien de missions':'missions','les parcs nationaux':'parcs','images satellite':'satellites'};
for(const [q,e] of Object.entries(cases)){const g=R(q);t(g===e||(q==='combien de missions'&&g==='missions'),'route "'+q+'" → '+g+' (attendu '+e+')');}
// l'avatar relaie et complète
(async()=>{await av.ask('accueil','état de la météo');
 const d=delivered.pop();t(d&&d.a==='meteo','ask doit router vers meteo, reçu '+(d&&d.a));
 t(d&&/Analyse « /.test(d.txt),'le message livré à l\'avatar doit contenir l\'analyse propre de l\'IA');
 sb.G360_IA.situation();const s=delivered.pop();t(s&&s.txt.split('\n').length>=23,'point de situation doit remonter les 22 IA');

 // annonces automatiques : pas de doublon, source/date indiquées
 const n0=delivered.length; const ag=sb.G360_IA.agents.find(a=>a.id==='alertes');
 av.deliver(ag,'Nouvelle information reçue pour Alertes : 1 nouvel enregistrement(s) détecté(s) dans alertes. Cette information doit être vérifiée.','local');
 av.deliver(ag,'Nouvelle information reçue pour Alertes : 1 nouvel enregistrement(s) détecté(s) dans alertes. Cette information doit être vérifiée.','local');
 t(delivered.length-n0===1,'annonce dupliquée non filtrée ('+(delivered.length-n0)+')');
 t(/Source : .* détecté le /.test(delivered[delivered.length-1].txt),'source/date absentes de l\'annonce');
 console.log(`Tests : ${ok} réussis, ${ko} échoués`);process.exit(ko?1:0)})();
