/* GABON 360 AI — configuration de l'adresse du serveur /api (Vercel).
   Dans l'APK, le site est embarqué (file://) : les routes /api/* n'existent pas localement.
   Pour les activer dans l'APK, renseignez ici l'adresse PUBLIQUE de votre déploiement, par exemple :
     window.G360_API_BASE = "https://votre-domaine.vercel.app";
   Laissée vide : l'application fonctionne sans ces routes (avatar en mode local, limites des parcs/frontières
   récupérées directement quand c'est possible). Ne mettez pas ici d'adresse protégée par connexion Vercel : elle refuserait les requêtes. */
window.G360_API_BASE = window.G360_API_BASE || "";
