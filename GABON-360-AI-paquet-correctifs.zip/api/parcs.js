// Relais /api/parcs — parcs nationaux du Gabon (Forest Atlas), appelé par index.html (faImport) si l'accès direct échoue.
const FA="https://gis.forest-atlas.org/server/rest/services/gab/forest_gabon/MapServer/25/query?where=type_desc%3D%27Parc%20National%27&outFields=*&returnGeometry=true&outSR=4326&f=geojson";
module.exports=async(req,res)=>{try{
 const r=await fetch(FA);if(!r.ok)throw new Error("HTTP "+r.status);const j=await r.json();
 res.setHeader("Content-Type","application/json; charset=utf-8");res.setHeader("Cache-Control","s-maxage=86400");res.status(200).json(j)
}catch(e){res.status(502).json({error:{message:"Forest Atlas indisponible"}})}};
