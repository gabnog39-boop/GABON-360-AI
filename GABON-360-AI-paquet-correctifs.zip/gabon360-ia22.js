/* GABON 360 AI — Raccordement des 22 IA à l'avatar central.
   Ce fichier COMPLÈTE gabon360-ia.js (il ne le remplace pas) :
   1. fournit window.G360.data() (alertes, missions, observations, rapports, profils) à partir des données
      réellement chargées par l'application ; sans connexion ou sans droits, la source reste « non reliée » ;
   2. donne à chacune des 22 IA sa propre fonction d'analyse, calculée uniquement sur des faits comptés ;
   3. fait router par l'avatar la question vers l'IA concernée (clavier ou voix) ;
   4. ajoute « Point de situation » (remontée des 22 IA vers l'avatar) et un auto-test.
   Aucune donnée n'est inventée. Les sources externes absentes sont nommées comme dépendances. */
(function () {
  "use strict";
  if (window.__G360_IA22__) return;
  window.__G360_IA22__ = true;

  // ---- 0. Routes /api dans l'APK (site embarqué en file://) -----------------------------------
  const apiBase = () => { try { return String(window.G360_API_BASE || localStorage.getItem("g360_api_base") || "").replace(/\/$/, ""); } catch (_) { return ""; } };
  if (location.protocol === "file:" || apiBase()) {
    const f0 = window.fetch;
    window.fetch = function (u, o) {
      if (typeof u === "string" && u.indexOf("/api/") === 0) {
        const b = apiBase();
        if (!b) return Promise.reject(new Error("Serveur /api non configuré dans cette application (voir gabon360-config.js)."));
        u = b + u;
      }
      return f0.call(this, u, o);
    };
  }

  // ---- 1. Données de l'application -----------------------------------------------------------
  const G360 = (window.G360 = window.G360 || {});
  const MAP = { alertes: "al", missions: "ms", observations: "ob", rapports: "rp", profiles: "us" };
  const appData = () => { try { return typeof D !== "undefined" && D ? D : null; } catch (_) { return null; } };
  const role = () => { try { return (typeof me !== "undefined" && me && me.role) || null; } catch (_) { return null; } };
  if (typeof G360.data !== "function") {
    G360.data = (n) => { const d = appData(), k = MAP[n]; const v = d && k ? d[k] : null; return Array.isArray(v) ? v : null; };
  }
  const rows = (n) => G360.data(n);
  const fiches = (ids) => {
    try { return (window.G360_CENTRE && window.G360_CENTRE.loadRecords ? window.G360_CENTRE.loadRecords() : []).filter((r) => ids.includes(r.module)); }
    catch (_) { return []; }
  };
  const n = (a, f) => (a || []).filter(f).length;
  const dernier = (f) => { const l = f.slice(-1)[0]; return l ? " Dernière fiche : " + String(l.createdAt || "").slice(0, 10) + " · " + String(l.title || l.moduleName || "fiche") + "." : ""; };
  const fi = (ids, nom) => { const f = fiches(ids); return nom + " : " + f.length + " fiche(s) enregistrée(s) sur cet appareil." + dernier(f); };
  const live = (id) => { try { return (window.G360_LIVE && window.G360_LIVE.contextFor && window.G360_LIVE.contextFor(id)) || ""; } catch (_) { return ""; } };
  const nonRelie = (nom) => nom + " : source non reliée (connexion requise ou table inaccessible).";
  const ouvertes = () => (rows("alertes") || []).filter((x) => !["resolue", "rejetee"].includes(x.statut));

  // ---- 2. Les 22 IA : métadonnées + fonction propre ------------------------------------------
  // skill(q) -> { etat: "ok"|"partiel"|"non_relie", lines: [..] }
  const SK = {
    accueil() {
      const o = ouvertes(), a = rows("alertes"), m = rows("missions"), r = rows("rapports");
      return { etat: a ? "ok" : "partiel", lines: [
        a ? o.length + " alerte(s) ouverte(s) dont " + n(o, (x) => x.priorite === "critique") + " critique(s)." : nonRelie("Alertes"),
        m ? n(m, (x) => x.statut !== "terminee" && x.statut !== "terminée") + " mission(s) non terminée(s) sur " + m.length + "." : nonRelie("Missions"),
        r ? n(r, (x) => x.statut && x.statut !== "valide" && x.statut !== "validé") + " rapport(s) à valider ou en cours sur " + r.length + "." : nonRelie("Rapports")] };
    },
    carte() {
      const a = rows("alertes"), ob = rows("observations");
      return { etat: a ? "ok" : "partiel", lines: [
        a ? n(a, (x) => x.latitude != null) + " alerte(s) positionnée(s) sur " + a.length + " ; " + n(ouvertes(), (x) => x.latitude == null) + " ouverte(s) sans position." : nonRelie("Alertes cartographiées"),
        ob ? ob.length + " observation(s) de terrain disponibles." : nonRelie("Observations"),
        "Fond de carte Leaflet : " + (typeof L !== "undefined" ? "chargé." : "NON chargé (réseau/CDN requis).")] };
    },
    satellites() {
      return { etat: "partiel", lines: [fi(["satellites"], "Demandes d'imagerie"), live("satellites") || "Visualiseur NASA GIBS non vérifié.",
        "Dépendance : flux Copernicus/Sentinel Hub (clés) non configuré — aucune image n'est analysée automatiquement."] };
    },
    drones() {
      return { etat: "partiel", lines: [fi(["drones"], "Missions drones"), "Dépendance : drone/flux vidéo et autorisation de vol — aucun drone n'est piloté ni lu par l'application."] };
    },
    navigation() {
      const m = rows("missions"), km = m ? (m.reduce((s, x) => s + (Number(x.distance_m) || 0), 0) / 1000).toFixed(1) : null;
      return { etat: m ? "ok" : "partiel", lines: [fi(["navigation"], "Itinéraires préparés"), m ? "Distance cumulée des missions enregistrées : " + km + " km." : nonRelie("Missions"),
        "Navigation hors ligne : " + (window.G360_NAV || window.G360_OFFLINE ? "module chargé." : "module gabon360-navigation-offline.js à vérifier au navigateur.")] };
    },
    geoloc() {
      return { etat: navigator.geolocation ? "ok" : "partiel", lines: [fi(["geoloc"], "Relevés GPS"),
        navigator.geolocation ? "API de géolocalisation du navigateur disponible (autorisation demandée à l'usage)." : "Géolocalisation indisponible sur cet appareil."] };
    },
    cyber() {
      const f = fiches(["cyber"]);
      return { etat: "ok", lines: [fi(["cyber"], "Registre d'incidents") + (f.length ? " dont " + n(f, (r) => (r.values || []).join(" ").toLowerCase().includes("haute") || (r.values || []).join(" ").toLowerCase().includes("critique")) + " de priorité haute/critique." : ""),
        "Session : " + (role() ? "authentifiée (rôle " + role() + ")." : "non authentifiée."), "Surveillance strictement défensive (services GABON 360 AI) ; aucune surveillance de personnes."] };
    },
    memoire(q) {
      const lines = [fi(["memoire"], "Archives territoriales")];
      const a = rows("alertes"), ms = rows("missions"), rp = rows("rapports");
      lines.push("Mémoire disponible : " + [a && a.length + " alertes", ms && ms.length + " missions", rp && rp.length + " rapports"].filter(Boolean).join(", ") + ".");
      if (q) {
        const hits = search(q);
        lines.push(hits.length ? "Résultats pour « " + q + " » (" + hits.length + ") :\n" + hits.slice(0, 5).map((h) => "  - " + h).join("\n") : "Aucun résultat pour « " + q + " » dans les données chargées.");
      }
      return { etat: "ok", lines };
    },
    alertes() {
      const a = rows("alertes"); if (!a) return { etat: "non_relie", lines: [nonRelie("Alertes")] };
      const o = ouvertes();
      return { etat: "ok", lines: [a.length + " alerte(s), " + o.length + " ouverte(s) : " + n(o, (x) => x.priorite === "critique") + " critique(s), " + n(o, (x) => x.priorite === "haute") + " haute(s), " + n(o, (x) => x.statut === "nouvelle") + " nouvelle(s).",
        "Aucune alerte n'est confirmée automatiquement : une personne choisit le statut."] };
    },
    rapports() {
      const r = rows("rapports"); if (!r) return { etat: "non_relie", lines: [nonRelie("Rapports"), fi(["rapports"], "Notes locales")] };
      const par = {}; r.forEach((x) => { par[x.statut || "sans statut"] = (par[x.statut || "sans statut"] || 0) + 1; });
      return { etat: "ok", lines: [r.length + " rapport(s) : " + Object.entries(par).map(([k, v]) => v + " " + k).join(", ") + "."] };
    },
    stats() {
      const a = rows("alertes"), m = rows("missions"), o = rows("observations"), r = rows("rapports"), f = fiches(["stats"]);
      return { etat: a || m || o || r ? "ok" : "partiel", lines: ["Totaux : " + [a && a.length + " alertes", m && m.length + " missions", o && o.length + " observations", r && r.length + " rapports"].filter(Boolean).join(" · ") + ".",
        fi(["stats"], "Indicateurs saisis"), live("stats")].filter(Boolean) };
    },
    meteo() {
      const w = window.G360_LIVE && window.G360_LIVE.weather;
      return { etat: w ? "ok" : "partiel", lines: [live("meteo") || "Météo en direct non vérifiée.", fi(["meteo"], "Relevés météo saisis"),
        "Dépendance : Open-Meteo (internet) ; pas de prévision de risque calculée sans données."] };
    },
    parcs() {
      const ob = rows("observations"), par = {};
      (ob || []).forEach((x) => { const k = x.parc || "parc non précisé"; par[k] = (par[k] || 0) + 1; });
      const top = Object.entries(par).sort((a, b) => b[1] - a[1]).slice(0, 5);
      return { etat: ob ? "ok" : "partiel", lines: [ob ? ob.length + " observation(s) sur " + Object.keys(par).length + " parc(s)" + (top.length ? " ; les plus actifs : " + top.map(([k, v]) => k + " (" + v + ")").join(", ") + "." : ".") : nonRelie("Observations par parc"),
        "Limites des parcs : import Forest Atlas via le relais /api/parcs (internet requis)."] };
    },
    eaux() {
      return { etat: "partiel", lines: [fi(["eaux"], "Observations eaux/océan"), "Dépendance : données maritimes/hydrologiques autorisées (non configurées) ; aucun suivi de personnes."] };
    },
    frontieres() {
      return { etat: "partiel", lines: [fi(["frontieres"], "Signalements frontaliers"), "Contour national : relais /api/frontiere (geoBoundaries, internet requis)."] };
    },
    air() {
      return { etat: "partiel", lines: [fi(["air"], "Signalements aériens"), "Dépendance : source de trafic aérien autorisée (ADS-B/ANAC) non configurée."] };
    },
    centre() {
      const sit = situationLines();
      return { etat: "ok", lines: [fi(["centre"], "Fiches de situation")].concat(sit) };
    },
    admin() {
      const r = role();
      if (!["proprietaire", "administrateur"].includes(r)) return { etat: "partiel", lines: ["Réservé au propriétaire et aux administrateurs (rôle actuel : " + (r || "non connecté") + ")."] };
      return { etat: "ok", lines: [fi(["admin"], "Journal des décisions"), "Le rôle est contrôlé dans l'application ; la protection réelle des données dépend des règles de la base Supabase (non vérifiées)."] };
    },
    users() {
      const r = role(), u = rows("profiles");
      if (!["proprietaire", "administrateur"].includes(r)) return { etat: "partiel", lines: ["Liste des comptes réservée au propriétaire et aux administrateurs."] };
      if (!u) return { etat: "non_relie", lines: [nonRelie("Comptes")] };
      const par = {}; u.forEach((x) => { const k = x.role || "sans rôle"; par[k] = (par[k] || 0) + 1; });
      return { etat: "ok", lines: [u.length + " compte(s) : " + Object.entries(par).map(([k, v]) => v + " " + k).join(", ") + "."] };
    },
    paiements() {
      return { etat: "partiel", lines: [fi(["paiements"], "Références de paiement saisies"),
        "Aucun paiement n'est confirmé côté interface : la vérification doit venir du serveur (server/payments, fournisseur de paiement et clés non configurés ici)."] };
    },
    missions() {
      const m = rows("missions"); if (!m) return { etat: "non_relie", lines: [nonRelie("Missions")] };
      const par = {}; m.forEach((x) => { par[x.statut || "sans statut"] = (par[x.statut || "sans statut"] || 0) + 1; });
      return { etat: "ok", lines: [m.length + " mission(s) : " + Object.entries(par).map(([k, v]) => v + " " + k).join(", ") + "."] };
    },
    garmin() {
      return { etat: "ok", lines: [fi(["garmin"], "Échanges GPX"), "Import/export GPX réalisés dans la page Garmin / GPX ; aucun appareil Garmin n'est relié directement (transfert par fichier)."] };
    }
  };

  const META = {
    accueil: ["index.html (v-ho), gabon360-ia.js", "Synthèse alertes/missions/rapports", "Supabase (connexion)"],
    carte: ["index.html (v-mp), Leaflet", "Positions des alertes et observations", "CDN Leaflet, fonds de carte (internet)"],
    satellites: ["gabon360-centre.js, gabon360-live-connectors.js", "Demandes d'imagerie, lien NASA GIBS", "Copernicus/Sentinel Hub (clés)"],
    drones: ["gabon360-centre.js", "Préparation/suivi administratif des missions drone", "Drone, flux vidéo, autorisation de vol"],
    navigation: ["gabon360-centre.js, gabon360-navigation-offline.js", "Itinéraires, risques, hors ligne", "Fonds de carte hors ligne"],
    geoloc: ["gabon360-centre.js", "Relevés GPS", "Autorisation de position du navigateur"],
    cyber: ["gabon360-centre.js", "Registre d'incidents, état de session", "Journaux serveur (non reliés)"],
    memoire: ["gabon360-centre.js, gabon360-ia22.js (search)", "Archivage et recherche plein texte", "—"],
    alertes: ["index.html (v-al), gabon360-modules-addon.js", "Triage, priorité, absence de position", "Supabase table evenements"],
    rapports: ["index.html (v-rp)", "Répartition par statut", "Supabase table rapports"],
    stats: ["gabon360-centre.js, gabon360-ia22.js", "Totaux et indicateurs", "Supabase"],
    meteo: ["gabon360-live-connectors.js", "Météo actuelle Open-Meteo, relevés saisis", "Internet (Open-Meteo)"],
    parcs: ["index.html (v-pk), api/parcs.js", "Observations par parc, import des limites", "Forest Atlas (internet)"],
    eaux: ["gabon360-centre.js", "Observations cours d'eau et littoral", "Données hydrologiques/maritimes"],
    frontieres: ["gabon360-centre.js, api/frontiere.js", "Signalements, contour national", "geoBoundaries (internet)"],
    air: ["gabon360-centre.js", "Registre de signalements aériens", "Source ADS-B/ANAC"],
    centre: ["gabon360-centre.js, gabon360-ia22.js", "Synthèse des autres IA", "—"],
    admin: ["gabon360-centre.js", "Journal des décisions (rôle admin)", "Supabase RLS"],
    users: ["index.html (v-us)", "Comptes par rôle (rôle admin)", "Supabase table profiles"],
    paiements: ["gabon360-centre.js, server/payments (non déployé)", "Suivi manuel des références", "Fournisseur de paiement + clés + serveur"],
    missions: ["index.html (v-ms)", "Statuts et distances", "Supabase table missions"],
    garmin: ["index.html (v-gx)", "Import/export GPX", "Fichiers GPX/appareil Garmin"]
  };

  function runSkill(id, q) {
    const f = SK[id]; if (!f) return { etat: "non_relie", lines: ["Aucune fonction définie pour cette IA."] };
    try { return f(q); } catch (e) { return { etat: "erreur", lines: ["Erreur interne de l'IA " + id + " : " + e.message] }; }
  }
  function situationLines() {
    const out = [];
    ["alertes", "missions", "rapports"].forEach((id) => { const r = runSkill(id); out.push("• " + id + " : " + r.lines[0]); });
    const w = live("meteo"); if (w) out.push("• " + w.split("\n")[0]);
    return out;
  }
  function search(q) {
    const t = String(q || "").toLowerCase().trim(); if (!t) return [];
    const hits = [];
    fiches(Object.keys(SK)).forEach((r) => { const s = (r.title || "") + " " + (r.values || []).join(" "); if (s.toLowerCase().includes(t)) hits.push("fiche " + r.module + " : " + (r.title || r.moduleName || "") + " — " + (r.values || []).filter(Boolean).join("; ").slice(0, 120)); });
    [["alertes", "alerte", "titre"], ["missions", "mission", "titre"], ["rapports", "rapport", "titre"]].forEach(([n_, lib, c]) => (rows(n_) || []).forEach((x) => { if (String(x[c] || "").toLowerCase().includes(t)) hits.push(lib + " : " + x[c]); }));
    return hits;
  }

  // ---- 3. Routage par l'avatar ---------------------------------------------------------------
  const ROUTES = [
    ["satellites", /satellite|imagerie|sentinel|copernicus/], ["drones", /drone/], ["meteo", /m[ée]t[ée]o|pluie|orage|vent|temp[ée]rature/],
    ["cyber", /cyber|piratage|incident informatique|s[ée]curit[ée] informatique/], ["paiements", /paiement|abonnement|facture/],
    ["garmin", /garmin|gpx/], ["geoloc", /g[ée]olocalis|ma position|o[uù] suis/], ["navigation", /navigation|itin[ée]raire|chemin/],
    ["frontieres", /fronti[èe]re/], ["air", /a[ée]rien|avion|vol\b/], ["eaux", /\beau|oc[ée]an|mer\b|rivi[èe]re|fleuve|littoral/],
    ["parcs", /parc|faune|biodiversit/], ["alertes", /alerte|anomalie|critique/], ["missions", /mission|patrouille/], ["rapports", /rapport/],
    ["users", /utilisateur|compte|r[ôo]le/], ["admin", /administrat|r[ée]glage/], ["memoire", /m[ée]moire|archive|retrouve|cherche/],
    ["stats", /statistique|chiffre|combien/], ["carte", /carte|cartograph/], ["centre", /situation|centre national|synth[èe]se|point de situation/]
  ];
  const routeId = (q) => { const t = String(q || "").toLowerCase(); const r = ROUTES.find(([, re]) => re.test(t)); return r ? r[0] : null; };

  function boot() {
    const G = window.G360_IA; if (!G || !G.avatar || !Array.isArray(G.agents)) return false;
    const Av = G.avatar;
    let lastQ = "";
    if (location.protocol === "file:" && apiBase()) G.endpoint = apiBase() + "/api/assistant";
    G.agents.forEach((a) => { const m = META[a.id]; if (m) { a.files = m[0]; a.fonctions = m[1]; a.dependances = m[2]; } a.skill = (q) => runSkill(a.id, q); });
    // Complète la réponse « état vérifiable » de chaque IA avec sa fonction propre.
    const deliver = Av.deliver;
    const vus = new Map(); let dernierAuto = 0; const file = [];
    const autoMsg = (x) => typeof x === "string" && x.indexOf("Nouvelle information reçue") === 0;
    const vider = () => { const it = file.shift(); if (it) { dernierAuto = Date.now(); deliver.call(Av, it.agent, it.text, it.mode); } if (file.length) setTimeout(vider, 6000); };
    Av.deliver = function (agent, text, mode) {
      let t = text;
      if (autoMsg(text)) {
        // Annonce automatique : pas de répétition (60 s), source et date indiquées, une annonce toutes les 6 s au plus.
        const k = (agent && agent.id) + "|" + text, now = Date.now();
        if (vus.has(k) && now - vus.get(k) < 60000) return;
        vus.set(k, now);
        t = text + "\nSource : données de l'application GABON 360 AI · détecté le " + new Date(now).toLocaleString("fr-FR") + ".";
        if (now - dernierAuto < 6000) { file.push({ agent, text: t, mode }); if (file.length === 1) setTimeout(vider, 6000 - (now - dernierAuto)); return; }
        dernierAuto = now;
        return deliver.call(this, agent, t, mode);
      }
      try { if (agent && String(text).indexOf(agent.page + " — état vérifiable") === 0) { const r = runSkill(agent.id, lastQ); t = text + "\n— Analyse « " + agent.page + " » (" + r.etat + ") —\n" + r.lines.join("\n"); } } catch (_) {}
      return deliver.call(this, agent, t, mode);
    };
    // L'avatar choisit l'IA compétente d'après la question.
    const ask = Av.ask;
    Av.ask = function (id, q) {
      lastQ = q || "";
      const target = q ? routeId(q) : null;
      return ask.call(this, target || id, q);
    };
    // Remontée des 22 IA vers l'avatar.
    G.situation = function () {
      const a0 = G.agents.find((x) => x.id === "centre") || G.agents[0];
      const lines = G.agents.map((a) => { const r = runSkill(a.id); return "[" + a.page + "] " + r.etat + " — " + r.lines[0]; });
      Av.deliver(a0, "Point de situation des 22 IA :\n" + lines.join("\n"), "local");
    };
    const go = document.getElementById("g360-go");
    if (go && !document.getElementById("g360-all")) {
      const b = document.createElement("button"); b.id = "g360-all"; b.textContent = "📋 Point de situation"; b.onclick = () => { G.voiceUnlocked = true; G.situation(); };
      go.insertAdjacentElement("afterend", b);
    }
    return true;
  }

  // ---- 4. Auto-test (à lancer dans le navigateur : G360_IA22.selfTest()) ----------------------
  function selfTest() {
    const G = window.G360_IA || { agents: [] };
    const res = Object.keys(SK).map((id) => {
      const r = runSkill(id), a = G.agents.find((x) => x.id === id);
      const pageEl = document.querySelector('[data-ia="' + id + '"]') || document.getElementById("g360-page-" + id) || document.getElementById("v-" + id);
      return { ia: id, enregistree: !!a, fonction: r.etat !== "erreur", etat: r.etat, page: !!pageEl, relaisAvatar: typeof avSay === "function" && !!(G.avatar && G.avatar.deliver) };
    });
    console.table(res); return res;
  }

  window.G360_IA22 = { skills: SK, meta: META, run: runSkill, search, route: routeId, selfTest, boot };
  if (!boot()) window.addEventListener("load", boot);
})();
