# GABON 360 AI — correctifs v2 (branche test-avatar-central)

## Cause réelle du blocage
Deux MutationObserver (gabon360-live-connectors.js ligne 115 et gabon360-ia.js ligne 191)
surveillent tout le document et réécrivent le DOM à chaque appel : boucle infinie au chargement,
la page se fige, aucun bouton ne répond. Confirmé en arrêtant la page figée avec le débogueur Chrome
(pile : statusCards -> MutationObserver) et en désactivant le script fautif (la page se charge alors).

## Fichiers modifiés (4, aucun supprimé, aucun autre touché)
1. gabon360-live-connectors.js : l'observateur se déconnecte pendant son travail (cause principale).
2. gabon360-ia.js : même protection sur l'observateur de mount() (cause latente, même défaut).
3. gabon360-centre.js : apostrophes non échappées (erreur de syntaxe, fichier non chargé).
4. gabon360-modules-addon.js : le bouton flottant « + Modules IA » prenait toute la largeur (CSS) et
   recouvrait le bas de l'écran ; il est désormais compact (width:auto).

## IMPORTANT : l'APK ne se met pas à jour tout seul
L'APK de test embarque une COPIE des fichiers au moment de la construction (build-apk-test.yml,
chargée en file:///android_asset/site/). Après avoir poussé ces fichiers, il faut relancer la
construction de l'APK et le réinstaller. Un ancien APK garde l'ancien bug.

## Vérifier que le bon code est en ligne (depuis le téléphone)
Ouvrez  <votre-lien-vercel>/gabon360-live-connectors.js  et cherchez « g360Obs ».
Absent = ce n'est pas la version corrigée qui est déployée.
Les empreintes SHA-256 des fichiers corrects sont dans SHA256SUMS.txt.
