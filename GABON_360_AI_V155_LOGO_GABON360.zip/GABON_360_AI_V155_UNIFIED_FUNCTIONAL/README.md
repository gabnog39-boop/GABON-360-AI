# GABON 360 AI V290 — functional Android build

Cette version remplace la maquette locale précédente par une application Android réellement interactive en mode local : navigation par modules, événements, alertes, missions, audit, rapport JSON, commande vocale native, synthèse vocale native, GPS, caméra du téléphone et contrôles OWNER de démonstration.

Les données satellite, SIG officiel, caméras distantes, drones, météo et paiement restent des intégrations serveur à brancher sur l'infrastructure de production. L'application ne prétend pas être connectée à ces flux tant qu'ils ne sont pas configurés.

Le workflow GitHub Actions compile directement le projet Android présent dans le dépôt.


## Identité visuelle
Le logo officiel GABON 360 fourni par le concepteur est intégré à l'interface et utilisé comme icône de l'application.
