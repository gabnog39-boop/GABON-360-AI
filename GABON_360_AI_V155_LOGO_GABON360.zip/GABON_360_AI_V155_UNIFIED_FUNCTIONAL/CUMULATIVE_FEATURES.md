# GABON 360 AI — V155 UNIFIED FUNCTIONAL

Cette version unifie dans une seule application Android les capacités cumulées développées jusqu'à V155.

## Fonctions opérationnelles locales
- Centre de situation
- carte locale interactive avec événements
- 13 parcs nationaux + 9 provinces
- couches SIG de démonstration
- sources / état / rafraîchissement
- alertes et prise en compte
- événements + validation humaine
- missions + clôture
- scénario bout-en-bout
- historique et audit local
- rapports JSON + sauvegarde Android
- partage de rapport
- commande texte
- reconnaissance vocale native Android
- synthèse vocale native Android
- avatar animé pendant la parole
- GPS du téléphone
- caméra du téléphone
- contrôle OWNER local (suspension/réactivation)
- paramètres et persistance locale

## Capacités backend cumulées embarquées comme références
Les bundles backend V123 à V154 sont inclus dans `app/src/main/assets/backend_versions/` afin de conserver l'architecture et les évolutions dans un seul projet.
Ils ne sont pas exécutés comme serveur dans l'APK : un déploiement backend sécurisé reste nécessaire pour les vrais flux satellite, SIG, caméras, drones, paiements, authentification et données opérationnelles.

## Principe
L'application ne présente pas les données de démonstration comme des flux réels. Les connexions production doivent être ajoutées côté serveur sécurisé.
