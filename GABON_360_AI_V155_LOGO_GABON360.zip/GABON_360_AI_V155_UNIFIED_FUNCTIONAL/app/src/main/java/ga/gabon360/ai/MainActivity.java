package ga.gabon360.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private LocationManager locationManager;
    private static final int REQ_AUDIO = 7001;
    private static final int REQ_LOCATION = 7002;
    private static final int REQ_CAMERA = 7003;
    private static final int REQ_CAPTURE = 7004;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.FRENCH); });
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(request.getResources());
                    else { request.deny(); requestAudioPermission(); }
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) callback.invoke(origin, true, false);
                else { callback.invoke(origin, false, false); requestLocationPermission(); }
            }
        });
        web.addJavascriptInterface(new Bridge(), "G360");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void requestAudioPermission(){ if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); }
    private void requestLocationPermission(){ if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); }
    private void requestCamera(){ if (checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA); else openCamera(); }

    private void openCamera(){
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, REQ_CAPTURE);
        else web.evaluateJavascript("window.onNativeCamera('');", null);
    }

    private void startRecognition(){
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { web.evaluateJavascript("window.onNativeVoiceError('Reconnaissance vocale indisponible sur cet appareil');", null); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestAudioPermission(); return; }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { web.evaluateJavascript("window.onNativeVoiceState('Écoute…');", null); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { web.evaluateJavascript("window.onNativeVoiceState('Traitement…');", null); }
            public void onError(int e) { web.evaluateJavascript("window.onNativeVoiceError('Erreur micro : "+e+"');", null); }
            public void onResults(Bundle b) {
                ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(r!=null && !r.isEmpty()) web.evaluateJavascript("window.onNativeVoice("+org.json.JSONObject.quote(r.get(0))+");", null);
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int a, Bundle b) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez à GABON 360 AI");
        recognizer.startListening(i);
    }

    private void getLocation(){
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) { requestLocationPermission(); return; }
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        try {
            Location last=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(last==null) last=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(last!=null) sendLocation(last);
            locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, new LocationListener(){public void onLocationChanged(Location l){sendLocation(l);} public void onProviderEnabled(String p){} public void onProviderDisabled(String p){} public void onStatusChanged(String p,int s,Bundle b){}}, null);
        } catch(Exception e){ web.evaluateJavascript("window.onNativeLocationError('GPS indisponible');", null); }
    }
    private void sendLocation(Location l){ web.evaluateJavascript("window.onNativeLocation("+l.getLatitude()+","+l.getLongitude()+","+l.getAccuracy()+");", null); }

    private void saveText(String name,String text){
        try {
            if(android.os.Build.VERSION.SDK_INT>=29){
                android.content.ContentValues v=new android.content.ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/GABON_360_AI");
                Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u!=null){try(OutputStream o=getContentResolver().openOutputStream(u)){o.write(text.getBytes("UTF-8"));}}
            } else { File d=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); d.mkdirs(); File f=new File(d,name); try(FileOutputStream o=new FileOutputStream(f)){o.write(text.getBytes("UTF-8"));} MediaScannerConnection.scanFile(this,new String[]{f.getAbsolutePath()},null,null); }
            web.evaluateJavascript("window.onNativeSaved('"+name.replace("'","\\'")+"');",null);
        }catch(Exception e){web.evaluateJavascript("window.onNativeSaveError('"+e.getMessage().replace("'","\\'")+"');",null);}
    }

    private void share(String text){ Intent s=new Intent(Intent.ACTION_SEND); s.setType("text/plain"); s.putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(s,"Partager GABON 360 AI")); }

    public class Bridge {
        @JavascriptInterface public void speak(String text){runOnUiThread(()->{if(tts!=null){tts.stop();tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"g360");}});}
        @JavascriptInterface public void stopSpeak(){runOnUiThread(()->{if(tts!=null)tts.stop();});}
        @JavascriptInterface public void startVoice(){runOnUiThread(()->startRecognition());}
        @JavascriptInterface public void stopVoice(){runOnUiThread(()->{if(recognizer!=null)recognizer.stopListening();});}
        @JavascriptInterface public void getLocation(){runOnUiThread(()->MainActivity.this.getLocation());}
        @JavascriptInterface public void saveReport(String name,String text){runOnUiThread(()->saveText(name,text));}
        @JavascriptInterface public void share(String text){runOnUiThread(()->MainActivity.this.share(text));}
        @JavascriptInterface public void camera(){runOnUiThread(()->requestCamera());}
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQ_CAMERA && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) openCamera();
        if(requestCode==REQ_AUDIO && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) web.evaluateJavascript("window.onNativeVoiceState('Microphone autorisé');", null);
        if(requestCode==REQ_LOCATION && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) getLocation();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data); if(requestCode==REQ_CAPTURE){if(resultCode==RESULT_OK && data!=null && data.getExtras()!=null){Bitmap b=(Bitmap)data.getExtras().get("data");try{ByteArrayOutputStream o=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,82,o);String x=Base64.encodeToString(o.toByteArray(),Base64.NO_WRAP);web.evaluateJavascript("window.onNativeCamera('data:image/jpeg;base64,"+x+"');",null);}catch(Exception e){web.evaluateJavascript("window.onNativeCamera('');",null);}}else web.evaluateJavascript("window.onNativeCamera('');",null);}}
    @Override protected void onDestroy(){if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}
