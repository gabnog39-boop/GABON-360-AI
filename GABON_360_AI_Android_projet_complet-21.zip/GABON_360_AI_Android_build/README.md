# GABON 360 AI — Android

Application Android WebView locale pour le prototype GABON 360 AI.

- Application ID: `ga.gabon360.ai`
- Version: 1.0.0
- Interface: prototype V290 embarqué dans `app/src/main/assets/index.html`
- Icône: GABON 360 AI
- Build: Android Gradle Plugin 8.6.1 / compileSdk 35

Les données satellite, SIG, caméras et alertes du prototype restent des données de démonstration tant que des services réels autorisés ne sont pas connectés.
