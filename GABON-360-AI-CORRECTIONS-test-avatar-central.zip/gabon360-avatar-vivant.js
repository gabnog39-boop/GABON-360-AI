/* GABON 360 AI — Avatar central vivant (v1)
   Animation 2D en temps réel (canvas) de l'image ORIGINALE de l'avatar (assets/avatar-central.jpg).
   - clignement des yeux, respiration, mouvements de tête/corps, sourcils, expressions
   - bouche pilotée par le texte prononcé (voyelles/consonnes) et resynchronisée par les événements
     de parole (boundary / onRangeStart natif). Ce n'est PAS une analyse du signal audio.
   - voix : Android TextToSpeech natif (prioritaire, sans geste utilisateur) sinon speechSynthesis
   - les mains ne sont pas animées séparément (image unique) : gestes = hochement, inclinaison, avancée du buste
   Aucune dépendance. Ne modifie pas le visage : seules des régions de l'image sont déplacées. */
(function () {
  'use strict';
  if (window.G360_AVATAR_VIVANT) return;

  var SRC = './assets/avatar-central.jpg';
  var REF_W = 1145;                       // coordonnées de référence = image originale 1145 x 1374
  var EYES = [{ x: 465, y: 331, rx: 46, ry: 18 }, { x: 624, y: 347, rx: 42, ry: 18 }];
  var BROWS = [{ x: 470, y: 292, rx: 80, ry: 26 }, { x: 640, y: 318, rx: 78, ry: 26 }];
  var MOUTH = { x: 528, y: 505, rx: 68, ry: 34 };
  var PIVOT = { x: 570, y: 1000 };

  var API = window.G360_AVATAR_VIVANT = {
    version: 1, ready: false, frames: 0, blinks: 0, speakStarts: 0, maxMouth: 0,
    state: 'idle', speaking: false, voice: 'aucune'
  };

  var img = new Image(), base = document.createElement('canvas');
  var W = 0, H = 0, K = 1, skin = ['#7a4f3d', '#7a4f3d'];
  var sprites = {};
  var stageCanvas = null, launchCanvas = null;

  /* ---------- état d'animation ---------- */
  var S = {
    mouth: 0, mouthT: 0, wide: 0,
    blink: 0, blinkAt: 0, blinkPhase: -1,
    brow: 0, browT: 0,
    nod: 0, nodT: 0, tilt: 0, tiltT: 0, lean: 0, leanT: 0,
    gestureAt: 0, t0: Date.now(), alert: 0,
    text: '', idx: 0, tpc: 62, start: 0, speakEnd: 0, utt: null, mode: ''
  };

  function rnd(a, b) { return a + Math.random() * (b - a); }
  function lerp(a, b, f) { return a + (b - a) * f; }

  /* ---------- préparation des sprites ---------- */
  function sprite(cx, cy, rx, ry) {
    var x = Math.max(0, Math.round((cx - rx) * K)), y = Math.max(0, Math.round((cy - ry) * K));
    var w = Math.min(W - x, Math.round(rx * 2 * K)), h = Math.min(H - y, Math.round(ry * 2 * K));
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var g = c.getContext('2d');
    g.drawImage(base, x, y, w, h, 0, 0, w, h);
    var m = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.18, w / 2, h / 2, Math.max(w, h) / 2);
    m.addColorStop(0, 'rgba(0,0,0,1)'); m.addColorStop(0.62, 'rgba(0,0,0,0.95)'); m.addColorStop(1, 'rgba(0,0,0,0)');
    g.globalCompositeOperation = 'destination-in'; g.fillStyle = m; g.fillRect(0, 0, w, h);
    return { c: c, x: x, y: y, w: w, h: h };
  }
  function avg(x, y, w, h) {
    var d = base.getContext('2d').getImageData(Math.round(x * K), Math.round(y * K), Math.max(1, Math.round(w * K)), Math.max(1, Math.round(h * K))).data;
    var r = 0, g = 0, b = 0, n = d.length / 4;
    for (var i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; }
    return 'rgb(' + Math.round(r / n) + ',' + Math.round(g / n) + ',' + Math.round(b / n) + ')';
  }
  function prepare() {
    W = img.naturalWidth; H = img.naturalHeight; K = W / REF_W;
    base.width = W; base.height = H;
    base.getContext('2d').drawImage(img, 0, 0);
    sprites.browL = sprite(BROWS[0].x, BROWS[0].y, BROWS[0].rx, BROWS[0].ry);
    sprites.browR = sprite(BROWS[1].x, BROWS[1].y, BROWS[1].rx, BROWS[1].ry);
    sprites.jaw = sprite(MOUTH.x, MOUTH.y + 30, MOUTH.rx + 8, 30);
    sprites.lid = EYES.map(function (e) { return sprite(e.x, e.y - 17, e.rx * 0.95, 8); });
    skin = [avg(EYES[0].x - 16, EYES[0].y + 42, 32, 10), avg(EYES[1].x - 16, EYES[1].y + 42, 32, 10)];
    API.ready = true;
  }

  /* ---------- rendu ---------- */
  function drawFrame(ctx, cw, ch, crop) {
    if (!API.ready) return;
    ctx.save();
    ctx.clearRect(0, 0, cw, ch);
    var c = crop || { x: 0, y: 0, w: W, h: H };
    ctx.scale(cw / c.w, ch / c.h); ctx.translate(-c.x, -c.y);
    // mouvements globaux : respiration, balancement, hochement, avancée du buste
    var px = PIVOT.x * K, py = PIVOT.y * K;
    ctx.translate(px, py);
    ctx.rotate(S.tilt * Math.PI / 180);
    var sc = 1 + 0.004 * Math.sin((Date.now() - S.t0) / 1500) + S.lean * 0.035;
    ctx.scale(sc, sc);
    ctx.translate(-px, -py + S.nod * K);
    ctx.drawImage(base, 0, 0);
    // sourcils
    var bl = S.brow * 7 * K;
    if (Math.abs(bl) > 0.2) {
      ctx.drawImage(sprites.browL.c, sprites.browL.x, sprites.browL.y - bl);
      ctx.drawImage(sprites.browR.c, sprites.browR.x, sprites.browR.y - bl);
    }
    // yeux : la vraie peau de la paupière est étirée sur l'œil (texture et couleur d'origine)
    if (S.blink > 0.02) {
      for (var i = 0; i < 2; i++) {
        var e = EYES[i], L = sprites.lid[i], rx = e.rx * 0.95 * K;
        var extra = 23 * K * S.blink;
        ctx.drawImage(L.c, L.x, L.y, L.w, L.h + extra);
        ctx.save(); ctx.strokeStyle = 'rgba(22,10,8,' + (0.55 * Math.min(1, S.blink * 2)) + ')'; ctx.lineWidth = 1.5 * K;
        ctx.beginPath(); ctx.ellipse(e.x * K, L.y + L.h + extra - 1 * K, rx * 0.9, 1.6 * K, 0, 0.15, Math.PI - 0.15); ctx.stroke();
        ctx.restore();
      }
    }
    // bouche : lèvre inférieure/menton abaissés, intérieur sombre, dents
    var d = S.mouth * 27 * K;
    if (d > 0.8) {
      var mx = MOUTH.x * K, my = MOUTH.y * K, w = (46 - S.wide * 12) * K;
      ctx.save();
      ctx.shadowColor = '#1d0709'; ctx.shadowBlur = 4 * K; ctx.fillStyle = '#2a0c0f';
      ctx.beginPath(); ctx.ellipse(mx, my + d * 0.5, w, d * 0.56 + 2 * K, 0, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      if (d > 5 * K) {
        ctx.fillStyle = 'rgba(232,224,210,.78)';
        var th = Math.min(d * 0.32, 5 * K);
        ctx.fillRect(mx - w * 0.62, my - 1 * K, w * 1.24, th);
      }
      var j = sprites.jaw;
      ctx.drawImage(j.c, j.x - (S.wide * 3 * K), j.y + d, j.w + S.wide * 6 * K, j.h);
    }
    ctx.restore();
    API.frames++;
  }

  /* ---------- logique de vie ---------- */
  var VOW = { a: 1, 'à': 1, 'â': 1, e: 0.62, 'é': 0.7, 'è': 0.8, 'ê': 0.8, i: 0.42, y: 0.42, o: 0.72, 'ô': 0.72, u: 0.5, 'ù': 0.5, 'û': 0.5, 'œ': 0.7 };
  function visemeAt(i) {
    var ch = (S.text.charAt(i) || ' ').toLowerCase();
    if (VOW[ch] != null) { S.wide = (ch === 'o' || ch === 'u' || ch === 'ô' || ch === 'ù' || ch === 'û') ? 1 : 0; return VOW[ch]; }
    S.wide = 0;
    if ('mbp'.indexOf(ch) >= 0) return 0;
    if (',.;:!?\n'.indexOf(ch) >= 0) return 0;
    if (ch === ' ') return 0.08;
    return 0.28;
  }

  function startSpeech(text, mode) {
    S.text = String(text || ''); S.mode = mode; S.idx = 0; S.start = Date.now();
    S.tpc = 62; S.speakEnd = S.start + S.text.length * S.tpc * 1.7 + 2500;
    API.speaking = true; API.speakStarts++; API.voice = mode === 'native' ? 'Android TTS natif' : 'speechSynthesis';
    setState(/alerte|urgence|danger|critique|incendie|intrusion|braconn/i.test(S.text) ? 'alert' : 'speak');
  }
  function endSpeech() {
    API.speaking = false; S.mouthT = 0;
    if (API.state === 'speak' || API.state === 'alert') setState('idle');
  }
  function syncIdx(i) { S.idx = i; S.start = Date.now() - i * S.tpc; }

  function setState(st) {
    API.state = st;
    S.browT = st === 'alert' ? 1 : st === 'think' ? 0.55 : st === 'listen' ? 0.35 : 0;
    S.alert = st === 'alert' ? 1 : 0;
    S.tiltT = st === 'listen' ? 3 : st === 'think' ? -2 : 0;
    S.leanT = st === 'alert' ? 0.9 : st === 'listen' ? 0.6 : 0;
    [stageCanvas && stageCanvas.parentNode, document.getElementById('g360-avatar-launch')].forEach(function (el) {
      if (!el) return;
      el.setAttribute('data-vivant', st);
    });
  }
  API.setState = setState;
  API.say = function (t) { startSpeech(t, 'web'); };

  function gesture(now) {
    if (now < S.gestureAt) return;
    S.gestureAt = now + rnd(1400, 3200);
    var g = Math.floor(Math.random() * 4);
    if (g === 0) { S.nodT = 5; setTimeout(function () { S.nodT = 0; }, 260); }
    else if (g === 1) { S.tiltT = rnd(-3.2, 3.2); setTimeout(function () { S.tiltT = API.state === 'listen' ? 3 : 0; }, 900); }
    else if (g === 2) { S.leanT = 0.7; setTimeout(function () { S.leanT = API.state === 'alert' ? 0.9 : 0; }, 1000); }
    else { S.browT = Math.max(S.browT, 0.6); setTimeout(function () { S.browT = API.state === 'alert' ? 1 : 0; }, 700); }
  }

  function update(now) {
    // clignement (naturel : 2,2 – 5,5 s ; plus rapide en parole)
    if (!S.blinkAt) S.blinkAt = now + rnd(900, 2500);
    if (S.blinkPhase < 0 && now >= S.blinkAt) { S.blinkPhase = 0; API.blinks++; }
    if (S.blinkPhase >= 0) {
      S.blinkPhase += 1 / 7;                       // ~230 ms à 30 i/s
      S.blink = S.blinkPhase < 0.5 ? S.blinkPhase * 2 : Math.max(0, 2 - S.blinkPhase * 2);
      if (S.blinkPhase >= 1) { S.blinkPhase = -1; S.blink = 0; S.blinkAt = now + rnd(2200, 5500) * (API.speaking ? 0.75 : 1); }
    }
    // parole
    if (API.speaking) {
      if (!S.idxFromEvent) S.idx = Math.floor((now - S.start) / S.tpc);
      if (now > S.speakEnd) endSpeech();            // garde-fou si aucun événement de fin n'arrive
      S.mouthT = (S.idx >= S.text.length) ? 0 : visemeAt(S.idx) * (0.85 + 0.15 * Math.sin(now / 55));
      gesture(now);
    } else { S.mouthT = 0; }
    S.mouth = lerp(S.mouth, S.mouthT, 0.5);
    if (S.force) { for (var fk in S.force) S[fk] = S.force[fk]; }
    if (S.mouth > API.maxMouth) API.maxMouth = S.mouth;
    S.brow = lerp(S.brow, S.browT, 0.12);
    S.nod = lerp(S.nod, S.nodT, 0.3);
    S.tilt = lerp(S.tilt, S.tiltT + 0.35 * Math.sin((now - S.t0) / 2300), 0.08);
    S.lean = lerp(S.lean, S.leanT, 0.08);
  }

  /* ---------- montage dans la page ---------- */
  function mount() {
    var stage = document.getElementById('g360-avatar-stage');
    var st = document.createElement('style');
    st.textContent = '#g360-vivant-stage{max-width:100%;height:auto;border-radius:12px;display:block}' +
      '#g360-avatar-stage[data-vivant="alert"]{box-shadow:0 0 0 3px #ff4d4d,0 0 26px #ff4d4d88}' +
      '#g360-avatar-stage[data-vivant="speak"]{box-shadow:0 0 0 2px #35e6a0aa}' +
      '#g360-avatar-stage[data-vivant="listen"]{box-shadow:0 0 0 2px #4db8ffaa}' +
      '#g360-vivant-launch{width:100%;height:100%;display:block;border-radius:50%}';
    document.head.appendChild(st);
    // images d'avatar cassées (AVATAR_DATA) -> image originale
    [].slice.call(document.querySelectorAll('img[alt*="vatar"],img[alt*="VATAR"]')).forEach(function (im) {
      if (/AVATAR_DATA/.test(im.getAttribute('src') || '')) im.src = SRC;
    });
    if (stage) {
      var old = document.getElementById('g360-avatar-img');
      stageCanvas = document.createElement('canvas'); stageCanvas.id = 'g360-vivant-stage';
      stageCanvas.width = 430; stageCanvas.height = Math.round(430 * H / W);
      stageCanvas.style.width = 'min(430px,82vw)';
      stageCanvas.setAttribute('role', 'img'); stageCanvas.setAttribute('aria-label', 'Avatar central GABON 360 AI animé');
      if (old) { old.style.display = 'none'; old.parentNode.insertBefore(stageCanvas, old); } else stage.appendChild(stageCanvas);
    }
    var launch = document.getElementById('g360-avatar-launch');
    if (launch) {
      var li = launch.querySelector('img'); if (li) li.style.display = 'none';
      launchCanvas = document.createElement('canvas'); launchCanvas.id = 'g360-vivant-launch';
      launchCanvas.width = 184; launchCanvas.height = 184; launch.appendChild(launchCanvas);
    }
  }

  /* ---------- voix : redirection native + événements ---------- */
  function hookVoice() {
    var raw = window.AndroidTTS;
    function nativeReady() { try { return !!(raw && raw.isReady && raw.isReady()); } catch (e) { return false; } }
    if (raw && !raw.__g360w) {
      var wrap = {
        __g360w: 1,
        isReady: function () { return raw.isReady(); },
        speak: function (t) { S.utt = null; startSpeech(t, 'native'); raw.speak(String(t)); },
        stopSpeak: function () { endSpeech(); raw.stopSpeak(); }
      };
      try { window.AndroidTTS = wrap; } catch (e) { /* pont non remplaçable : les événements natifs suffisent */ }
    }
    var ss = window.speechSynthesis;
    if (ss && !ss.__g360w) {
      var oSpeak = ss.speak.bind(ss), oCancel = ss.cancel.bind(ss);
      ss.speak = function (u) {
        var text = (u && u.text) || '';
        if (nativeReady()) {              // dans l'APK : voix native, sans geste utilisateur requis
          S.utt = u; startSpeech(text, 'native');
          try { raw.speak(text); } catch (e) { endSpeech(); }
          try { u && typeof u.onstart === 'function' && u.onstart({}); } catch (e) { }
          return;
        }
        S.utt = null; startSpeech(text, 'web');
        try {
          u.addEventListener('boundary', function (ev) { if (ev && ev.charIndex != null) { S.idxFromEvent = true; syncIdx(ev.charIndex); } });
          u.addEventListener('end', endSpeech); u.addEventListener('error', endSpeech);
        } catch (e) { }
        oSpeak(u);
      };
      ss.cancel = function () { try { oCancel(); } catch (e) { } if (nativeReady()) { try { raw.stopSpeak(); } catch (e) { } } endSpeech(); };
      ss.__g360w = true;
    }
  }
  // événements envoyés par MainActivity (UtteranceProgressListener)
  API.native = function (ev, s) {
    if (ev === 'start') { S.idxFromEvent = false; }
    else if (ev === 'range') { S.idxFromEvent = true; syncIdx(s || 0); }
    else if (ev === 'done') {
      var u = S.utt; S.utt = null; endSpeech(); S.idxFromEvent = false;
      try { if (u && typeof u.onend === 'function') u.onend({}); } catch (e) { }
    }
  };

  /* ---------- réactions aux IA, aux alertes et aux messages ---------- */
  function hookIA() {
    var A = window.G360_IA && window.G360_IA.avatar;
    if (A && typeof A.deliver === 'function' && !A.__g360w) {
      var o = A.deliver;
      A.deliver = function (agent, text) {
        try {
          var t = String(text || '');
          if (/alerte|urgence|danger|critique|incendie|intrusion|braconn/i.test(t)) setState('alert');
          else if (!API.speaking) { setState('think'); setTimeout(function () { if (!API.speaking && API.state === 'think') setState('idle'); }, 1800); }
          API.lastAgent = agent && (agent.page || agent.id) || null;
          var s = document.getElementById('g360-avatar-status');
          if (s && API.lastAgent) s.textContent = 'IA « ' + API.lastAgent + ' » → avatar central';
        } catch (e) { }
        return o.apply(this, arguments);
      };
      A.__g360w = true;
    }
    window.addEventListener('g360:avatar-message', function (ev) {
      var d = ev && ev.detail; if (d && /alerte|urgence|danger|critique|incendie|intrusion|braconn/i.test(String(d.text || ''))) setState('alert');
    });
    var L = document.getElementById('g360-avatar-listen');
    if (L) L.addEventListener('click', function () { setState('listen'); setTimeout(function () { if (API.state === 'listen') setState('idle'); }, 9000); });
  }

  /* ---------- boucle ---------- */
  var last = 0;
  function loop(ts) {
    requestAnimationFrame(loop);
    if (document.hidden || !API.ready) return;
    if (ts - last < 33) return; last = ts;
    update(Date.now());
    var face = { x: 380 * K, y: 215 * K, w: 330 * K, h: 330 * K };
    if (launchCanvas) drawFrame(launchCanvas.getContext('2d'), launchCanvas.width, launchCanvas.height, face);
    if (stageCanvas && stageCanvas.offsetParent !== null) drawFrame(stageCanvas.getContext('2d'), stageCanvas.width, stageCanvas.height);
  }
  API.force = function (o) { S.force = o || null; };
  API.selfTest = function () {
    return { ready: API.ready, frames: API.frames, blinks: API.blinks, speakStarts: API.speakStarts, maxMouth: +API.maxMouth.toFixed(2), voice: API.voice, state: API.state };
  };

  function init() {
    img.onload = function () { prepare(); mount(); hookVoice(); hookIA(); requestAnimationFrame(loop); };
    img.onerror = function () { API.error = 'image avatar introuvable : ' + SRC; };
    img.src = SRC;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
