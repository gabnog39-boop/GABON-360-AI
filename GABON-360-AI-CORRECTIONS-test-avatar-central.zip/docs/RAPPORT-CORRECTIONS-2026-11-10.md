# Rapport — corrections GABON 360 AI (copie de travail de « test-avatar-central »)
Date : 2026-11-10. Ni `main` ni `principal` touchés. Aucune clé de signature touchée. Rien poussé sur GitHub.

## 1. Audit — problèmes constatés
1. **index.html corrompu (cause probable des boutons inertes)** : un bloc de 22 Ko (enregistrement du service worker + avatar central V1 + avatar « vie » V1) avait été injecté à l'intérieur d'une chaîne JavaScript (fonction d'export PDF des rapports). Résultat : erreur « Invalid or unexpected token » → tout le script principal (80 Ko) ne s'exécutait pas, et le bouton/modal de l'avatar n'existaient pas dans le DOM.
2. **Icône officielle absente** : `icons/gabon360-icon.jpg` = 2 654 octets, tronqué/illisible. Le script d'icônes générait alors **silencieusement un logo de remplacement dessiné** (l'APK fournie contenait donc ce faux logo).
3. **Ressources d'icône absentes du dépôt** (aucun PNG sous `android/`), dépendance totale au workflow.
4. **Image d'avatar cassée** : `src="data:image/jpeg;base64,AVATAR_DATA"` (texte de remplacement jamais substitué).
5. **Avatar non animé** : seulement des animations CSS de l'image fixe ; aucun clignement, aucune synchronisation bouche/voix.
6. **Voix automatique** : `speechSynthesis` exige un geste utilisateur dans une WebView ; seule la voix native Android peut parler sans appui.
7. **Pas de retour d'état de la voix native** vers la page (début/fin/position).

## 2. Corrections effectuées
- `index.html` : bloc réinséré comme vrai HTML avant `</body>`, chaîne JS d'export PDF restaurée à l'identique de `index-132.html` ; `AVATAR_DATA` → `./assets/avatar-central.jpg` ; chargement de `gabon360-avatar-vivant.js`.
- `icons/gabon360-icon.jpg` : remplacée par le **logo officiel fourni** (ancien fichier conservé : `icons/gabon360-icon.corrompu-2654o.jpg.bak`). Original aussi conservé dans `assets/originals/`.
- `scripts/generate_android_launcher_icons.py` : **plus aucun logo de secours** (la compilation s'arrête si l'icône est illisible) ; marge de 17 % pour l'icône adaptative ; fond = couleur réelle des coins du logo.
- Icônes Android **générées et versionnées** (mdpi→xxxhdpi, ronde, adaptative v26, premier plan 432 px, couleur de fond).
- `assets/avatar-central.jpg` (720×864) dérivé de l'image originale, qui est conservée intacte dans `assets/originals/avatar-central-original.png`.
- `gabon360-avatar-vivant.js` (nouveau) : animation canvas de l'image originale : clignements, respiration, balancement/hochement/inclinaison/avancée du buste, sourcils, bouche pilotée par le texte (voyelles/consonnes) et resynchronisée par événements de parole, états repos / parole / alerte / écoute / réflexion, réaction aux messages des IA (via `G360_IA.avatar.deliver` et l'événement `g360:avatar-message`), redirection de `speechSynthesis` vers la voix native Android si disponible.
- `MainActivity.java` : `UtteranceProgressListener` (début, fin, position de lecture) relayé à la page.

## 3. Fichiers modifiés / ajoutés
Modifiés : `index.html`, `icons/gabon360-icon.jpg`, `scripts/generate_android_launcher_icons.py`, `android/.../MainActivity.java`, `android/.../res/mipmap-anydpi-v26/ic_launcher.xml`, `ic_launcher_round.xml`.
Ajoutés : `gabon360-avatar-vivant.js`, `assets/avatar-central.jpg`, `assets/originals/*`, `icons/gabon360-icon.corrompu-2654o.jpg.bak`, `android/.../res/mipmap-{m,h,xh,xxh,xxxh}dpi/*`, `drawable-nodpi/gabon360_icon_foreground.png`, `values/gabon360_icon_colors.xml`, ce rapport.

## 4. Tests réellement exécutés
| Test | Résultat |
|---|---|
| `node --check` des 5 JS, `sw.js`, nouveau module et 4 scripts inline de `index.html` | OK |
| Chromium (Playwright) sur Linux : page chargée, canvas avatar (accueil + fenêtre) présents | OK |
| Chromium : 550+ images rendues, 3 clignements, 2 prises de parole, ouverture de bouche max mesurée, fin de parole via événement `done` | OK |
| Chromium : voix native **simulée** (faux `AndroidTTS`) : appels reçus, état « alerte » sur texte d'alerte | OK (simulation) |
| Rendu visuel poses forcées (bouche 0/45/100 %, œil 50/100 %) inspecté | acceptable, pas photoréaliste |
| Génération des icônes Pillow : 10 PNG + XML | OK |

## 5. NON testé (impossible ici : pas de SDK Android, pas de réseau, pas d'appareil)
- Compilation Gradle/APK, installation et ouverture sur TECNO KF7j / Android 11.
- Compilation de `MainActivity.java` modifiée (relecture seulement).
- Voix française native réelle, événements `onRangeStart` (dépendent du moteur TTS du téléphone).
- Micro : `webkitSpeechRecognition` n'existe pas dans la WebView Android → bouton « Écouter » probablement inopérant ; reconnaissance native à ajouter (non faite).
- GPS réel, Locus, connexion Supabase/API, paiements, 22 IA côté serveur.
- Les mains ne sont pas animées séparément (image unique).

## 6. Fonctions NON déclarées opérationnelles
Satellites, drones, caméras, météo/maritime en flux réels, paiements : aucun flux vérifié.

## 7. Étapes pour obtenir l'APK debug
1. Copier les fichiers du ZIP sur la branche `test-avatar-central` (aucune suppression).
2. Lancer le workflow « Construire APK … » (`workflow_dispatch`) ; l'APK sort dans l'artefact `GABON-360-AI-APK-test` (debug temporaire si pas de clé).
3. Si la compilation échoue, m'envoyer le journal.
